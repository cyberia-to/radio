def normalized-log [path: path] {
    open --raw $path
    | str replace --all --regex '\x1b\[[0-9;]*m' ''
    | lines
    | each {|line| $line | str replace --regex '^\d{4}-\d\d-\d\dT\S+Z ' '' }
    | str join (char nl)
}

def first-manifest-block [path: path] {
    let text = (normalized-log $path)
    let first = 'failed to load manifest for workspace member'
    let last = 'No such file or directory (os error 2)'
    let tail = ($text | split row $first | skip 1 | first)
    $first + ($tail | split row $last | first) + $last
}

def main [] {
    let root = '/tmp/radio-bao-root-remote-ci'
    for receipt in (glob ($root | path join '*.receipt.json')) {
        let meta = (open $receipt)
        let prefix = ($receipt | str replace '.receipt.json' '')
        for stream in [stdout stderr] {
            let expected = ($meta | get $'($stream)_sha256')
            let actual = (open --raw $'($prefix).($stream)' | hash sha256)
            if $actual != $expected { error make {msg: $'hash mismatch: ($prefix).($stream)'} }
        }
        if $meta.exit != 0 { error make {msg: $'capture failure: ($receipt)'} }
    }
    let jobs = (glob ($root | path join 'pr*-run-*-jobs.stdout') | each {|file|
        let pr = ($file | path basename | split row '-' | first)
        let data = (open --raw $file | from json)
        if $data.total_count != ($data.jobs | length) { error make {msg: $'pagination required: ($file)'} }
        $data.jobs | insert pr $pr
    } | flatten)
    let failed = ($jobs | where conclusion == failure)
    let blocks = ($failed | where pr == pr33 | where name != codespell | each {|job|
        let parent = ($failed | where pr == pr32 | where name == $job.name | first)
        let paths = [$'pr32-job-($parent.id)-log.stdout' $'pr33-job-($job.id)-log.stdout']
        let before = (first-manifest-block ($root | path join $paths.0))
        let after = (first-manifest-block ($root | path join $paths.1))
        if $before != $after { error make {msg: $'changed manifest failure: ($job.name)'} }
        {name: $job.name, paths: $paths, equal: true, block: $after, block_sha256: ($after | hash sha256)}
    } | sort-by name)
    $blocks | to json | save --force ($root | path join setup-failure-comparison.json)
    let before = (normalized-log ($root | path join pr32-job-114077088822-log.stdout) | lines | where {|line| $line =~ '^\./.*==>' } | sort)
    let after = (normalized-log ($root | path join pr33-job-114105448219-log.stdout) | lines | where {|line| $line =~ '^\./.*==>' } | sort)
    {
        pr32: ($before | length), pr33: ($after | length),
        added: ($after | where {|x| $x not-in $before}),
        removed: ($before | where {|x| $x not-in $after})
    } | to json | save --force ($root | path join codespell-delta.json)
    $jobs | select pr id name status conclusion labels runner_name started_at completed_at html_url
        | to json | save --force ($root | path join jobs-index.json)
    print $'Verified receipts; ($blocks | length) exact normalized manifest-failure pairs.'
}

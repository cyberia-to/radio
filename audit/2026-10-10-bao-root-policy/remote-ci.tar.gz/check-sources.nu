def main [] {
    let repo = '/Users/master/cyber/radio-kadek-root-policy'
    let root = '/tmp/radio-bao-root-remote-ci'
    let revisions = [
        8d0ff6ccf10af71b3518701d4bccdeef5eb5e910
        f2b42c0674c586599b7defa72150ca2c5f8c4655
        fd90677c2fd3aa61a9aa9db1a07a5c1c234320cd
    ]
    let paths = [.github/workflows/ci.yml .github/workflows/docs.yaml .github/workflows/tests.yaml Cargo.toml iroh-relay/Cargo.toml]
    let records = ($paths | each {|path|
        let records = ($revisions | each {|rev|
            let argv = [-C $repo show $'($rev):($path)']
            let result = (^git ...$argv | complete)
            if $result.exit_code != 0 { error make {msg: $result.stderr} }
            {argv: ([git] | append $argv), exit: $result.exit_code, sha256: ($result.stdout | hash sha256)}
        })
        if ($records.sha256 | uniq | length) != 1 { error make {msg: $'source differs: ($path)'} }
        {path: $path, identical: true, records: $records}
    })
    let doc_argv = [-C $repo show 'fd90677c2fd3aa61a9aa9db1a07a5c1c234320cd:roadmap/soft3-radio.md']
    let doc = (^git ...$doc_argv | complete)
    if $doc.exit_code != 0 { error make {msg: $doc.stderr} }
    {
        checked_at: (date now | format date '%Y-%m-%dT%H:%M:%S%:z'),
        sources: $records,
        codespell_added_source: {
            argv: ([git] | append $doc_argv), exit: $doc.exit_code,
            sha256: ($doc.stdout | hash sha256), line: 220,
            text: ($doc.stdout | lines | get 219)
        }
    } | to json | save --force ($root | path join source-comparison.json)
    print 'Five exact source paths identical across PR32 head, PR33 head, and PR33 base; added codespell line verified in base.'
}

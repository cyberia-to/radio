def main [] {
    let root = '/tmp/radio-bao-root-remote-ci'
    for file in (glob ($root | path join 'pr*-run-*-jobs.stdout')) {
        let pr = ($file | path basename | split row '-' | first)
        let data = (open --raw $file | from json)
        if $data.total_count != ($data.jobs | length) {
            error make {msg: $'pagination required: ($file)'}
        }
        for job in ($data.jobs | where status == completed | where conclusion != cancelled | where conclusion != skipped) {
            let label = $'($pr)-job-($job.id)-log'
            if not ($root | path join $'($label).receipt.json' | path exists) {
                ^nu ($root | path join capture.nu) $label api $'repos/cyberia-to/radio/actions/jobs/($job.id)/logs'
                if $env.LAST_EXIT_CODE != 0 { error make {msg: $'log download failed: ($label)'} }
            }
        }
    }
}

def main [label: string, ...args: string] {
    let root = '/tmp/radio-bao-root-remote-ci'
    let began = (date now | format date '%Y-%m-%dT%H:%M:%S%:z')
    let result = (^gh ...$args | complete)
    $result.stdout | save --force ($root | path join $'($label).stdout')
    $result.stderr | save --force ($root | path join $'($label).stderr')
    {
        argv: ([gh] | append $args),
        started: $began,
        ended: (date now | format date '%Y-%m-%dT%H:%M:%S%:z'),
        exit: $result.exit_code,
        stdout_sha256: ($result.stdout | hash sha256),
        stderr_sha256: ($result.stderr | hash sha256)
    } | to json | save --force ($root | path join $'($label).receipt.json')
    if $result.exit_code != 0 { error make {msg: $'gh exited ($result.exit_code): ($label)'} }
    print $label
}

use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let db = '/Users/master/.cargo/advisory-dbs/advisory-db-3157b0e258782691'
 let head = (checked [git -C $db rev-parse HEAD] | str trim)
 if $head != '7eebec69c352c7191b1f13eb95dd510eeca5d1de' or (checked [git -C $db status --porcelain] | str trim) != '' { error make {msg: 'advisory DB drift; create isolated pinned copy first'} }
 {database: $db, revision: $head, no_fetch: true, source_config_sha256: (sha ($run | path join candidate radio deny.toml))} | to json | save ($run | path join candidate-deny-source.json)
 for item in [
  {name: candidate-named-format, args: [make --disable-check-for-updates format-check]}
  {name: candidate-named-nextest-all, args: [nextest run --workspace --all-features --lib --bins --tests --no-run --locked --offline]}
  {name: candidate-named-clippy-all, args: [clippy --workspace --all-features --all-targets --lib --bins --tests --benches --examples --locked --offline]}
  {name: candidate-named-clippy-none, args: [clippy --workspace --no-default-features --all-targets --lib --bins --tests --benches --examples --locked --offline]}
  {name: candidate-named-clippy-default, args: [clippy --workspace --all-targets --lib --bins --tests --benches --examples --locked --offline]}
  {name: candidate-named-deny, args: [deny --workspace --all-features --locked check --disable-fetch -Dwarnings]}
 ] {
  let outcome = (^nu ($run | path join candidate-project-gate.nu) $item.name --args ($item.args | to json --raw) | complete)
  print $outcome.stdout
  if $outcome.stderr != '' { print --stderr $outcome.stderr }
  if not (($run | path join logs $'($item.name).json') | path exists) { error make {msg: 'runner failed before receipt'} }
 }
 let outcome = (^nu ($run | path join candidate-project-gate.nu) candidate-named-nightly-docs --toolchain nightly-2025-10-09 --ci-docs --args '["doc","--workspace","--all-features","--no-deps","--document-private-items","--locked","--offline"]' | complete)
 print $outcome.stdout
 if $outcome.stderr != '' { print --stderr $outcome.stderr }
 if not (($run | path join logs candidate-named-nightly-docs.json) | path exists) { error make {msg: 'nightly runner failed before receipt'} }
}

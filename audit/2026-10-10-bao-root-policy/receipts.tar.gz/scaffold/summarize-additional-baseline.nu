use common.nu *
def main [] {
    let run = $env.FILE_PWD
    let names = [iroh-blobs-clippy iroh-blobs-doc workspace-test-compile local-consumers-test-compile named-format-check named-nextest-build named-deny named-msrv-workspace]
    let gates = ($names | each {|name|
        let stem = ($run | path join logs $"parent-($name)")
        let receipt = (open $"($stem).json")
        let stderr = (open --raw $"($stem).stderr")
        {
            name: $name, exit: $receipt.exit, argv: $receipt.argv
            receipt: $"($stem).json", receipt_sha256: (sha $"($stem).json")
            first_error: ($stderr | lines | where {|line| $line | str starts-with 'error' } | get 0? | default '')
            stdout_sha256: (sha $"($stem).stdout"), stderr_sha256: (sha $"($stem).stderr")
        }
    })
    {
        radio: '258724bd8ab797ad8d2ef43c6a4a2e07f1fc9e24'
        hemera: '23f3bbcff910ea6d504ceb505680a539260869da'
        scope: 'Exact-parent baseline only; no candidate overlay or source changes.'
        gates: $gates
        qualification: 'Workspace/local-consumer test commands used --no-run; both fail compilation and execute no tests. Missing make/nextest/deny are unavailable tool gates. Ordinary compiler1.95.0; named MSRV uses actual1.89.0. Both set matching RUSTC/RUSTDOC, jobs4 and strict warnings.'
        named_nightly_docs: 'Unavailable: nightly-2025-10-09 rustdoc missing. Initial rustup which unexpectedly began automatic download; own process interrupted(exit-2), no-install lookup exit1, only newly created incomplete toolchain removed(exit0), inventory restored. Every raw receipt retained.'
        nightly_receipts: [parent-native-doc-toolchain parent-native-doc-toolchain-no-install parent-toolchain-inventory-after parent-remove-incomplete-doc-toolchain parent-toolchain-inventory-during-removal parent-toolchain-inventory-restored]
        other_stages: 'No cross-platform, Android, wasm, network simulation, minimal-versions lock regeneration, semver, full CI matrix or product/rung gate executed.'
        closure: 'parent-local-source-closure.json'
        lock_sha256: (sha ($run | path join parent radio Cargo.lock))
        total_scaffold_bytes: (usage $run)
    } | to json | save ($run | path join parent-additional-baseline-summary.json)
    $gates | select name exit first_error
}

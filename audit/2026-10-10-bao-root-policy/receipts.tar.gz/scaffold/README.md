# BAO ROOT isolated gate scaffolding

Exact source-only parent/candidate closures: radio258724bd8ab797ad8d2ef43c6a4a2e07f1fc9e24,
Hemera23f3bbcff910ea6d504ceb505680a539260869da. No test/build/metadata/overlay has run.
Only tracked nettools/target is excluded; archive pathspec and full/excluded Git
inventories are retained. Cargo.lock remains exact; no manifest or source shim.

- `nu prepare.nu` prepares once and refuses replacing closures; each setup command has a receipt.
- After approval/source freeze only: `nu overlay.nu --source <owned-worktree> --freeze <JSON>`
  checks proposed `{path,sha256}` records; add `--execute` to copy the whitelisted files
  into candidate only and retain hashes. It never copies task docs, manifests or locks.
- `nu gate.nu --scope candidate --name root-debug --args '["test","-p","cyber-bao","--test","root_policy","--locked","--offline"]'`
  prints argv/environment only. After authorization add `--execute` to run and record it.
- Ordinary commands pin actual1.95.0 cargo/rustc/rustdoc/Clippy; `--toolchain 1.89.0`
  selects actual MSRV binaries. Build jobs4. No Homebrew or inherited stable compiler override.
- `nu gate.nu --scope parent --name clean-after-recorded-gates --clean-completed --execute`
  cleans only that completed owned target. Logs/archives/source receipts remain outside targets.

Execute gates sequentially, never two scopes concurrently. Retain raw logs before
cleaning. Keep this entire run under30GB: a20GB pre-gate staging threshold requires
cleaning completed targets, and size is recorded before/after. The runner does not
promise a hard live filesystem quota; monitor long builds and stop them before30GB.
Do not clean running/other-owned targets. No release/rung/row-4 closure follows.

The approved gate plan remains in the frozen task docs. This scaffolding does not
assert fresh review approval or select a protocol, migration, or alternate root.

def main [] {
 let run = $env.FILE_PWD
 for item in [
  {name: bao-release-all, args: [test -p cyber-bao --release --all-features --locked --offline]}
  {name: native-root-release-all, args: [test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --release --all-features --locked --offline]}
  {name: native-export-release-all, args: [test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --release --all-features --locked --offline]}
 ] {
  ^nu ($run | path join gate.nu) --scope candidate --name $item.name --execute --args ($item.args | to json --raw)
  if $env.LAST_EXIT_CODE != 0 { exit $env.LAST_EXIT_CODE }
 }
}

export def checked [args: list<string>] {
    let r = (run-external ($args | first) ...($args | skip 1) | complete)
    if $r.exit_code != 0 { error make {msg: $"command failed: ($args | to nuon)\nexit ($r.exit_code)\n($r.stderr)\n($r.stdout)"} }
    $r.stdout
}
export def sha [file: path] {
    checked [shasum -a 256 $file] | split row ' ' | first
}
export def record [run: path, name: string, args: list<string>, environment: record = {}] {
    let stem = ($run | path join logs $name)
    if ($"($stem).json" | path exists) { error make {msg: $"receipt already exists: ($name)"} }
    let started = (date now)
    let result = (with-env $environment { run-external ($args | first) ...($args | skip 1) | complete })
    $result.stdout | save $"($stem).stdout"
    $result.stderr | save $"($stem).stderr"
    {argv: $args, environment: $environment, cwd: $env.PWD, started: $started,
        ended: (date now), exit: $result.exit_code,
        stdout_sha256: ($result.stdout | hash sha256), stderr_sha256: ($result.stderr | hash sha256)}
        | to json | save $"($stem).json"
    print $"($name): exit ($result.exit_code)"
    $result
}
export def required [run: path, name: string, args: list<string>] {
    let result = (record $run $name $args)
    if $result.exit_code != 0 { error make {msg: $"setup failed: ($name), exit ($result.exit_code); receipt retained"} }
    $result.stdout
}
export def usage [run: path] {
    checked [du -sk $run] | parse -r '^(?P<kb>\d+)\s+' | get 0.kb | into int | $in * 1024
}

use common.nu *
def main [--radio-repo: path = '/Users/master/cyber/radio', --hemera-repo: path = '/Users/master/cyber/hemera'] {
    let run = $env.FILE_PWD
    let radio = '258724bd8ab797ad8d2ef43c6a4a2e07f1fc9e24'
    let hemera = '23f3bbcff910ea6d504ceb505680a539260869da'
    if (($run | path join parent) | path exists) { error make {msg: 'prepare refuses to replace existing source closures'} }
    mkdir ($run | path join logs) ($run | path join archives) ($run | path join targets)
    let top = (required $run top [git -C $radio_repo ls-tree --name-only $radio] | lines | where $it != 'nettools')
    let net = (required $run nettools [git -C $radio_repo ls-tree --name-only $"($radio):nettools"]
        | lines | where $it != 'target' | each { $"nettools/($in)" })
    let selected = ($top | append $net)
    $selected | to json | save ($run | path join archives radio-pathspec.json)
    required $run excluded-targets [git -C $radio_repo ls-tree -r --long $radio nettools/target]
        | save ($run | path join archives excluded-nettools-target.txt)
    required $run radio-tree [git -C $radio_repo ls-tree -r $radio]
        | save ($run | path join archives radio-full-tree.txt)
    required $run hemera-tree [git -C $hemera_repo ls-tree -r $hemera]
        | save ($run | path join archives hemera-full-tree.txt)
    let radio_tar = ($run | path join archives radio.tar)
    let hemera_tar = ($run | path join archives hemera.tar)
    required $run archive-radio ([git -C $radio_repo archive --format=tar --output $radio_tar $radio] | append $selected) | ignore
    required $run archive-hemera [git -C $hemera_repo archive --format=tar --output $hemera_tar $hemera] | ignore
    required $run list-radio [tar -tf $radio_tar] | save ($run | path join archives radio-tar-paths.txt)
    required $run list-hemera [tar -tf $hemera_tar] | save ($run | path join archives hemera-tar-paths.txt)
    let lock_blob = (required $run lock-blob [git -C $radio_repo rev-parse $"($radio):Cargo.lock"] | str trim)
    let lock_sha = '295b21c8804e3885a195511ffca6fcf368e7c762c5b411374aecf20ba4d14052'
    for scope in [parent candidate] {
        let root = ($run | path join $scope)
        mkdir ($root | path join radio) ($root | path join hemera) ($run | path join targets $scope)
        required $run $"extract-($scope)-radio" [tar -xf $radio_tar -C ($root | path join radio)] | ignore
        required $run $"extract-($scope)-hemera" [tar -xf $hemera_tar -C ($root | path join hemera)] | ignore
        let lock = ($root | path join radio Cargo.lock)
        if (checked [git hash-object $lock] | str trim) != $lock_blob or (sha $lock) != $lock_sha {
            error make {msg: $"($scope) lock differs from committed bytes"}
        }
        if (($root | path join radio nettools target) | path exists) { error make {msg: 'excluded target appeared in export'} }
    }
    let toolchains = ([1.95.0 1.89.0] | each {|version|
        let names = if $version == '1.95.0' { [cargo rustc rustdoc cargo-clippy] } else { [cargo rustc rustdoc] }
        let binaries = ($names | each {|name|
            let path = (required $run $"tool-($version)-($name)" [rustup which --toolchain $version $name] | str trim)
            let args = if $name == 'rustc' or $name == 'cargo' { [$path -Vv] } else { [$path --version] }
            required $run $"version-($version)-($name)" $args | ignore
            {name: $name, path: $path, sha256: (sha $path)}
        })
        {version: $version, binaries: $binaries}
    })
    $toolchains | to json | save ($run | path join toolchains.json)
    {radio: $radio, hemera: $hemera, candidate_overlay: null,
        archive_paths: {radio: $radio_tar, hemera: $hemera_tar},
        archive_sha256: {radio: (sha $radio_tar), hemera: (sha $hemera_tar)},
        lock_blob: $lock_blob, lock_sha256: $lock_sha,
        exclusion: 'Only tracked nettools/target; full top-level entries except nettools plus every nettools child except target.',
        preparation: 'Exact source export only. No cargo metadata, tests, build, network fetch or production overlay run.',
        jobs: 4, total_disk_limit_bytes: 30000000000, bytes_after_prepare: (usage $run)}
        | to json | save ($run | path join sources.json)
    print $"Prepared source-only parent and candidate at ($run)."
}

use common.nu *
def main [] {
    let run = $env.FILE_PWD
    let source = '/Users/master/cyber/radio-kadek-root-policy'
    let root = ($run | path join witness)
    if ($root | path exists) { error make {msg: 'witness already exists'} }
    for repo in [radio hemera] {
        let dest = ($root | path join $repo)
        mkdir $dest
        required $run $'witness-extract-($repo)' [tar -xf ($run | path join archives $'($repo).tar') -C $dest] | ignore
    }
    let path = 'cyber-bao/tests/root_policy.rs'
    let src = ($source | path join $path)
    let dest = ($root | path join radio $path)
    cp $src $dest
    let hash = (sha $src)
    if (sha $dest) != $hash { error make {msg: 'test overlay copy mismatch'} }
    [{path: $path, sha256: $hash, source: $src}] | to json | save ($run | path join witness-test-overlay.json)
    let inputs = (open ($run | path join sources.json))
    if (sha ($root | path join radio Cargo.lock)) != $inputs.lock_sha256 { error make {msg: 'witness lock drift'} }
}

def main [] {
 let run = $env.FILE_PWD
 let cases = [
  {name: root-policy-all, args: [test -p cyber-bao --test root_policy --all-features --locked --offline]}
  {name: native-root-policy-default, args: [test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --locked --offline]}
  {name: native-root-policy-all, args: [test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --all-features --locked --offline]}
  {name: native-export-default, args: [test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --locked --offline]}
  {name: native-export-all, args: [test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --all-features --locked --offline]}
  {name: bao-default, args: [test -p cyber-bao --locked --offline]}
  {name: bao-all, args: [test -p cyber-bao --all-features --locked --offline]}
 ]
 for item in $cases {
  ^nu ($run | path join gate.nu) --scope candidate --name $item.name --execute --args ($item.args | to json --raw)
  if $env.LAST_EXIT_CODE != 0 { exit $env.LAST_EXIT_CODE }
 }
}

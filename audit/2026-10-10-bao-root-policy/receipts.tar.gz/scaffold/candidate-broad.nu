def main [] {
 let run = $env.FILE_PWD
 let cases = [
  {name: metadata, toolchain: '1.95.0', args: [metadata --format-version '1' --locked --offline]}
  {name: format, toolchain: '1.95.0', args: [fmt --all -- --check]}
  {name: bao-clippy, toolchain: '1.95.0', args: [clippy --manifest-path cyber-bao/Cargo.toml --all-targets --all-features --locked --offline -- -D warnings]}
  {name: native-clippy, toolchain: '1.95.0', args: [clippy --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline -- -D warnings]}
  {name: bao-doc, toolchain: '1.95.0', args: [doc --manifest-path cyber-bao/Cargo.toml --all-features --no-deps --locked --offline]}
  {name: native-doc, toolchain: '1.95.0', args: [doc --manifest-path iroh-blobs/Cargo.toml --all-features --no-deps --locked --offline]}
  {name: workspace-no-run, toolchain: '1.95.0', args: [test --workspace --no-run --locked --offline]}
  {name: consumers-no-run, toolchain: '1.95.0', args: [test -p particle -p radio-cli -p radio-integration-tests --all-features --no-run --locked --offline]}
  {name: msrv-bao-check, toolchain: '1.89.0', args: [check -p cyber-bao --all-targets --all-features --locked --offline]}
  {name: msrv-bao-root, toolchain: '1.89.0', args: [test -p cyber-bao --test root_policy --all-features --locked --offline]}
  {name: msrv-native-root, toolchain: '1.89.0', args: [test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --locked --offline]}
  {name: msrv-native-export, toolchain: '1.89.0', args: [test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --locked --offline]}
  {name: msrv-workspace-check, toolchain: '1.89.0', args: [check --workspace --all-targets --locked --offline]}
 ]
 for item in $cases {
  if (($run | path join logs $'candidate-($item.name).json') | path exists) { continue }
  let outcome = (^nu ($run | path join gate.nu) --scope candidate --name $item.name --toolchain $item.toolchain --execute --args ($item.args | to json --raw) | complete)
  print $outcome.stdout
  if $outcome.stderr != '' { print --stderr $outcome.stderr }
  # Every red is retained separately; later gates have independent obligations.
  if not (($run | path join logs $'candidate-($item.name).json') | path exists) { error make {msg: 'runner failed before receipt; stop'} }
 }
}

use common.nu *
def main [--source: path, --freeze: path, --execute] {
    if $source == null or $freeze == null { error make {msg: '--source and --freeze are required'} }
    let run = $env.FILE_PWD
    let inputs = (open ($run | path join sources.json))
    let allowed = ['cyber-bao/src/io/mod.rs' 'cyber-bao/src/io/outboard.rs' 'cyber-bao/src/io/decode.rs'
        'cyber-bao/src/io/slice.rs' 'cyber-bao/src/io/sync.rs' 'cyber-bao/tests/slice_traversal.rs'
        'cyber-bao/tests/root_policy.rs' 'cyber-bao/tests/root_policy_async.rs'
        'iroh-blobs/src/hash.rs' 'iroh-blobs/src/api/blobs/export_pairs.rs'
        'iroh-blobs/src/api/blobs/export_pairs/support.rs']
    let files = (open $freeze)
    if ($files | is-empty) or (($files | get path | uniq | length) != ($files | length)) { error make {msg: 'empty/duplicate source freeze'} }
    let checked_files = ($files | each {|item|
        if $item.path not-in $allowed { error make {msg: $"out-of-scope overlay: ($item.path)"} }
        let src = ($source | path join $item.path)
        let dst = ($run | path join candidate radio $item.path)
        let actual = (sha $src)
        if $actual != $item.sha256 { error make {msg: $"source freeze mismatch: ($item.path)"} }
        {path: $item.path, source: $src, destination: $dst, sha256: $actual,
            old_sha256: (if ($dst | path exists) { sha $dst } else { null })}
    })
    if not $execute { print ($checked_files | to json); return }
    if (($run | path join overlay.json) | path exists) { error make {msg: 'overlay already recorded; do not overwrite reviewed state'} }
    for item in $checked_files {
        mkdir ($item.destination | path dirname)
        cp $item.source $item.destination
        if (sha $item.destination) != $item.sha256 { error make {msg: 'copy verification failed'} }
    }
    if (sha ($run | path join candidate radio Cargo.lock)) != $inputs.lock_sha256 { error make {msg: 'overlay changed lock'} }
    {time: (date now), source: ($source | path expand), freeze: ($freeze | path expand),
        freeze_sha256: (sha $freeze), files: $checked_files,
        status: 'Local reviewed-source overlay, not a release candidate or origin input.'}
        | to json | save ($run | path join overlay.json)
}

use common.nu *
def main [] {
    let run = $env.FILE_PWD
    for version in ['1.95.0' '1.89.0'] {
        let args = '["check","-p","cyber-bao","--all-features","--all-targets","--locked","--offline"]'
        let text = (required $run $"dry-gate-($version)" [nu ($run | path join gate.nu) --scope candidate --name dry-only --toolchain $version --args $args])
        let dry = ($text | from json)
        let bin = ($dry.argv | first | path dirname)
        if ($dry.environment.PATH | first) != $bin or $dry.environment.RUSTC != ($bin | path join rustc) or $dry.environment.RUSTDOC != ($bin | path join rustdoc) {
            error make {msg: 'dry gate compiler environment mismatch'}
        }
        if $dry.environment.CARGO_BUILD_JOBS != '4' { error make {msg: 'jobs mismatch'} }
    }
    let source = ($run | path join parent radio)
    let freeze = ($run | path join dry-overlay-freeze.json)
    [{path: 'cyber-bao/src/io/mod.rs', sha256: (sha ($source | path join cyber-bao src io mod.rs))}]
        | to json | save $freeze
    required $run dry-overlay [nu ($run | path join overlay.nu) --source $source --freeze $freeze] | ignore
    if (($run | path join overlay.json) | path exists) { error make {msg: 'dry overlay mutated source state'} }
    if not (glob ($run | path join targets '*' '*') | is-empty) { error make {msg: 'unexpected target output'} }
    print 'Scaffolding dry-runs validated; no cargo metadata/check/build/test or source overlay executed.'
}

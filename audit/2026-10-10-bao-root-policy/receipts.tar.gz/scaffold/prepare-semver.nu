use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let root = ($run | path join semver)
 if ($root | path exists) { error make {msg: 'semver closure exists'} }
 for scope in [current parent tag] {
  let dest = ($root | path join $scope)
  mkdir ($dest | path join radio) ($dest | path join hemera)
  let archive = if $scope == tag { 'tag-radio.tar' } else { 'radio.tar' }
  required $run $'semver-prepare-($scope)-radio' [tar -xf ($run | path join archives $archive) -C ($dest | path join radio)] | ignore
  required $run $'semver-prepare-($scope)-hemera' [tar -xf ($run | path join archives hemera.tar) -C ($dest | path join hemera)] | ignore
 }
 let freeze = (open /tmp/kadek-bao-root-policy-source-v3.json)
 for item in $freeze {
  let src = ($run | path join candidate radio $item.path)
  if (sha $src) != $item.sha256 { error make {msg: 'source freeze mismatch'} }
  let dest = ($root | path join current radio $item.path)
  mkdir ($dest | path dirname)
  cp $src $dest
 }
 let exe = (which cargo-semver-checks | first | get path)
 required $run semver-tool-version [$exe --version] | ignore
 {tool: $exe, tool_sha256: (sha $exe), snapshot: 'source-v3 test-only refinement; authoritative source closures remain separate from tool scratch resolution', freeze_sha256: (sha /tmp/kadek-bao-root-policy-source-v3.json), locks: ([current parent tag] | each {|scope| {scope: $scope, sha256: (sha ($root | path join $scope radio Cargo.lock))}})} | to json | save ($run | path join semver-sources.json)
}

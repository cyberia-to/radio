use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let bin = '/Users/master/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin'
 let environment = {PATH: ([$bin] | append $env.PATH), RUSTC: ($bin | path join rustc), RUSTDOC: ($bin | path join rustdoc), RUSTUP_TOOLCHAIN: '1.95.0'}
 cd ($run | path join candidate radio)
 for item in [
 {name: candidate-clean-completed-release, args: [clean --release --target-dir ($run | path join targets candidate)]}
 {name: candidate-clean-completed-parent-nightly, args: [clean --target-dir ($run | path join targets parent-nightly-docs)]}
 ] {
 let result = (record $run $item.name ([($bin | path join cargo)] | append $item.args) $environment)
 if $result.exit_code != 0 { exit $result.exit_code }
 }
}

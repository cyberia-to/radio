use common.nu *
def main [] {
    let run = $env.FILE_PWD
    let input = ($run | path join logs parent-metadata.stdout)
    let metadata = (open --raw $input | from json)
    let local = ($metadata.packages | where source == null)
    let bao = ($local | where name == cyber-bao | first | get id)
    mut closure = [$bao]
    loop {
        let seen = $closure
        let found = ($metadata.resolve.nodes | where {|node|
            ($node.id not-in $seen) and ($node.deps | any {|dep| $dep.pkg in $seen })
        } | get id)
        if ($found | is-empty) { break }
        $closure = ($closure | append $found)
    }
    let rows = ($metadata.packages | where {|p| $p.id in $closure } | select id name version source manifest_path)
    {
        basis: 'Exact-parent locked offline Cargo metadata; default workspace feature resolution. Source closure, not executed reverse-dependency tests.'
        metadata_sha256: (sha $input)
        radio: '258724bd8ab797ad8d2ef43c6a4a2e07f1fc9e24'
        hemera: '23f3bbcff910ea6d504ceb505680a539260869da'
        local_package_count: ($local | length)
        transitive_reverse_closure_including_root: $rows
    } | to json | save ($run | path join parent-local-source-closure.json)
    $rows | select name version source
}

def main [] {
 let run = $env.FILE_PWD
 ^nu ($run | path join overlay-v3.nu)
 if $env.LAST_EXIT_CODE != 0 { exit $env.LAST_EXIT_CODE }
 for item in [
  {name: v3-bao-all, args: [test -p cyber-bao --all-features --locked --offline]}
  {name: v3-native-root-all, args: [test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --all-features --locked --offline]}
  {name: v3-native-export-all, args: [test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --all-features --locked --offline]}
  {name: v3-bao-release-all, args: [test -p cyber-bao --release --all-features --locked --offline]}
  {name: v3-native-root-release-all, args: [test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --release --all-features --locked --offline]}
  {name: v3-native-export-release-all, args: [test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --release --all-features --locked --offline]}
 ] {
  ^nu ($run | path join gate.nu) --scope candidate --name $item.name --execute --args ($item.args | to json --raw)
  if $env.LAST_EXIT_CODE != 0 { exit $env.LAST_EXIT_CODE }
 }
 ^nu ($run | path join candidate-fixture.nu)
 if $env.LAST_EXIT_CODE != 0 { exit $env.LAST_EXIT_CODE }
 ^nu ($run | path join candidate-broad.nu)
 exit $env.LAST_EXIT_CODE
}

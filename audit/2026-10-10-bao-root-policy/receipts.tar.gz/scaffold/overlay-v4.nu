use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let old = (open /tmp/kadek-bao-root-policy-source-v3.json)
 let new = (open /tmp/kadek-bao-root-policy-source-v4.json)
 let path = 'iroh-blobs/src/api/blobs/export_pairs/support.rs'
 for item in $new {
  let prior = ($old | where path == $item.path | first)
  if $item.path != $path and $item.sha256 != $prior.sha256 { error make {msg: 'unexpected source change'} }
  if (sha ($run | path join candidate radio $item.path)) != $prior.sha256 { error make {msg: 'candidate old snapshot changed'} }
 }
 let src = ('/Users/master/cyber/radio-kadek-root-policy' | path join $path)
 let dst = ($run | path join candidate radio $path)
 let expected = (open --raw $dst | str replace "use hemera::tree::{chunk_cv, parent_cv};\n\nuse iroh::endpoint::VarInt;" "use hemera::tree::{chunk_cv, parent_cv};\nuse iroh::endpoint::VarInt;")
 if $expected != (open --raw $src) { error make {msg: 'change is not the exact one blank-line removal'} }
 if (($run | path join overlay-v4.json) | path exists) { error make {msg: 'existing overlay receipt'} }
 cp $src $dst
 for item in $new { if (sha ($run | path join candidate radio $item.path)) != $item.sha256 { error make {msg: 'post-copy drift'} } }
 {old_freeze: '/tmp/kadek-bao-root-policy-source-v3.json', new_freeze: '/tmp/kadek-bao-root-policy-source-v4.json', old_sha256: (sha /tmp/kadek-bao-root-policy-source-v3.json), new_sha256: (sha /tmp/kadek-bao-root-policy-source-v4.json), path: $path, reason: 'Exactly one blank line between external imports removed; no Rust token change.', time: (date now)} | to json | save ($run | path join overlay-v4.json)
}

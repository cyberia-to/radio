use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let bin = '/Users/master/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin'
 let fixture = ($run | path join candidate-right-fixture)
 mkdir $fixture
 let environment = {PATH: ([$bin] | append $env.PATH), RUSTC: ($bin | path join rustc), RUSTDOC: ($bin | path join rustdoc), RUSTUP_TOOLCHAIN: '1.95.0', RUSTFLAGS: '-Dwarnings', RUSTDOCFLAGS: '-Dwarnings', CARGO_BUILD_JOBS: '4', CARGO_TARGET_DIR: ($run | path join targets candidate), RADIO_EXPORT_PAIRS_FIXTURE_DIR: $fixture}
 cd ($run | path join candidate radio)
 let result = (record $run candidate-right-fixture [($bin | path join cargo) test --manifest-path iroh-blobs/Cargo.toml --lib api::blobs::export_pairs::readonly_store_right_block --all-features --locked --offline -- --exact] $environment)
 if $result.exit_code != 0 { exit $result.exit_code }
 let hash = (sha ($fixture | path join right-proof.bin))
 let root = (open --raw ($fixture | path join right-root.txt))
 let bytes = (ls ($fixture | path join right-proof.bin) | first | get size | into int)
 if $hash != '108022aa95ee61a1058d6d4bb53979a95bc46de114b036fcc6620fbd65648a51' or $root != '9ccd2809b2bcca875ee39f2c034c80969c176a5510a66d638b2c88c3cd7c7f0f' or $bytes != 65608 { error make {msg: 'independent right proof drift'} }
 {root: $root, proof_bytes: $bytes, proof_sha256: $hash, command_receipt: 'logs/candidate-right-fixture.json'} | to json | save ($run | path join candidate-right-fixture.json)
}

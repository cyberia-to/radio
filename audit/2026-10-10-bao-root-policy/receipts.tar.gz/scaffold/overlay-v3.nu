use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let old = (open /tmp/kadek-bao-root-policy-source-v2.json)
 let new = (open /tmp/kadek-bao-root-policy-source-v3.json)
 let changed = ['cyber-bao/tests/root_policy.rs' 'iroh-blobs/src/api/blobs/export_pairs/support.rs']
 for item in $new {
  let prior = ($old | where path == $item.path | first)
  if $item.path not-in $changed and $item.sha256 != $prior.sha256 { error make {msg: 'unexpected source change'} }
  if (sha ($run | path join candidate radio $item.path)) != $prior.sha256 { error make {msg: 'candidate old snapshot changed'} }
  if (sha ('/Users/master/cyber/radio-kadek-root-policy' | path join $item.path)) != $item.sha256 { error make {msg: 'owned source drift'} }
 }
 if (($run | path join overlay-v3.json) | path exists) { error make {msg: 'existing overlay receipt'} }
 for path in $changed { cp ('/Users/master/cyber/radio-kadek-root-policy' | path join $path) ($run | path join candidate radio $path) }
 for item in $new { if (sha ($run | path join candidate radio $item.path)) != $item.sha256 { error make {msg: 'post-copy drift'} } }
 {old_freeze: '/tmp/kadek-bao-root-policy-source-v2.json', new_freeze: '/tmp/kadek-bao-root-policy-source-v3.json', old_sha256: (sha /tmp/kadek-bao-root-policy-source-v2.json), new_sha256: (sha /tmp/kadek-bao-root-policy-source-v3.json), changes: $changed, reason: 'Test-only helper placement below imports and exact range cardinality assertion; production unchanged.', time: (date now)} | to json | save ($run | path join overlay-v3.json)
}

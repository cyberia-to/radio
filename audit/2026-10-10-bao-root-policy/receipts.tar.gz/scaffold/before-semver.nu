use common.nu *
def main [] {
 let run = $env.FILE_PWD
 ^nu ($run | path join gate.nu) --scope candidate --name clean-completed-before-semver --clean-completed --execute
 if $env.LAST_EXIT_CODE != 0 { exit $env.LAST_EXIT_CODE }
 let bin = '/Users/master/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin'
 cd ($run | path join candidate radio)
 let result = (record $run candidate-clean-completed-nightly [($bin | path join cargo) clean --target-dir ($run | path join targets candidate-nightly-docs)] {RUSTUP_TOOLCHAIN: '1.95.0', RUSTC: ($bin | path join rustc), RUSTDOC: ($bin | path join rustdoc)})
 if $result.exit_code != 0 { exit $result.exit_code }
 let freeze = (open /tmp/kadek-bao-root-policy-source-v4.json)
 let path = 'iroh-blobs/src/api/blobs/export_pairs/support.rs'
 cp ($run | path join candidate radio $path) ($run | path join semver current radio $path)
 for item in $freeze { if (sha ($run | path join semver current radio $item.path)) != $item.sha256 { error make {msg: 'semver candidate v4 drift'} } }
 {freeze: '/tmp/kadek-bao-root-policy-source-v4.json', sha256: (sha /tmp/kadek-bao-root-policy-source-v4.json), note: 'Same final v4 source; source-v3 to v4 transition removes one blank line only; manifests/locks preserved in semver-sources.json.'} | to json | save ($run | path join semver-sources-v4.json)
 ^nu ($run | path join candidate-semver.nu)
 exit $env.LAST_EXIT_CODE
}

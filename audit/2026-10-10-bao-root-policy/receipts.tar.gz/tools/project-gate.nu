use /tmp/radio-bao-root-policy.rPXzYh/common.nu *
def main [name: string, --toolchain: string = '1.95.0', --ci-docs, --args: string] {
 let run = $env.FILE_PWD
 let scaffold = '/tmp/radio-bao-root-policy.rPXzYh'
 if $toolchain not-in ['1.95.0' 'nightly-2025-10-09'] { error make {msg: 'unpinned compiler'} }
 let configured = $'/Users/master/.rustup/toolchains/($toolchain)-aarch64-apple-darwin/bin'
 let sources = (open ($scaffold | path join sources.json))
 let before = ((usage $run) + (usage $scaffold))
 if $before >= 20000000000 { error make {msg: '20GB staging threshold'} }
 let target = if $toolchain == '1.95.0' { $scaffold | path join targets parent } else { $scaffold | path join targets parent-nightly-docs }
 let environment = { PATH: ([($run | path join bin) $configured] | append $env.PATH), RUSTC: ($configured | path join rustc), RUSTDOC: ($configured | path join rustdoc), RUSTUP_TOOLCHAIN: $toolchain, RUSTUP_AUTO_INSTALL: '0', CARGO_BUILD_JOBS: '4', CARGO_TARGET_DIR: $target, RUSTFLAGS: '-Dwarnings', RUSTDOCFLAGS: (if $ci_docs { '--cfg docsrs' } else { '-Dwarnings' }) }
 cd ($scaffold | path join parent radio)
 if (sha Cargo.lock) != $sources.lock_sha256 { error make {msg: 'lock drift before command'} }
 let result = (record $run $name ([($configured | path join cargo)] | append ($args | from json)) $environment)
 let after = ((usage $run) + (usage $scaffold))
 {before_bytes: $before, after_bytes: $after, target: $target, limit_bytes: 30000000000, source_revision: '258724bd8ab797ad8d2ef43c6a4a2e07f1fc9e24', lock_sha256: (sha Cargo.lock)} | to json | save ($run | path join logs $'($name).usage.json')
 if (sha Cargo.lock) != $sources.lock_sha256 { error make {msg: 'lock drift after command; receipt preserved'} }
 if $after > 30000000000 { error make {msg: '30GB total limit exceeded'} }
 exit $result.exit_code
}

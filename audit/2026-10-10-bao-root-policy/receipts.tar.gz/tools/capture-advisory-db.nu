use /tmp/radio-bao-root-policy.rPXzYh/common.nu *
let run = '/tmp/radio-gate-tools'
let db = '/Users/master/.cargo/advisory-dbs/advisory-db-3157b0e258782691'
let head = (required $run advisory-db-head [git -C $db rev-parse HEAD] | str trim)
let state = (required $run advisory-db-status [git -C $db status --porcelain=v1])
if $state != '' { error make {msg: 'advisory DB dirty'} }
let source = (required $run advisory-db-origin [git -C $db remote get-url origin] | str trim)
let archive = ($run | path join advisory-db.tar)
let unused = (required $run advisory-db-archive [git -C $db archive --format=tar --output $archive $head])
{revision: $head, source: $source, original_path: $db, archive: $archive, archive_sha256: (sha $archive), fetched_by: 'parent-deny-installed', candidate_requirement: 'check --disable-fetch after asserting exact same DB HEAD and clean status; restore own isolated snapshot if shared cache changes'} | to json | save ($run | path join advisory-db.json)

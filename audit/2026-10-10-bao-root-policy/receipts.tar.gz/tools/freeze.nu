use /tmp/radio-bao-root-policy.rPXzYh/common.nu *
let root = '/tmp/radio-gate-tools'
let paths = (glob ($root | path join '*') | where {|p| ($p | path type) == 'file' and ($p | path parse | get extension) in [nu md json]} | append (glob ($root | path join logs '*') | where {|p| ($p | path type) == 'file'}))
let rows = ($paths | sort | each {|p| $'((sha $p))  ($p | path relative-to $root)'})
($rows | str join "\n") + "\n" | save ($root | path join PARENT-INSTALLED-SHA256SUMS)
print {payloads: ($rows | length), manifest_sha256: (sha ($root | path join PARENT-INSTALLED-SHA256SUMS))}

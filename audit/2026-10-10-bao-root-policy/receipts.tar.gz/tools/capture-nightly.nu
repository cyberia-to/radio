use /tmp/radio-bao-root-policy.rPXzYh/common.nu *
let root = '/tmp/radio-gate-tools'
let bin = '/Users/master/.rustup/toolchains/nightly-2025-10-09-aarch64-apple-darwin/bin'
mut rows = []
for name in [cargo rustc rustdoc] {
 let path = ($bin | path join $name)
 let args = if $name == rustc { ['-Vv'] } else { ['-V'] }
 let got = (required $root $'nightly-installed-($name)' ([$path] | append $args))
 $rows = ($rows | append {path: $path, sha256: (sha $path), version: $got})
}
$rows | to json | save ($root | path join nightly-binaries.json)

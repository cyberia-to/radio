use /tmp/radio-bao-root-policy.rPXzYh/common.nu *
def main [name: string, --args: string] {
    let run = $env.FILE_PWD
    let scaffold = '/tmp/radio-bao-root-policy.rPXzYh'
    let before = ((usage $run) + (usage $scaffold))
    if $before >= 20000000000 { error make {msg: '20GB staging limit; clean completed owned targets before next command'} }
    let configured = '/Users/master/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin'
    let environment = {
        PATH: ([($run | path join bin) $configured] | append $env.PATH)
        RUSTC: ($configured | path join rustc), RUSTDOC: ($configured | path join rustdoc)
        RUSTUP_TOOLCHAIN: '1.95.0', RUSTUP_AUTO_INSTALL: '0'
        CARGO_BUILD_JOBS: '4', CARGO_TARGET_DIR: ($run | path join target)
        CARGO_INSTALL_ROOT: $run
    }
    cd $run
    let result = (record $run $name ($args | from json) $environment)
    let after = ((usage $run) + (usage $scaffold))
    {before_bytes: $before, after_bytes: $after, limit_bytes: 30000000000}
        | to json | save ($run | path join logs $"($name).usage.json")
    if $after > 30000000000 { error make {msg: '30GB total budget exceeded; raw receipt retained'} }
    exit $result.exit_code
}

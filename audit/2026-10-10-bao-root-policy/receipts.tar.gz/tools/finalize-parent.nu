use /tmp/radio-bao-root-policy.rPXzYh/common.nu *
let run = '/tmp/radio-gate-tools'
let scaffold = '/tmp/radio-bao-root-policy.rPXzYh'
mut checks = []
for repository in [radio hemera] {
 let parent = ($scaffold | path join parent $repository)
 let candidate = ($scaffold | path join candidate $repository)
 let receipt = (open ($run | path join logs $'postcheck-($repository).json'))
 let got = {exit_code: $receipt.exit}
 if $got.exit_code != 0 { error make {msg: 'source changed'} }
 $checks = ($checks | append {repository: $repository, exit: $got.exit_code, target_exclusion: 'Nextest created only empty target/nextest subdirectories; build outputs are in explicit external CARGO_TARGET_DIR.'})
}
let extra = (^rg --files --hidden ($scaffold | path join parent radio target) | complete)
if $extra.stdout != '' or $extra.exit_code != 1 { error make {msg: 'unexpected files in local target'} }
let sources = (open ($scaffold | path join sources.json))
if (sha ($scaffold | path join parent radio Cargo.lock)) != $sources.lock_sha256 { error make {msg: 'lock changed'} }
mut receipts = []
for path in (glob ($run | path join logs '*.json') | where {|p| not ($p | str ends-with '.usage.json')}) {
 let row = (open $path)
 if ('stdout_sha256' in $row) {
  let stem = ($path | str replace --regex '\.json$' '')
  if (sha $'($stem).stdout') != $row.stdout_sha256 or (sha $'($stem).stderr') != $row.stderr_sha256 { error make {msg: $'receipt checksum mismatch: ($path)'} }
  $receipts = ($receipts | append {name: ($path | path basename), exit: $row.exit, sha256: (sha $path)})
 }
}
let gates = ([parent-make-format-installed parent-nextest-installed parent-deny-installed parent-nightly-docs-installed] | each {|name| open ($run | path join logs $'($name).json') | merge {name: $name}})
{recorded: (date now), sources: $sources, completed_parent_only: true, candidate_gates: [], gates: $gates, verified_receipts: $receipts, source_checks: $checks, advisory_db: (open ($run | path join advisory-db.json))} | to json | save ($run | path join parent-installed-gates.json)
print {receipts_verified: ($receipts | length), gate_exits: ($gates | select name exit)}

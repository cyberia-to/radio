use /tmp/radio-bao-root-policy.rPXzYh/common.nu *

let root = $env.FILE_PWD
cd $root
let rows = [
    {tool: nextest, archive: 'cargo-nextest-0.9.80-universal-apple-darwin.tar.gz', tag: 'cargo-nextest-0.9.80'},
    {tool: make, archive: 'cargo-make-v0.37.24-aarch64-apple-darwin.zip', tag: '0.37.24'},
    {tool: deny, archive: 'cargo-deny-0.18.9-aarch64-apple-darwin.tar.gz', tag: '0.18.9'},
]
mut evidence = []
for row in $rows {
    let release = (open ($root | path join downloads $"($row.tool)-release.json"))
    if $release.tag_name != $row.tag { error make {msg: 'unexpected release tag'} }
    let asset = ($release.assets | where name == $row.archive | first)
    let actual = (sha ($root | path join downloads $row.archive))
    let digest = ($asset.digest? | default '')
    if $digest != '' and $digest != $"sha256:($actual)" { error make {msg: 'GitHub asset digest mismatch'} }
    if $row.tool == deny {
        let expected = (open --raw ($root | path join downloads $"($row.archive).sha256") | str trim)
        if $actual != $expected { error make {msg: 'published cargo-deny checksum mismatch'} }
    }
    $evidence = ($evidence | append {tool: $row.tool, tag: $row.tag, archive: $row.archive,
        url: $asset.browser_download_url, sha256: $actual, github_digest: $digest,
        checksum_note: (if $digest == '' and $row.tool != deny { 'Official HTTPS release acquisition; no publisher digest in API metadata.' } else { 'Matches published digest.' })})
}
$evidence | to json | save ($root | path join archive-verification.json)
mkdir bin
required $root extract-nextest [tar -xzf downloads/cargo-nextest-0.9.80-universal-apple-darwin.tar.gz -C bin cargo-nextest] | ignore
required $root extract-make [unzip -j downloads/cargo-make-v0.37.24-aarch64-apple-darwin.zip cargo-make-v0.37.24-aarch64-apple-darwin/cargo-make cargo-make-v0.37.24-aarch64-apple-darwin/makers -d bin] | ignore
required $root extract-deny [tar -xzf downloads/cargo-deny-0.18.9-aarch64-apple-darwin.tar.gz -C bin --strip-components '1' cargo-deny-0.18.9-aarch64-apple-darwin/cargo-deny] | ignore
for item in [{binary: cargo-nextest, args: [nextest --version]}, {binary: cargo-make, args: [make --version]}, {binary: cargo-deny, args: [deny --version]}] {
    let path = ($root | path join bin $item.binary)
    let output = (required $root $"version-($item.binary)" ([$path] | append $item.args))
    {binary: $path, sha256: (sha $path), version: ($output | str trim)} | to json | save ($root | path join $"($item.binary)-version.json")
}

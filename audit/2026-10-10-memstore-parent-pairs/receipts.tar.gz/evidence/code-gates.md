# Parent-pair repair: executed gates

Radio base0d11468503c052aa5dcefb0dabc4602bd8efdc60; Hemera23f3bbcff910ea6d504ceb505680a539260869da.
Candidate is the6-file local source freeze SHA256 d7c6cc1560eeeadc1b0c880cca79a3e2b09a2379489bac37706b0603db7069ca.
Earlier gates used freeze1649829898538dffa626d81dc83be4fcc7deddb137a188f64dd277a3b0b414dd; final freeze changes only one new-test import position to satisfy the named formatter. All production and fixture bytes are identical (format-refreeze.json). Final-byte tests/witnesses have explicit final receipt names.
Commands below use actual pinned Cargo/RUSTC/RUSTDOC, four build jobs, isolated targets and unchanged committed Cargo.lock.
Ordinary1.95.0; MSRV1.89.0; CI docs nightly2025-10-09. RUSTFLAGS=-Dwarnings; strict docs -Dwarnings; named CI docs --cfg docsrs.
Tool argv/env/times/exits and full raw stdout/stderr are retained beside each receipt under logs/. This summary is not a release/ring1 pass.

## Exact-parent failure-first and candidate checks

The witness overlays only the cfg(test) module and the exact final test/fixture bytes. Debug/release each executed11 tests:2 controls passed,9 failed.
Both original writers visibly panic on32→64 copy; public workflows fail as ordinary tests. No timeout was used to turn those failures into success.
Only synchronous print96 uses exact-assert should_panic. Existing reader-short and parent-free controls pass on the parent.

The PLAN predicted reader_partial_memory might improve. Actual candidate execution still fails on its first empty input (importing8bytes / invalid size for hash), before parent proofs. That predicted green flip is retracted; the new public witnesses cover the repaired paths directly. Hash::EMPTY remains a separate repair.

## Command receipts

- `candidate-bao-all` — exit0; `cargo test -p cyber-bao --all-features --locked --offline`.
  test result: ok. 71 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.21s
  test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 4.21s
  test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.09s
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
- `candidate-consumers-no-run` — exit101; `cargo test -p radio-cli -p radio-integration-tests --all-features --no-run --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `candidate-focused-timeouts-t1-v2` — exit0; `cargo nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --no-fail-fast --test-threads 1 --profile default -E test\(\=api::downloader::tests::downloader_get_all\)\ \|\ test\(\=api::downloader::tests::downloader_get_smoke\)\ \|\ test\(\=store::fs::import::tests::smoke\)\ \|\ test\(\=store::fs::tests::test_export_path\)\ \|\ test\(\=store::fs::tests::test_import_byte_stream\)\ \|\ test\(\=store::fs::tests::test_import_bytes_persistence_full\)\ \|\ test\(\=store::fs::tests::test_import_bytes_simple\)\ \|\ test\(\=store::fs::tests::test_import_path\)\ \|\ test\(\=util::connection_pool::tests::connection_pool_idle\)\ \|\ test\(\=util::connection_pool::tests::connection_pool_smoke\) --locked --offline`.
  Summary [ 202.925s] 10 tests run: 10 passed (8 slow), 116 skipped
- `candidate-focused-two` — exit100; `cargo nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --no-fail-fast --test-threads 1 --profile default -E test\(\=store::fs::tests::smoke\)\ \|\ test\(\=tests::two_nodes_observe_mem\) --locked --offline`.
  Summary [  51.967s] 2 tests run: 0 passed, 1 failed, 1 timed out, 124 skipped
  First diagnostic: error: iroh_blobs::api::RequestError - inner error: Error::Io: Error::Io: invalid size for hash
- `candidate-format-final` — exit1; `cargo fmt --all -- --check`.
- `candidate-format` — exit1; `cargo fmt --all -- --check`.
- `candidate-metadata` — exit0; `cargo metadata --format-version 1 --locked --offline`.
- `candidate-msrv-export` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --all-features --locked --offline`.
  test result: ok. 14 passed; 0 failed; 0 ignored; 0 measured; 112 filtered out; finished in 0.39s
- `candidate-msrv-native-check` — exit101; `cargo check --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline`.
  First diagnostic: error[E0277]: the trait bound `EndpointTicket: From<EndpointAddr>` is not satisfied
- `candidate-msrv-pairs` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline`.
  test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 115 filtered out; finished in 1.37s
- `candidate-msrv-workspace-check` — exit101; `cargo check --workspace --all-targets --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `candidate-named-clippy-all` — exit101; `cargo clippy --workspace --all-features --all-targets --lib --bins --tests --benches --examples --locked --offline`.
  First diagnostic: error: using `clone` on type `Hash` which implements the `Copy` trait
- `candidate-named-clippy-default` — exit101; `cargo clippy --workspace --all-targets --lib --bins --tests --benches --examples --locked --offline`.
  First diagnostic: error: using `clone` on type `Hash` which implements the `Copy` trait
- `candidate-named-clippy-none` — exit101; `cargo clippy --workspace --no-default-features --all-targets --lib --bins --tests --benches --examples --locked --offline`.
  First diagnostic: error: using `clone` on type `Hash` which implements the `Copy` trait
- `candidate-named-deny` — exit13; `cargo deny --workspace --all-features --locked check --disable-fetch -Dwarnings`.
  First diagnostic: error[source-not-allowed]: detected 'git' source not explicitly allowed
- `candidate-named-format-final` — exit105; `cargo make --disable-check-for-updates format-check`.
- `candidate-named-format` — exit105; `cargo make --disable-check-for-updates format-check`.
- `candidate-named-nextest-all` — exit101; `cargo nextest run --workspace --all-features --lib --bins --tests --no-run --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `candidate-named-nextest-default` — exit101; `cargo nextest run --workspace --lib --bins --tests --no-run --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `candidate-named-nextest-none` — exit101; `cargo nextest run --workspace --no-default-features --lib --bins --tests --no-run --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `candidate-named-nightly-docs` — exit101; `cargo doc --workspace --all-features --no-deps --document-private-items --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `candidate-native-clippy` — exit101; `cargo clippy --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline -- -D warnings`.
  First diagnostic: error: using `clone` on type `Hash` which implements the `Copy` trait
- `candidate-native-doc` — exit0; `cargo doc --manifest-path iroh-blobs/Cargo.toml --all-features --no-deps --locked --offline`.
- `candidate-native-export-all` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --all-features --locked --offline`.
  test result: ok. 14 passed; 0 failed; 0 ignored; 0 measured; 112 filtered out; finished in 1.01s
- `candidate-native-export-default` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --locked --offline`.
  test result: ok. 14 passed; 0 failed; 0 ignored; 0 measured; 112 filtered out; finished in 0.98s
- `candidate-native-nextest` — exit100; `cargo nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --no-fail-fast --test-threads 4 --locked --offline`.
  Summary [ 233.974s] 124 tests run: 83 passed (5 slow), 25 failed, 16 timed out, 2 skipped
  First diagnostic: error: iroh_blobs::api::RequestError - inner error: Error::Io: Error::Io: invalid size for hash
- `candidate-native-root-policy` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --all-features --locked --offline`.
  test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 121 filtered out; finished in 0.43s
- `candidate-native-smoke` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib store::mem::tests::smoke --all-features --locked --offline`.
  test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 125 filtered out; finished in 0.35s
- `candidate-observe60-diagnostic` — exit0; `cargo nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --no-fail-fast --test-threads 1 --profile default --config-file /tmp/radio-memstore-pairs.pJDTXk/observe-60.nextest.toml -E test\(\=tests::two_nodes_observe_mem\) --locked --offline`.
- `candidate-pairs-all-final` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline`.
  test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 115 filtered out; finished in 1.36s
- `candidate-pairs-all` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline`.
  test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 115 filtered out; finished in 1.74s
- `candidate-pairs-default` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --locked --offline`.
  test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 115 filtered out; finished in 1.90s
- `candidate-pairs-none-final` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --no-default-features --locked --offline`.
  test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 56 filtered out; finished in 0.86s
- `candidate-pairs-none` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --no-default-features --locked --offline`.
  test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 56 filtered out; finished in 1.10s
- `candidate-pairs-release-final` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --release --all-features --locked --offline`.
  test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 115 filtered out; finished in 0.22s
- `candidate-pairs-release` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --release --all-features --locked --offline`.
  test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 115 filtered out; finished in 0.36s
- `candidate-semver-parent-iroh-blobs` — exit0; `cargo semver-checks check-release --manifest-path iroh-blobs/Cargo.toml --baseline-root /tmp/radio-memstore-pairs.pJDTXk/semver/parent/radio/iroh-blobs --verbose`.
  Checked [   0.029s] 202 checks: 202 pass, 58 skip
  Summary no semver update required
- `candidate-semver-tag-iroh-blobs` — exit0; `cargo semver-checks check-release --manifest-path iroh-blobs/Cargo.toml --baseline-root /tmp/radio-memstore-pairs.pJDTXk/semver/tag/radio/iroh-blobs --verbose`.
  Checked [   0.026s] 202 checks: 202 pass, 58 skip
  Summary no semver update required
- `candidate-three-fixture` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs::three_group_nonzero_parent_ordinal --all-features --locked --offline`.
  test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 125 filtered out; finished in 2.17s
- `candidate-workspace-no-run` — exit101; `cargo test --workspace --no-run --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `parent-consumers-no-run` — exit101; `cargo test -p radio-cli -p radio-integration-tests --all-features --no-run --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `parent-focused-timeouts-t1-v2` — exit0; `cargo nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --no-fail-fast --test-threads 1 --profile default -E test\(\=api::downloader::tests::downloader_get_all\)\ \|\ test\(\=api::downloader::tests::downloader_get_smoke\)\ \|\ test\(\=store::fs::import::tests::smoke\)\ \|\ test\(\=store::fs::tests::test_export_path\)\ \|\ test\(\=store::fs::tests::test_import_byte_stream\)\ \|\ test\(\=store::fs::tests::test_import_bytes_persistence_full\)\ \|\ test\(\=store::fs::tests::test_import_bytes_simple\)\ \|\ test\(\=store::fs::tests::test_import_path\)\ \|\ test\(\=util::connection_pool::tests::connection_pool_idle\)\ \|\ test\(\=util::connection_pool::tests::connection_pool_smoke\) --locked --offline`.
  Summary [ 211.077s] 10 tests run: 10 passed (9 slow), 105 skipped
- `parent-focused-two` — exit100; `cargo nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --no-fail-fast --test-threads 1 --profile default -E test\(\=store::fs::tests::smoke\)\ \|\ test\(\=tests::two_nodes_observe_mem\) --locked --offline`.
  Summary [  36.519s] 2 tests run: 0 passed, 2 failed, 113 skipped
  First diagnostic: error: iroh_blobs::api::RequestError - inner error: Error::Io: Error::Io: invalid size for hash
- `parent-format` — exit1; `cargo fmt --all -- --check`.
- `parent-metadata` — exit0; `cargo metadata --format-version 1 --locked --offline`.
- `parent-msrv-export` — exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --all-features --locked --offline`.
  test result: ok. 14 passed; 0 failed; 0 ignored; 0 measured; 101 filtered out; finished in 0.41s
- `parent-msrv-native-check` — exit101; `cargo check --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline`.
  First diagnostic: error[E0277]: the trait bound `EndpointTicket: From<EndpointAddr>` is not satisfied
- `parent-msrv-workspace-check` — exit101; `cargo check --workspace --all-targets --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `parent-named-clippy-all` — exit101; `cargo clippy --workspace --all-features --all-targets --lib --bins --tests --benches --examples --locked --offline`.
  First diagnostic: error: using `clone` on type `Hash` which implements the `Copy` trait
- `parent-named-clippy-default` — exit101; `cargo clippy --workspace --all-targets --lib --bins --tests --benches --examples --locked --offline`.
  First diagnostic: error: using `clone` on type `Hash` which implements the `Copy` trait
- `parent-named-clippy-none` — exit101; `cargo clippy --workspace --no-default-features --all-targets --lib --bins --tests --benches --examples --locked --offline`.
  First diagnostic: error: using `clone` on type `Hash` which implements the `Copy` trait
- `parent-named-deny` — exit13; `cargo deny --workspace --all-features --locked check --disable-fetch -Dwarnings`.
  First diagnostic: error[no-license-field]: license expression was not specified in manifest for crate 'cyber-hemera = 0.3.1'
- `parent-named-format` — exit105; `cargo make --disable-check-for-updates format-check`.
- `parent-named-nextest-all` — exit101; `cargo nextest run --workspace --all-features --lib --bins --tests --no-run --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `parent-named-nextest-default` — exit101; `cargo nextest run --workspace --lib --bins --tests --no-run --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `parent-named-nextest-none` — exit101; `cargo nextest run --workspace --no-default-features --lib --bins --tests --no-run --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `parent-named-nightly-docs` — exit101; `cargo doc --workspace --all-features --no-deps --document-private-items --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `parent-native-clippy` — exit101; `cargo clippy --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline -- -D warnings`.
  First diagnostic: error: using `clone` on type `Hash` which implements the `Copy` trait
- `parent-native-doc` — exit0; `cargo doc --manifest-path iroh-blobs/Cargo.toml --all-features --no-deps --locked --offline`.
- `parent-native-nextest` — exit100; `cargo nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --no-fail-fast --test-threads 4 --locked --offline`.
  Summary [ 118.797s] 113 tests run: 82 passed (8 slow), 27 failed, 4 timed out, 2 skipped
  First diagnostic: error: iroh_blobs::api::RequestError - inner error: Error::Io: Error::Io: invalid size for hash
- `parent-workspace-no-run` — exit101; `cargo test --workspace --no-run --locked --offline`.
  First diagnostic: error[E0053]: method `find_providers` has an incompatible type for trait
- `tool-nightly-cargo` — exit0; `cargo --version`.
- `version-1.89.0-cargo` — exit0; `cargo -Vv`.
- `version-1.95.0-cargo` — exit0; `cargo -Vv`.
- `witness-pairs-debug-final` — exit101; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline`.
  test result: FAILED. 2 passed; 9 failed; 0 ignored; 0 measured; 115 filtered out; finished in 0.56s
  First diagnostic: error: test failed, to rerun pass `--lib`
- `witness-pairs-debug-v1` — exit101; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline`.
  test result: FAILED. 2 passed; 9 failed; 0 ignored; 0 measured; 115 filtered out; finished in 0.68s
  First diagnostic: error: test failed, to rerun pass `--lib`
- `witness-pairs-release-final` — exit101; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline --release`.
  test result: FAILED. 2 passed; 9 failed; 0 ignored; 0 measured; 115 filtered out; finished in 0.10s
  First diagnostic: error: test failed, to rerun pass `--lib`
- `witness-pairs-release-v1` — exit101; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --release --locked --offline`.
  test result: FAILED. 2 passed; 9 failed; 0 ignored; 0 measured; 115 filtered out; finished in 0.10s
  First diagnostic: error: test failed, to rerun pass `--lib`

## Exact current-parent / candidate native test comparison

- iroh-blobs api::downloader::tests::downloader_get_all: PASS → TIMEOUT.
- iroh-blobs api::downloader::tests::downloader_get_smoke: PASS → TIMEOUT.
- iroh-blobs store::fs::import::tests::smoke: PASS → TIMEOUT.
- iroh-blobs store::fs::tests::smoke: FAIL → TIMEOUT.
- iroh-blobs store::fs::tests::test_export_path: PASS → TIMEOUT.
- iroh-blobs store::fs::tests::test_import_byte_stream: PASS → TIMEOUT.
- iroh-blobs store::fs::tests::test_import_bytes_persistence_full: PASS → TIMEOUT.
- iroh-blobs store::fs::tests::test_import_bytes_simple: PASS → TIMEOUT.
- iroh-blobs store::fs::tests::test_import_path: PASS → TIMEOUT.
- iroh-blobs store::mem::parent_pairs::corrupted_leaf_rejected_then_valid_retry: absent → PASS.
- iroh-blobs store::mem::parent_pairs::corrupted_parent_rejected_then_valid_retry: absent → PASS.
- iroh-blobs store::mem::parent_pairs::diagnostic_one_pair: absent → PASS.
- iroh-blobs store::mem::parent_pairs::diagnostic_rejects_partial_pair: absent → PASS.
- iroh-blobs store::mem::parent_pairs::diagnostic_two_pairs: absent → PASS.
- iroh-blobs store::mem::parent_pairs::fs_complete_memory_batch_and_reopen: absent → PASS.
- iroh-blobs store::mem::parent_pairs::literal_pair_storage: absent → PASS.
- iroh-blobs store::mem::parent_pairs::parent_free_control: absent → PASS.
- iroh-blobs store::mem::parent_pairs::right_partial_then_complete_and_repeat: absent → PASS.
- iroh-blobs store::mem::parent_pairs::short_pair_reader_error: absent → PASS.
- iroh-blobs store::mem::parent_pairs::three_group_nonzero_parent_ordinal: absent → PASS.
- iroh-blobs tests::two_nodes_observe_mem: FAIL → TIMEOUT.
- iroh-blobs util::connection_pool::tests::connection_pool_idle: PASS → TIMEOUT.
- iroh-blobs util::connection_pool::tests::connection_pool_smoke: PASS → TIMEOUT.

Remaining candidate non-pass results:
- FAIL iroh-blobs api::blobs::reader::tests::reader_partial_memory
- FAIL iroh-blobs api::blobs::reader::tests::reader_partial_fs
- FAIL iroh-blobs api::remote::tests::test_local_info_complex_request
- FAIL iroh-blobs api::remote::tests::test_local_info_hash_seq_large
- FAIL iroh-blobs api::remote::tests::test_observe_partial_fs
- FAIL iroh-blobs api::remote::tests::test_observe_partial_mem
- FAIL iroh-blobs protocol::builder::tests::chunk_ranges_ext
- FAIL iroh-blobs protocol::tests::request_wire_format
- TIMEOUT iroh-blobs api::downloader::tests::downloader_get_all
- TIMEOUT iroh-blobs api::downloader::tests::downloader_get_smoke
- FAIL iroh-blobs api::remote::tests::test_local_info_hash_seq
- FAIL iroh-blobs store::fs::tests::test_import_bao_persistence_full
- FAIL iroh-blobs store::fs::tests::test_import_bao_persistence_just_size
- FAIL iroh-blobs store::fs::tests::test_import_bao_persistence_observe
- FAIL iroh-blobs store::fs::tests::test_import_bao_persistence_recover
- FAIL iroh-blobs store::fs::tests::test_import_bao_persistence_two_stages
- TIMEOUT iroh-blobs store::fs::import::tests::smoke
- TIMEOUT iroh-blobs store::fs::tests::smoke
- TIMEOUT iroh-blobs store::fs::tests::test_export_path
- TIMEOUT iroh-blobs store::fs::tests::test_import_bao_ranges
- TIMEOUT iroh-blobs store::fs::tests::test_import_byte_stream
- FAIL iroh-blobs store::fs::tests::test_observe
- TIMEOUT iroh-blobs store::fs::tests::test_import_bytes_persistence_full
- TIMEOUT iroh-blobs store::fs::tests::test_import_bytes_simple
- TIMEOUT iroh-blobs store::fs::tests::test_import_path
- FAIL iroh-blobs store::gc::tests::gc_smoke_fs
- FAIL iroh-blobs tests::node_serve_blobs
- FAIL iroh-blobs tests::node_serve_hash_seq
- FAIL iroh-blobs tests::two_nodes_get_blobs_mem
- FAIL iroh-blobs tests::two_nodes_get_blobs_fs
- FAIL iroh-blobs tests::two_nodes_get_many_fs
- FAIL iroh-blobs tests::two_nodes_get_many_mem
- FAIL iroh-blobs tests::two_nodes_hash_seq_fs
- FAIL iroh-blobs tests::two_nodes_hash_seq_progress
- FAIL iroh-blobs tests::two_nodes_hash_seq_mem
- TIMEOUT iroh-blobs tests::two_nodes_observe_fs
- TIMEOUT iroh-blobs tests::two_nodes_observe_mem
- TIMEOUT iroh-blobs tests::two_nodes_push_blobs_fs
- TIMEOUT iroh-blobs tests::two_nodes_push_blobs_mem
- TIMEOUT iroh-blobs util::connection_pool::tests::connection_pool_idle
- TIMEOUT iroh-blobs util::connection_pool::tests::connection_pool_smoke

Full per-test panic/error text is preserved in nextest-failure-details.json; statuses alone are not diagnostic parity.


## Limits

Broad formatter/Clippy/dependency/compiler/deny findings stay red; masked new-test Clippy is not certified.
Cargo archive build scripts report missing Git worktree/VERGEN default warnings; command success is not a zero-warning claim.
Persisted incomplete checkpoint checksum/recovery, Hash::EMPTY, actor lifecycle, bounded proof budgets and particle/root authority remain separate.
Setup-only corrections retained: witness guard initially expected equivalent cfg hunk lines in the wrong order; explicit byte verifier then passed. Direct cargo-make --version exited1; cargo-make make --version and the named actual gate use the correct interface.
The temporary sequential runner initially propagated the already-recorded candidate nightly exit101 before proceeding; its docs wrapper was corrected to consume the status, and execution resumed after that receipt. No gate or receipt was repeated or overwritten.
Focused setup first rejected a Nu interpolated literal, then ps received split field names and exited1 before Cargo. The corrected v2 attempt has its own complete machine observations and real test receipts; setup failures are not product results.
Last-tag semver uses the explicitly pinned current Hemera path with scratch resolution, not a historical release closure.

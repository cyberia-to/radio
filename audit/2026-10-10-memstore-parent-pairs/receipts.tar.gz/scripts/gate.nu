use common.nu *
def main [--scope: string, --name: string, --toolchain: string = '1.95.0', --execute, --clean-completed, --ci-docs, --args: string = '[]'] {
    let run = $env.FILE_PWD
    if $scope not-in [parent candidate witness] or $name == null or not ($name =~ '^[a-zA-Z0-9_-]+$') {
        error make {msg: 'explicit parent/candidate scope and unique safe receipt name required'}
    }
    if $toolchain not-in ['1.95.0' '1.89.0' 'nightly-2025-10-09'] { error make {msg: 'unpinned toolchain'} }
    let cargo_args = ($args | from json)
    if not (($cargo_args | describe) | str starts-with 'list') or not ($cargo_args | all {|arg| ($arg | describe) == 'string' }) {
        error make {msg: '--args must be a JSON array of strings'}
    }
    let configured = if $toolchain == 'nightly-2025-10-09' {
        [cargo rustc rustdoc] | each {|name| {name: $name, path: $'/Users/master/.rustup/toolchains/($toolchain)-aarch64-apple-darwin/bin/($name)'}}
    } else { open ($run | path join toolchains.json) | where version == $toolchain | first | get binaries }
    let cargo = ($configured | where name == cargo | first | get path)
    let rustc = ($configured | where name == rustc | first | get path)
    let rustdoc = ($configured | where name == rustdoc | first | get path)
    let target = ($run | path join targets (if $ci_docs { $'($scope)-nightly-docs' } else { $scope }))
    let inputs = (open ($run | path join sources.json))
    let environment = {PATH: (['/tmp/radio-gate-tools/bin' ($cargo | path dirname)] | append $env.PATH), RUSTC: $rustc, RUSTDOC: $rustdoc,
        RUSTUP_TOOLCHAIN: $toolchain, RUSTUP_AUTO_INSTALL: '0', RUSTFLAGS: '-Dwarnings',
        RUSTDOCFLAGS: (if $ci_docs { '--cfg docsrs' } else { '-Dwarnings' }),
        CARGO_BUILD_JOBS: '4', CARGO_TARGET_DIR: $target, CARGO_NET_OFFLINE: 'true'}
    let args = if $clean_completed { [clean --target-dir $target] } else { $cargo_args }
    if ($args | is-empty) { error make {msg: 'cargo command required through --args JSON, or --clean-completed'} }
    if $clean_completed and not ($cargo_args | is-empty) { error make {msg: 'clean accepts no cargo arguments'} }
    if not $execute { print ({argv: ([$cargo] | append $args), environment: $environment, cwd: ($run | path join $scope radio)} | to json); return }
    # Invoke one gate at a time. Clean completed scopes before switching expensive builds.
    let before = ((usage $run) + (usage '/tmp/radio-gate-tools'))
    if $before >= 20000000000 and not $clean_completed { error make {msg: '20GB staging threshold: clean a completed owned target before another gate; total budget is30GB'} }
    cd ($run | path join $scope radio)
    if (sha Cargo.lock) != $inputs.lock_sha256 { error make {msg: 'lock drift before gate'} }
    let result = (record $run $"($scope)-($name)" ([$cargo] | append $args) $environment)
    let after = ((usage $run) + (usage '/tmp/radio-gate-tools'))
    {before_bytes: $before, after_bytes: $after, target: $target, limit_bytes: 30000000000}
        | to json | save ($run | path join logs $"($scope)-($name).usage.json")
    if (sha Cargo.lock) != $inputs.lock_sha256 { error make {msg: 'lock drift after gate; raw result retained'} }
    if $after > 30000000000 { error make {msg: 'disk budget exceeded; stop and clean only completed owned targets; raw result retained'} }
    exit $result.exit_code
}

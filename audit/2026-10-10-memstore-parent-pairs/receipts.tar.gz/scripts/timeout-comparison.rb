require 'json'
require 'digest'

root = File.dirname(__FILE__)
def outcomes(root, name)
  path = root + '/logs/' + name + '.stderr'
  return {} unless File.exist?(path)
  File.read(path).lines.each_with_object({}) do |line, rows|
    if (m = line.match(/^\s*(PASS|FAIL|TIMEOUT)\s+\[\s*([\d.]+)s\]\s+iroh-blobs\s+(\S+)/))
      rows[m[3]] = {status: m[1], seconds: m[2]}
    end
  end
end
comparison = JSON.parse(File.read(root + '/nextest-comparison.json'))
details = JSON.parse(File.read(root + '/nextest-failure-details.json'))
common_failures = comparison.select { |r| r['parent'] == 'FAIL' && r['candidate'] == 'FAIL' }
raise 'common failure count changed' unless common_failures.length == 25
common_failures.each do |row|
  name = row.fetch('name').delete_prefix('iroh-blobs ')
  raise "common error text changed: #{name}" unless details.fetch('parent')[name] && details.fetch('parent')[name] == details.fetch('candidate')[name]
end
selected = comparison.select { |r| r['parent'] == 'PASS' && r['candidate'] == 'TIMEOUT' }.map { |r| r.fetch('name').delete_prefix('iroh-blobs ') }
parent = outcomes(root, 'parent-focused-timeouts-t1-v2')
candidate = outcomes(root, 'candidate-focused-timeouts-t1-v2')
raise 'focused selection drift' unless selected.length == 10 && parent.keys.sort == selected.sort && candidate.keys.sort == selected.sort
lines = [
 '# Focused timeout diagnosis', '',
 'Radio exact parent0d11468503c052aa5dcefb0dabc4602bd8efdc60; candidate final freeze d7c6cc1560eeeadc1b0c880cca79a3e2b09a2379489bac37706b0603db7069ca. Production bytes match the initial candidate; only one test import moved.',
 'Original bounded native nextest: parent113 run,82 pass,27 fail,4 timeout,2 skip; candidate124 run,83 pass,25 fail,16 timeout,2 skip. Both exited100. Status changes:10 PASS→TIMEOUT,2 FAIL→TIMEOUT,11 new PASS;25 common FAIL,4 common TIMEOUT,72 common PASS. Original receipts are retained unchanged.',
 'Focused commands use the same Rust1.95.0/source closure, four build jobs, nextest0.9.80, --test-threads1 --profile default with committed slow-timeout period10s/terminate-after3. The -E expression selects exactly the ten names below; full argv/env and before/after clock,disk,vm_stat,load,process observations are in logs/{parent,candidate}-focused-timeouts-t1-v2.*. No timeout extension or entire-suite rerun.', '',
 '| Selected existing test | Parent serial | Candidate serial |',
 '|---|---:|---:|'
]
selected.each do |name|
  p = parent.fetch(name); c = candidate.fetch(name)
  lines << "| #{name} | #{p[:status]} #{p[:seconds]}s | #{c[:status]} #{c[:seconds]}s |"
end
lines += ['',
 'Both focused commands exited0: parent10/10 pass in211.077s (9 slow), candidate10/10 in202.925s (8 slow). Selected-test CPU activity was sampled in parent-focused-mid/candidate-focused-mid receipts. Before these runs disk snapshots showed48GiB/45GiB free and load averages2.80/2.61 (1-minute). Initial broad-run machine load was not captured, so no causal attribution to contention, disk or networking is established.',
 'These focused results do not reproduce a functional hang in the selected cases. The29.098s candidate FS import is close to the unchanged30s bound. Original concurrent failures remain red; neither uniform performance nor entire-suite parity is claimed.', '',
 'The two other transitions are distinct: parent fs::tests::smoke eventually reports invalid size for hash after large imports; parent tests::two_nodes_observe_mem hits the repaired32→64 mem.rs copy panic and Sender closed. Focused serial outcomes follow when recorded:', ''
]
%w[parent candidate].each do |scope|
  values = outcomes(root, scope + '-focused-two')
  values.each { |name, value| lines << "- #{scope} #{name}: #{value[:status]} #{value[:seconds]}s." }
end
if File.exist?(root + '/logs/candidate-observe60-diagnostic.json')
  value = outcomes(root, 'candidate-observe60-diagnostic').fetch('tests::two_nodes_observe_mem')
  lines += ['', "The separately authorized one-shot candidate-only60s diagnostic completed #{value[:status]} in#{value[:seconds]}s: 1.851s beyond the original30s boundary. Its out-of-tree full config copy changes only terminate-after3→6 (observe-60-config.json), with --test-threads1 and the exact test filter. This is diagnostic evidence of completion, not a replacement for the red named gate.",
    'No near30s CPU/stack sample was obtained in this run: process checks first found compilation active, then found the test had already exited. No sample command executed. The dedicated run was not repeated. Before/after machine observations and exact argv/result remain in candidate-observe60-* receipts.']
end
lines += ['', 'The original25 common failed-test stderr bodies match after thread-ID normalization. The common test_import_bao_ranges timeout exposes the same separate checksum copy panic at util.rs227→237; the line shift comes from the inserted helper. Full per-test error text remains in nextest-failure-details.json and raw native-nextest logs.', '']
File.write(root + '/timeout-diagnostic.md', lines.join("\n"))
puts "timeout-diagnostic.md #{File.size(root + '/timeout-diagnostic.md')} bytes #{Digest::SHA256.file(root + '/timeout-diagnostic.md').hexdigest}"

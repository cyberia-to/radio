use common.nu *
def gate [run: path, scope: string, name: string, args: list<string>, green: bool = false] {
 let result = (^nu ($run | path join gate.nu) --scope $scope --name $name --execute --args ($args | to json --raw) | complete)
 print $result.stdout
 if $result.stderr != '' { print --stderr $result.stderr }
 let path = ($run | path join logs $'($scope)-($name).json')
 if not ($path | path exists) { error make {msg: 'missing gate receipt'} }
 if $green and (open $path | get exit) != 0 { error make {msg: 'required scoped green gate failed'} }
}
def clean [run: path, scope: string, suffix: string] {
 ^nu ($run | path join clean-scope.nu) $scope $suffix
 if $env.LAST_EXIT_CODE != 0 { error make {msg: 'cleanup wrapper failed'} }
}
def main [] {
 let run = $env.FILE_PWD
 if not ($run | path join logs candidate-focused-timeouts-t1-v2.json | path exists) { error make {msg: 'focused candidate command must finish first'} }
 let expression = 'test(=store::fs::tests::smoke) | test(=tests::two_nodes_observe_mem)'
 for scope in [parent candidate] {
  ^nu ($run | path join observe.nu) $'($scope)-focused-two-before'
  gate $run $scope focused-two [nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --no-fail-fast --test-threads '1' --profile default -E $expression --locked --offline]
  ^nu ($run | path join observe.nu) $'($scope)-focused-two-after'
 }
 gate $run candidate format-final [fmt --all -- --check]
 gate $run candidate named-format-final [make --disable-check-for-updates format-check]
 gate $run candidate pairs-all-final [test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline] true
 gate $run candidate pairs-none-final [test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --no-default-features --locked --offline] true
 gate $run candidate pairs-release-final [test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --release --all-features --locked --offline] true
 clean $run candidate after-final-tests
 clean $run parent after-focused-tests
 for release in [false true] {
  let args = [test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline]
  let args = if $release { $args | append ['--release'] } else { $args }
  gate $run witness (if $release { 'pairs-release-final' } else { 'pairs-debug-final' }) $args
 }
 clean $run witness after-final-witness
 let docs = (^nu ($run | path join nightly.nu) parent | complete)
 print $docs.stdout
 if $docs.stderr != '' { print --stderr $docs.stderr }
 if not ($run | path join logs parent-named-nightly-docs.json | path exists) { error make {msg: 'missing parent nightly receipt'} }
 clean $run parent after-nightly-final
 ^nu ($run | path join candidate-semver.nu)
 if $env.LAST_EXIT_CODE != 0 { error make {msg: 'semver wrapper failed'} }
}

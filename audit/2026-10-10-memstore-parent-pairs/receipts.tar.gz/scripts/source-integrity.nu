use common.nu *
let run = $env.FILE_PWD
let freeze = (open ($run | path join source-freeze.json))
for item in $freeze {
    for root in [($run | path join candidate radio) /Users/master/cyber/radio-kadek-memstore-pairs] {
        if (sha ($root | path join $item.path)) != $item.sha256 { error make {msg: $'source drift: ($item.path)'} }
    }
}
let comparison = (record $run source-closure-diff [diff -qr ($run | path join parent radio) ($run | path join candidate radio)])
if $comparison.exit_code != 1 { error make {msg: 'expected candidate delta'} }
required $run hemera-closure-equality [diff -qr ($run | path join parent hemera) ($run | path join candidate hemera)] | ignore
required $run source-diff-check [git -C /Users/master/cyber/radio-kadek-memstore-pairs diff --check] | ignore
{files: $freeze, lock_sha256: (sha ($run | path join candidate radio Cargo.lock)), golden_original_sha256: (sha ($run | path join candidate radio audit/2026-10-09-kadek-export-pairs/right-proof.bin)), note: 'Full source delta retained for independent whitelist review; same exact committed Hemera closure. Local candidate only.'} | to json | save ($run | path join source-integrity.json)

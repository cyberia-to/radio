use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let owned = '/Users/master/cyber/radio-kadek-memstore-pairs'
 let marker = "#[cfg(test)]\nmod parent_pairs;\n\n"
 let parent = (open --raw ($run | path join parent radio iroh-blobs/src/store/mem.rs))
 let witness = (open --raw ($run | path join witness radio iroh-blobs/src/store/mem.rs))
 if ($witness | split row $marker | length) != 2 or ($witness | str replace $marker '') != $parent {
  error make {msg: 'witness mem.rs is not exact parent plus one test declaration'}
 }
 let fixture_paths = [iroh-blobs/src/store/mem/parent_pairs.rs iroh-blobs/src/store/mem/parent_pairs/fixtures.rs iroh-blobs/src/store/mem/parent_pairs/right-proof.bin]
 let fixture_hashes = ($fixture_paths | each {|path|
  let digest = (sha ($owned | path join $path))
  if (sha ($run | path join witness radio $path)) != $digest { error make {msg: 'final witness fixture drift'} }
  {path: $path, sha256: $digest}
 })
 for path in [iroh-blobs/src/store/util.rs iroh-blobs/src/store/util/partial_mem_storage.rs Cargo.lock] {
  if (sha ($run | path join parent radio $path)) != (sha ($run | path join witness radio $path)) { error make {msg: 'unexpected witness production drift'} }
 }
 {base_revision: '0d11468503c052aa5dcefb0dabc4602bd8efdc60', test_files: $fixture_hashes,
  parent_mem_sha256: (sha ($run | path join parent radio iroh-blobs/src/store/mem.rs)),
  witness_mem_sha256: (sha ($run | path join witness radio iroh-blobs/src/store/mem.rs)),
  mem_change: 'Exactly one cfg(test) module declaration; all other bytes equal exact parent.',
  production_check: 'util.rs, partial_mem_storage.rs and lock exactly match parent; no repaired serializer in witness.',
  final_candidate_manifest_sha256: (sha ($run | path join source-freeze.json))}
  | to json | save ($run | path join witness-final-overlay.json)
}

def main [scope: string] {
 let run = $env.FILE_PWD
 ^nu ($run | path join gate.nu) --scope $scope --name named-nightly-docs --toolchain nightly-2025-10-09 --ci-docs --execute --args '["doc","--workspace","--all-features","--no-deps","--document-private-items","--locked","--offline"]'
 exit $env.LAST_EXIT_CODE
}

use common.nu *
let run = $env.FILE_PWD
let owned = '/Users/master/cyber/radio-kadek-memstore-pairs'
let paths = [iroh-blobs/src/store/mem.rs iroh-blobs/src/store/mem/parent_pairs.rs iroh-blobs/src/store/mem/parent_pairs/fixtures.rs iroh-blobs/src/store/mem/parent_pairs/right-proof.bin]
let records = ($paths | each {|path|
    let source = ($owned | path join $path)
    let actual = ($run | path join witness radio $path)
    if (sha $source) != (sha $actual) { error make {msg: 'witness content differs'} }
    {path: $path, sha256: (sha $source)}
})
let diff = (checked [git -C $owned diff -- iroh-blobs/src/store/mem.rs])
if ($diff | lines | where {|line| ($line | str starts-with '+') and not ($line | str starts-with '+++') }) != ['+#[cfg(test)]' '+mod parent_pairs;' '+'] { error make {msg: 'unexpected source changes'} }
{files: $records, mem_diff: $diff, kind: 'exact parent plus test module only', note: 'Preparation completed copies; initial overly strict order guard expected the equivalent hunk order incorrectly. This verifier checks actual order/content before production changes.'} | to json | save ($run | path join witness-overlay.json)

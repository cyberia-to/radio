use common.nu *
let run = $env.FILE_PWD
let bin = '/Users/master/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin'
let output = ($run | path join fixtures)
mkdir $output
let environment = {PATH: ([$bin] | append $env.PATH), RUSTC: ($bin | path join rustc), RUSTDOC: ($bin | path join rustdoc), RUSTUP_TOOLCHAIN: '1.95.0', RUSTUP_AUTO_INSTALL: '0', RUSTFLAGS: '-Dwarnings', RUSTDOCFLAGS: '-Dwarnings', CARGO_BUILD_JOBS: '4', CARGO_TARGET_DIR: ($run | path join targets candidate), RADIO_PARENT_PAIRS_FIXTURE_DIR: $output}
cd ($run | path join candidate radio)
required $run fixture-output-directory [pwd] | ignore
let result = (record $run candidate-three-fixture [($bin | path join cargo) test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs::three_group_nonzero_parent_ordinal --all-features --locked --offline] $environment)
if $result.exit_code != 0 { error make {msg: 'fixture witness failed'} }
{root: (open --raw ($output | path join three-root.txt)), files: ([three-full.bin three-middle.bin three-root.txt] | each {|name|
 let path = ($output | path join $name)
 {path: $path, bytes: (ls $path | get size.0 | into int), sha256: (sha $path)}
}), generator_sha256: (sha iroh-blobs/src/store/mem/parent_pairs/fixtures.rs), golden_sha256: (sha iroh-blobs/src/store/mem/parent_pairs/right-proof.bin), source_freeze_sha256: (sha ($run | path join source-freeze.json))} | to json | save ($run | path join fixture-identities.json)

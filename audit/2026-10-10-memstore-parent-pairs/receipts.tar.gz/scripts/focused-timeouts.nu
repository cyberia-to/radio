use common.nu *
def main [scope: string, threads: int = 1] {
    let run = $env.FILE_PWD
    if $scope not-in [parent candidate] or $threads not-in [1 4] { error make {msg: 'invalid diagnostic scope'} }
    let rows = (open ($run | path join nextest-comparison.json) | where parent == PASS and candidate == TIMEOUT)
    if ($rows | length) != 10 { error make {msg: 'expected original ten PASS-to-TIMEOUT names'} }
    let expression = ($rows | each {|r| 'test(=' + ($r.name | str replace 'iroh-blobs ' '') + ')' } | str join ' | ')
    let stem = $'($scope)-focused-timeouts-t($threads)-v2'
    for when in [before after] {
        required $run $'($stem)-($when)-clock' [date -u '+%Y-%m-%dT%H:%M:%SZ'] | ignore
        required $run $'($stem)-($when)-disk' [df -h /tmp] | ignore
        required $run $'($stem)-($when)-memory' [vm_stat] | ignore
        required $run $'($stem)-($when)-load' [uptime] | ignore
        required $run $'($stem)-($when)-processes' [ps -axo 'pid,ppid,etime,comm'] | ignore
        if $when == before {
            let args = [nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --no-fail-fast --test-threads ($threads | into string) --profile default -E $expression --locked --offline]
            let outcome = (^nu ($run | path join gate.nu) --scope $scope --name $'focused-timeouts-t($threads)-v2' --execute --args ($args | to json --raw) | complete)
            print $outcome.stdout
            if $outcome.stderr != '' { print --stderr $outcome.stderr }
            if not ($run | path join logs $'($stem).json' | path exists) { error make {msg: 'focused gate missing receipt'} }
        }
    }
}

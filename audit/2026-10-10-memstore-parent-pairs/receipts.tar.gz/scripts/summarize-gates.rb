require 'json'
require 'digest'
require 'shellwords'

root = File.dirname(__FILE__)
records = Dir[root + '/logs/*.json'].reject { |p| p.end_with?('.usage.json') }.sort.filter_map do |path|
  r = JSON.parse(File.read(path))
  next unless r['argv']&.first&.end_with?('/cargo')
  name = File.basename(path, '.json')
  out = File.read(path.sub(/\.json$/, '.stdout'))
  err = File.read(path.sub(/\.json$/, '.stderr'))
  result = out.lines.grep(/^test result:/).map(&:strip)
  result += err.lines.grep(/Summary.*tests run/).map(&:strip)
  result += err.lines.grep(/Checked.*checks:|Summary no semver update required/).map(&:strip)
  first_error = err.lines.find { |line| line.start_with?('error') }&.strip
  r.merge('name' => name, 'receipt' => path, 'test_results' => result, 'first_error' => first_error)
end
File.write(root + '/gate-index.json', JSON.pretty_generate(records) + "\n")
summary = [
  '# Parent-pair repair: executed gates', '',
  'Radio base0d11468503c052aa5dcefb0dabc4602bd8efdc60; Hemera23f3bbcff910ea6d504ceb505680a539260869da.',
  "Candidate is the6-file local source freeze SHA256 #{Digest::SHA256.file(root + '/source-freeze.json').hexdigest}.",
  'Earlier gates used freeze1649829898538dffa626d81dc83be4fcc7deddb137a188f64dd277a3b0b414dd; final freeze changes only one new-test import position to satisfy the named formatter. All production and fixture bytes are identical (format-refreeze.json). Final-byte tests/witnesses have explicit final receipt names.',
  'Commands below use actual pinned Cargo/RUSTC/RUSTDOC, four build jobs, isolated targets and unchanged committed Cargo.lock.',
  'Ordinary1.95.0; MSRV1.89.0; CI docs nightly2025-10-09. RUSTFLAGS=-Dwarnings; strict docs -Dwarnings; named CI docs --cfg docsrs.',
  'Tool argv/env/times/exits and full raw stdout/stderr are retained beside each receipt under logs/. This summary is not a release/ring1 pass.', '',
  '## Exact-parent failure-first and candidate checks', '',
  'The witness overlays only the cfg(test) module and the exact final test/fixture bytes. Debug/release each executed11 tests:2 controls passed,9 failed.',
  'Both original writers visibly panic on32→64 copy; public workflows fail as ordinary tests. No timeout was used to turn those failures into success.',
  'Only synchronous print96 uses exact-assert should_panic. Existing reader-short and parent-free controls pass on the parent.', '',
  'The PLAN predicted reader_partial_memory might improve. Actual candidate execution still fails on its first empty input (importing8bytes / invalid size for hash), before parent proofs. That predicted green flip is retracted; the new public witnesses cover the repaired paths directly. Hash::EMPTY remains a separate repair.', '',
  '## Command receipts', ''
]
records.each do |r|
  next if r['argv'][1] == 'clean'
  command = r['argv'].drop(1).shelljoin
  summary << "- `#{r['name']}` — exit#{r['exit']}; `cargo #{command}`."
  r['test_results'].each { |result| summary << "  #{result}" }
  summary << "  First diagnostic: #{r['first_error']}" if r['first_error']
end

def nextest_statuses(root, scope)
  path = "#{root}/logs/#{scope}-native-nextest.stderr"
  return {} unless File.exist?(path)
  File.read(path).lines.each_with_object({}) do |line, rows|
    if (m = line.match(/^\s*(PASS|FAIL|TIMEOUT|SKIP)\s+\[.*?\]\s+(\S+)\s+(\S+)/))
      rows["#{m[2]} #{m[3]}"] = m[1]
    end
  end
end
parent = nextest_statuses(root, 'parent')
candidate = nextest_statuses(root, 'candidate')
comparison = (parent.keys | candidate.keys).sort.map do |name|
  {name: name, parent: parent[name], candidate: candidate[name]}
end
File.write(root + '/nextest-comparison.json', JSON.pretty_generate(comparison) + "\n")
failure_details = %w[parent candidate].to_h do |scope|
  path = "#{root}/logs/#{scope}-native-nextest.stderr"
  sections = File.exist?(path) ? File.read(path).split(/^--- (STDOUT|STDERR):\s+iroh-blobs ([^\n]+) ---\s*$/) : []
  details = {}
  sections.drop(1).each_slice(3) do |kind, name, body|
    next unless kind == 'STDERR'
    lines = body.lines.take_while { |line| !line.match?(/^\s*(PASS|FAIL|TIMEOUT|SLOW|TERMINATING|Summary)\s/) }
    details[name] = lines.join.gsub(/\(\d+\) panicked at/, '(THREAD) panicked at').strip
  end
  [scope, details]
end
File.write(root + '/nextest-failure-details.json', JSON.pretty_generate(failure_details) + "\n")
unless parent.empty? || candidate.empty?
  summary += ['', '## Exact current-parent / candidate native test comparison', '']
  comparison.select { |r| r[:parent] != r[:candidate] }.each do |r|
    summary << "- #{r[:name]}: #{r[:parent] || 'absent'} → #{r[:candidate] || 'absent'}."
  end
  summary += ['', 'Remaining candidate non-pass results:']
  candidate.reject { |_, status| status == 'PASS' }.each { |name, status| summary << "- #{status} #{name}" }
  summary += ['', 'Full per-test panic/error text is preserved in nextest-failure-details.json; statuses alone are not diagnostic parity.', '']
end
summary += ['', '## Limits', '',
 'Broad formatter/Clippy/dependency/compiler/deny findings stay red; masked new-test Clippy is not certified.',
 'Cargo archive build scripts report missing Git worktree/VERGEN default warnings; command success is not a zero-warning claim.',
 'Persisted incomplete checkpoint checksum/recovery, Hash::EMPTY, actor lifecycle, bounded proof budgets and particle/root authority remain separate.',
 'Setup-only corrections retained: witness guard initially expected equivalent cfg hunk lines in the wrong order; explicit byte verifier then passed. Direct cargo-make --version exited1; cargo-make make --version and the named actual gate use the correct interface.',
 'The temporary sequential runner initially propagated the already-recorded candidate nightly exit101 before proceeding; its docs wrapper was corrected to consume the status, and execution resumed after that receipt. No gate or receipt was repeated or overwritten.',
 'Focused setup first rejected a Nu interpolated literal, then ps received split field names and exited1 before Cargo. The corrected v2 attempt has its own complete machine observations and real test receipts; setup failures are not product results.',
 'Last-tag semver uses the explicitly pinned current Hemera path with scratch resolution, not a historical release closure.', '' ]
File.write(root + '/code-gates.md', summary.join("\n"))
puts JSON.pretty_generate({cargo_receipts: records.length, nextest_parent: parent.length, nextest_candidate: candidate.length, summary_bytes: File.size(root + '/code-gates.md')})

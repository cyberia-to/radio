use common.nu *
let run = $env.FILE_PWD
let owned = '/Users/master/cyber/radio-kadek-memstore-pairs'
let paths = [iroh-blobs/src/store/mem.rs iroh-blobs/src/store/util.rs iroh-blobs/src/store/util/partial_mem_storage.rs iroh-blobs/src/store/mem/parent_pairs.rs iroh-blobs/src/store/mem/parent_pairs/fixtures.rs iroh-blobs/src/store/mem/parent_pairs/right-proof.bin]
let records = ($paths | each {|path|
    let source = ($owned | path join $path)
    let destination = ($run | path join candidate radio $path)
    mkdir ($destination | path dirname)
    cp $source $destination
    {path: $path, sha256: (sha $source)}
})
$records | to json | save ($run | path join source-freeze.json)
for path in ($paths | where $it != iroh-blobs/src/store/mem.rs and $it != iroh-blobs/src/store/util.rs and $it != iroh-blobs/src/store/util/partial_mem_storage.rs) {
    if (sha ($owned | path join $path)) != (sha ($run | path join witness radio $path)) { error make {msg: 'final test differs from red-first witness'} }
}
if (sha ($run | path join candidate radio Cargo.lock)) != (open ($run | path join sources.json) | get lock_sha256) { error make {msg: 'lock drift'} }
print {files: ($records | length), freeze_sha256: (sha ($run | path join source-freeze.json))}

use common.nu *
def main [label: string, --stack] {
 let run = $env.FILE_PWD
 let target_prefix = (($run | path join targets candidate debug deps) + '/iroh_blobs-')
 let rows = (checked [ps -axo 'pid,comm'] | lines | parse -r '^\s*(?<pid>\d+)\s+(?<path>.+)$' | where {|r| $r.path | str starts-with $target_prefix })
 if ($rows | length) == 0 { print 'selected test process is not active'; return }
 if ($rows | length) != 1 { error make {msg: 'more than one candidate test process'} }
 let pid = ($rows | first | get pid)
 required $run $'observe60-($label)-clock' [date -u '+%Y-%m-%dT%H:%M:%SZ'] | ignore
 required $run $'observe60-($label)-process' [ps -p $pid -o 'pid,ppid,etime,%cpu,command'] | ignore
 if $stack {
  required $run $'observe60-($label)-sample' [/usr/bin/sample $pid '1' '1' -file ($run | path join $'observe60-($label).sample.txt')] | ignore
 }
}

use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let root = ($run | path join targets semver semver-checks)
 let retained = ($run | path join semver-generated-final)
 let files = (checked [rg --files --hidden -g Cargo.toml -g Cargo.lock -g lib.rs $root] | lines)
 let records = ($files | each {|source|
  let relative = ($source | path relative-to $root)
  let target = ($retained | path join $relative)
  mkdir ($target | path dirname)
  cp $source $target
  {source: $source, retained: $target, sha256: (sha $source)}
 })
 {files: $records, note: 'Surviving final helper project after both semver commands; tool reused one project directory and final dependency path names the tag baseline. This is not a claim that intermediate generated files were separately captured. Full current/parent/tag source manifests and committed locks remain in semver/; raw logs identify each actual build and resolution.'} | to json | save ($run | path join semver-generated-final.json)
 let bin = '/Users/master/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin'
 cd ($run | path join semver current radio)
 let result = (record $run semver-clean-final [($bin | path join cargo) clean --target-dir ($run | path join targets semver)] {RUSTC: ($bin | path join rustc), RUSTDOC: ($bin | path join rustdoc), CARGO_BUILD_JOBS: '4'})
 if $result.exit_code != 0 { error make {msg: 'semver cleanup failed'} }
}

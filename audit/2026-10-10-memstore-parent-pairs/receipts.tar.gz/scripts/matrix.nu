def main [scope: string, phase: string] {
 let run = $env.FILE_PWD
 let scoped = [
  {name: pairs-all, args: [test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline]}
  {name: pairs-default, args: [test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --locked --offline]}
  {name: pairs-none, args: [test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --no-default-features --locked --offline]}
  {name: pairs-release, args: [test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --release --all-features --locked --offline]}
  {name: native-smoke, args: [test --manifest-path iroh-blobs/Cargo.toml --lib store::mem::tests::smoke --all-features --locked --offline]}
  {name: native-export-default, args: [test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --locked --offline]}
  {name: native-export-all, args: [test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --all-features --locked --offline]}
  {name: native-root-policy, args: [test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --all-features --locked --offline]}
  {name: bao-all, args: [test -p cyber-bao --all-features --locked --offline]}
 ]
 let broad = [
  {name: metadata, args: [metadata --format-version '1' --locked --offline]}
  {name: format, args: [fmt --all -- --check]}
  {name: native-clippy, args: [clippy --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline -- -D warnings]}
  {name: native-doc, args: [doc --manifest-path iroh-blobs/Cargo.toml --all-features --no-deps --locked --offline]}
  {name: workspace-no-run, args: [test --workspace --no-run --locked --offline]}
  {name: consumers-no-run, args: [test -p radio-cli -p radio-integration-tests --all-features --no-run --locked --offline]}
  {name: native-nextest, args: [nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --no-fail-fast --test-threads '4' --locked --offline]}
  {name: named-format, args: [make --disable-check-for-updates format-check]}
  {name: named-nextest-all, args: [nextest run --workspace --all-features --lib --bins --tests --no-run --locked --offline]}
  {name: named-nextest-none, args: [nextest run --workspace --no-default-features --lib --bins --tests --no-run --locked --offline]}
  {name: named-nextest-default, args: [nextest run --workspace --lib --bins --tests --no-run --locked --offline]}
  {name: named-clippy-all, args: [clippy --workspace --all-features --all-targets --lib --bins --tests --benches --examples --locked --offline]}
  {name: named-clippy-none, args: [clippy --workspace --no-default-features --all-targets --lib --bins --tests --benches --examples --locked --offline]}
  {name: named-clippy-default, args: [clippy --workspace --all-targets --lib --bins --tests --benches --examples --locked --offline]}
  {name: named-deny, args: [deny --workspace --all-features --locked check --disable-fetch -Dwarnings]}
 ]
 let msrv = [
  {name: msrv-native-check, args: [check --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline]}
  {name: msrv-pairs, args: [test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline]}
  {name: msrv-export, args: [test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --all-features --locked --offline]}
  {name: msrv-workspace-check, args: [check --workspace --all-targets --locked --offline]}
 ]
 let cases = if $phase == scoped { $scoped } else if $phase == broad { $broad } else if $phase == msrv { $msrv } else { error make {msg: 'phase must be scoped, broad or msrv'} }
 for item in $cases {
  # The pristine parent has no new test module; do not report a zero-test pass.
  if $scope == parent and $item.name == msrv-pairs { continue }
  let receipt = ($run | path join logs $'($scope)-($item.name).json')
  if ($receipt | path exists) { error make {msg: $'existing receipt: ($receipt)'} }
  let outcome = (^nu ($run | path join gate.nu) --scope $scope --name $item.name --toolchain (if $phase == msrv { '1.89.0' } else { '1.95.0' }) --execute --args ($item.args | to json --raw) | complete)
  print $outcome.stdout
  if $outcome.stderr != '' { print --stderr $outcome.stderr }
  if not ($receipt | path exists) { error make {msg: 'gate runner failed before receipt'} }
  if $phase == scoped and $outcome.exit_code != 0 { error make {msg: 'scoped gate red; inspect before continuing'} }
 }
}

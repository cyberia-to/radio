use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let owned = '/Users/master/cyber/radio-kadek-memstore-pairs'
 let prior = ($run | path join source-freeze.json)
 if (sha $prior) != '1649829898538dffa626d81dc83be4fcc7deddb137a188f64dd277a3b0b414dd' { error make {msg: 'unexpected old freeze'} }
 let changed = 'iroh-blobs/src/store/mem/parent_pairs.rs'
 let old = (open $prior)
 for item in $old {
  if (sha ($run | path join candidate radio $item.path)) != $item.sha256 { error make {msg: 'old candidate drift'} }
  if $item.path != $changed and (sha ($owned | path join $item.path)) != $item.sha256 { error make {msg: 'unexpected source change'} }
 }
 cp $prior ($run | path join source-freeze-v1.json)
 for destination in [candidate/radio witness/radio semver/current/radio] {
  cp ($owned | path join $changed) ($run | path join $destination $changed)
 }
 let revised = ($old | each {|item| if $item.path == $changed { $item | update sha256 (sha ($owned | path join $changed)) } else { $item } })
 $revised | to json | save -f $prior
 {old_manifest_sha256: (sha ($run | path join source-freeze-v1.json)), new_manifest_sha256: (sha $prior), changed_path: $changed,
  change: 'Only move fixtures import into the named formatter group; production and fixture bytes unchanged.',
  exact_unchanged_paths: ($old | where path != $changed | get path),
  old_test_sha256: ($old | where path == $changed | first | get sha256), new_test_sha256: (sha ($owned | path join $changed))}
  | to json | save ($run | path join format-refreeze.json)
 print (open ($run | path join format-refreeze.json))
}

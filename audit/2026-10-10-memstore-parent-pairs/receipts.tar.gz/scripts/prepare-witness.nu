use common.nu *
let run = $env.FILE_PWD
let owned = '/Users/master/cyber/radio-kadek-memstore-pairs'
let scope = ($run | path join witness)
if ($scope | path exists) { error make {msg: 'witness already exists'} }
mkdir ($scope | path join radio) ($scope | path join hemera)
required $run witness-radio [tar -xf ($run | path join archives radio.tar) -C ($scope | path join radio)] | ignore
required $run witness-hemera [tar -xf ($run | path join archives hemera.tar) -C ($scope | path join hemera)] | ignore
let paths = [iroh-blobs/src/store/mem.rs iroh-blobs/src/store/mem/parent_pairs.rs iroh-blobs/src/store/mem/parent_pairs/fixtures.rs iroh-blobs/src/store/mem/parent_pairs/right-proof.bin]
let records = ($paths | each {|path|
    let source = ($owned | path join $path)
    let destination = ($scope | path join radio $path)
    mkdir ($destination | path dirname)
    cp $source $destination
    {path: $path, sha256: (sha $source)}
})
let diff = (checked [git -C $owned diff -- iroh-blobs/src/store/mem.rs])
if ($diff | lines | where {|line| ($line | str starts-with '+') and not ($line | str starts-with '+++') }) != ['+#[cfg(test)]' '+mod parent_pairs;' '+'] {
    error make {msg: 'unexpected production edits before red-first witness'}
}
{files: $records, mem_diff: $diff, kind: 'exact parent plus test module only'} | to json | save ($run | path join witness-overlay.json)

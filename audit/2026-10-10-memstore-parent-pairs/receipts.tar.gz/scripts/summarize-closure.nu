use common.nu *
def main [scope: string] {
 let run = $env.FILE_PWD
 let input = ($run | path join logs $'($scope)-metadata.stdout')
 let metadata = (open --raw $input | from json)
 let local = ($metadata.packages | where source == null)
 let root = ($local | where name == iroh-blobs | first | get id)
 mut closure = [$root]
 loop {
  let seen = $closure
  let found = ($metadata.resolve.nodes | where {|node|
   ($node.id not-in $seen) and ($node.deps | any {|dep| $dep.pkg in $seen })
  } | get id)
  if ($found | is-empty) { break }
  $closure = ($closure | append $found)
 }
 let rows = ($metadata.packages | where {|p| $p.id in $closure } | select id name version source manifest_path)
 {basis: 'Exact archives, locked offline default-feature metadata. Source closure only.', metadata_sha256: (sha $input), radio: '0d11468503c052aa5dcefb0dabc4602bd8efdc60', hemera: '23f3bbcff910ea6d504ceb505680a539260869da', packages: $rows, direct_hemera: ($local | where name == cyber-hemera | select id version manifest_path)} | to json | save ($run | path join $'($scope)-local-source-closure.json')
 print ($rows | select name version source)
}

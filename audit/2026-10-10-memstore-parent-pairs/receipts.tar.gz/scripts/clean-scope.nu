def main [scope: string, suffix: string] {
 let run = $env.FILE_PWD
 if $scope == candidate and $suffix == after-final-tests and ($run | path join pause-for-observe-60 | path exists) {
  error make {msg: 'Intentional pause before candidate cleanup for authorized one-shot 60s observation diagnostic.'}
 }
 if $scope == parent and $suffix in [after-broad after-msrv] and ($run | path join pause-after-parent-broad | path exists) {
  error make {msg: 'Intentional pause after completed parent gate phase for focused timeout diagnosis; no target cleaned.'}
 }
 for nightly in [false true] {
  let args = [($run | path join gate.nu) --scope $scope --name $'clean-($suffix)-(if $nightly { "nightly" } else { "ordinary" })' --clean-completed --execute]
  let args = if $nightly { $args | append [--ci-docs] } else { $args }
  ^nu ...$args
  if $env.LAST_EXIT_CODE != 0 { exit $env.LAST_EXIT_CODE }
 }
}

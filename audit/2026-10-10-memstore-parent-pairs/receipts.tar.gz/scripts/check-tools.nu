use common.nu *
let run = $env.FILE_PWD
let db = '/Users/master/.cargo/advisory-dbs/advisory-db-3157b0e258782691'
let revision = (required $run advisory-db-head-v2 [git -C $db rev-parse HEAD] | str trim)
let status = (required $run advisory-db-status-v2 [git -C $db status --porcelain] | str trim)
if $revision != '7eebec69c352c7191b1f13eb95dd510eeca5d1de' or $status != '' { error make {msg: 'advisory DB drift'} }
let binaries = ([cargo-nextest cargo-make cargo-deny makers] | each {|name|
 let path = $'/tmp/radio-gate-tools/bin/($name)'
 let args = if $name == cargo-make { [$path make --version] } else { [$path --version] }
 required $run $'tool-version-v2-($name)' $args | ignore
 {path: $path, sha256: (sha $path)}
})
let nightly = ([cargo rustc rustdoc] | each {|name|
 let path = $'/Users/master/.rustup/toolchains/nightly-2025-10-09-aarch64-apple-darwin/bin/($name)'
 required $run $'tool-nightly-($name)' [$path --version] | ignore
 {path: $path, sha256: (sha $path)}
})
{binaries: $binaries, nightly: $nightly, advisory_db: {path: $db, revision: $revision}, installed_receipt_sha256: (sha /tmp/radio-gate-tools/PARENT-INSTALLED-SHA256SUMS), installed_payload_check_sha256: (sha ($run | path join tools-verification.log)), note: 'Historical acquisition dates retained in original ROOT receipt; exact frozen payloads verified here. No release claim.'} | to json | save ($run | path join tools.json)

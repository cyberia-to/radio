use common.nu *
def run-checked [args: list<string>] {
    ^nu ...$args
    if $env.LAST_EXIT_CODE != 0 { error make {msg: $'matrix/setup failed: ($args | to nuon)'} }
}
def docs-recorded [run: path, scope: string] {
    let result = (^nu ($run | path join nightly.nu) $scope | complete)
    print $result.stdout
    if $result.stderr != '' { print --stderr $result.stderr }
    # A red command is evidence; a wrapper failure without a receipt is not.
    let receipt = ($run | path join logs $'($scope)-named-nightly-docs.json')
    if not ($receipt | path exists) { error make {msg: 'nightly command has no receipt'} }
}
def main [--after-candidate-nightly] {
    let run = $env.FILE_PWD
    if not ($run | path join logs candidate-msrv-workspace-check.json | path exists) {
        error make {msg: 'candidate MSRV must finish first'}
    }
    if $after_candidate_nightly {
        if not ($run | path join logs candidate-named-nightly-docs.json | path exists) {
            error make {msg: 'resume requires completed candidate nightly receipt'}
        }
    } else {
        run-checked [($run | path join clean-scope.nu) candidate after-msrv]
        docs-recorded $run candidate
    }
    run-checked [($run | path join clean-scope.nu) candidate after-nightly]
    run-checked [($run | path join matrix.nu) parent broad]
    run-checked [($run | path join summarize-closure.nu) parent]
    run-checked [($run | path join clean-scope.nu) parent after-broad]
    run-checked [($run | path join matrix.nu) parent msrv]
    run-checked [($run | path join clean-scope.nu) parent after-msrv]
    docs-recorded $run parent
    run-checked [($run | path join clean-scope.nu) parent after-nightly]
    run-checked [($run | path join candidate-semver.nu)]
}

use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let owned = '/Users/master/cyber/radio-kadek-memstore-pairs'
 let freeze = (open ($run | path join source-freeze.json))
 for item in $freeze {
  for folder in [$owned ($run | path join candidate radio) ($run | path join semver current radio)] {
   if (sha ($folder | path join $item.path)) != $item.sha256 { error make {msg: 'final source freeze drift'} }
  }
 }
 required $run source-final-diff-check [git -C $owned diff --check] | ignore
 let diff = (record $run source-final-closure-diff [diff -qr ($run | path join parent radio) ($run | path join candidate radio)])
 if $diff.exit_code != 1 { error make {msg: 'expected nonempty source-only candidate diff'} }
 let expected = ['iroh-blobs/src/store/mem.rs' 'iroh-blobs/src/store/util.rs' 'iroh-blobs/src/store/util/partial_mem_storage.rs']
 let lines = ($diff.stdout | lines)
 if ($lines | length) != 4 { error make {msg: 'unexpected full closure differences'} }
 for path in $expected {
  if not ($lines | any {|line| ($line | str contains $path) and ($line | str ends-with 'differ') }) { error make {msg: 'missing expected production diff'} }
 }
 if not ($lines | any {|line| $line == $'Only in ($run)/candidate/radio/iroh-blobs/src/store: mem' }) { error make {msg: 'unexpected new source directory'} }
 required $run source-final-hemera-equality [diff -qr ($run | path join parent hemera) ($run | path join candidate hemera)] | ignore
 let locks = ([parent candidate witness] | each {|scope| {scope: $scope, sha256: (sha ($run | path join $scope radio Cargo.lock))}})
 if not ($locks | all {|r| $r.sha256 == '295b21c8804e3885a195511ffca6fcf368e7c762c5b411374aecf20ba4d14052' }) { error make {msg: 'authoritative lock drift'} }
 {manifest_sha256: (sha ($run | path join source-freeze.json)), files: $freeze, authoritative_locks: $locks, source_diff: $diff.stdout, production_change_since_first_freeze: false}
  | to json | save ($run | path join source-final-integrity.json)
}

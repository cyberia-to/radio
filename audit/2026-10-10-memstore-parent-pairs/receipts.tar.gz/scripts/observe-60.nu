use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let source = ($run | path join candidate radio .config nextest.toml)
 let original = (open --raw $source)
 let old = 'slow-timeout = { period = "10s", terminate-after = 3 }'
 if ($original | split row $old | length) != 2 { error make {msg: 'unexpected committed timeout config'} }
 let config = ($run | path join observe-60.nextest.toml)
 $original | str replace $old 'slow-timeout = { period = "10s", terminate-after = 6 }' | save $config
 {source_config_sha256: (sha $source), diagnostic_config_sha256: (sha $config), change: 'Only default terminate-after3→6; one candidate-only exact test, no committed config change.'} | to json | save ($run | path join observe-60-config.json)
 ^nu ($run | path join observe.nu) candidate-observe60-before
 let args = [nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --no-fail-fast --test-threads '1' --profile default --config-file $config -E 'test(=tests::two_nodes_observe_mem)' --locked --offline]
 let result = (^nu ($run | path join gate.nu) --scope candidate --name observe60-diagnostic --execute --args ($args | to json --raw) | complete)
 print $result.stdout
 if $result.stderr != '' { print --stderr $result.stderr }
 if not ($run | path join logs candidate-observe60-diagnostic.json | path exists) { error make {msg: 'diagnostic has no receipt'} }
 ^nu ($run | path join observe.nu) candidate-observe60-after
}

require 'json'
require 'digest'

root = File.dirname(__FILE__)
def normalize(text, root)
  text.gsub(root, '<scaffold>').gsub('/private<scaffold>', '<scaffold>')
      .gsub(%r{<scaffold>/(parent|candidate)/}, '<closure>/')
      .gsub(%r{<scaffold>/targets/(parent|candidate)(-nightly-docs)?/}, '<target>/')
end
def errors(text)
  clean = text.lines.reject { |l| l.match?(/^\s*(Checking|Compiling|Documenting|Finished|Generated)\s/) }.join
  clean.split(/(?=^(?:error|warning)(?:\[[^\]]+\])?:)/)
       .select { |s| s.match?(/\Aerror(?:\[[^\]]+\])?:/) }
       .map(&:strip).sort
end
def format_hunks(text)
  text.split(/(?=^Diff in )/).select { |s| s.start_with?('Diff in ') }
      .map { |s| s.sub(/^(Diff in .*?):\d+:$/, '\1:<line>:').strip }.sort
end
rows = Dir[root + '/logs/candidate-*.json'].reject { |p| p.end_with?('.usage.json') }.filter_map do |candidate_path|
  name = File.basename(candidate_path).delete_prefix('candidate-').delete_suffix('.json')
  parent_name = %w[format-final named-format-final].include?(name) ? name.delete_suffix('-final') : name
  parent_path = root + '/logs/parent-' + parent_name + '.json'
  next unless File.exist?(parent_path)
  c = JSON.parse(File.read(candidate_path)); p = JSON.parse(File.read(parent_path))
  next unless c['argv']&.first&.end_with?('/cargo') && c['argv'][1] != 'clean'
  raw = %w[parent candidate].to_h do |scope|
    stem = root + '/logs/' + scope + '-' + (scope == 'parent' ? parent_name : name)
    text = File.read(stem + '.stdout') + File.read(stem + '.stderr')
    [scope, normalize(text, root)]
  end
  pe = errors(raw['parent']); ce = errors(raw['candidate'])
  row = {name: name, parent_name: parent_name, parent_exit: p['exit'], candidate_exit: c['exit'],
         parent_receipt_sha256: Digest::SHA256.file(parent_path).hexdigest,
         candidate_receipt_sha256: Digest::SHA256.file(candidate_path).hexdigest,
         parent_errors: pe.map { |s| s.lines.first.strip }, candidate_errors: ce.map { |s| s.lines.first.strip },
         error_blocks_equal_after_path_normalization: pe == ce,
         parent_only_error_blocks: pe - ce, candidate_only_error_blocks: ce - pe}
  if %w[format named-format format-final named-format-final].include?(name)
    ph = format_hunks(raw['parent']); ch = format_hunks(raw['candidate'])
    row.merge!(parent_format_hunks: ph.length, candidate_format_hunks: ch.length,
               format_hunks_equal_after_paths_and_line_normalization: ph == ch,
               parent_only_format_hunks: ph - ch, candidate_only_format_hunks: ch - ph)
  end
  row
end
output = {method: 'Complete error blocks sorted after only closure/target path normalization and build-progress removal. Formatter hunk comparison additionally replaces hunk start line numbers. This does not establish test failure parity; nextest errors are compared separately.', gates: rows.sort_by { |r| r[:name] }}
File.write(root + '/paired-diagnostics.json', JSON.pretty_generate(output) + "\n")
puts JSON.pretty_generate(rows.map { |r| r.slice(:name, :parent_exit, :candidate_exit, :error_blocks_equal_after_path_normalization, :format_hunks_equal_after_paths_and_line_normalization) })

use common.nu *
def main [name: string] {
 let run = $env.FILE_PWD
 required $run $'($name)-clock' [date -u '+%Y-%m-%dT%H:%M:%SZ'] | ignore
 required $run $'($name)-cpu' [ps -axo 'pid,ppid,etime,%cpu,comm'] | ignore
 required $run $'($name)-load' [uptime] | ignore
 required $run $'($name)-disk' [df -h /tmp] | ignore
}

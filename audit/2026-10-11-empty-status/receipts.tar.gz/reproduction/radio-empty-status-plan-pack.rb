require 'json'
require 'digest'
require 'fileutils'
require 'open3'

DEST = '/tmp/radio-empty-status-plan-v1'
RUN = '/tmp/radio-empty-status.20261011-60036-oi3wr7'
RADIO = '/Users/master/cyber/radio-kadek-empty-status'
HEMERA = '/Users/master/cyber/hemera'
RADIO_REV = 'bc8b6331d3c76cbc011210e13f81e6ea351ef06f'
HEMERA_REV = 'd5f0a09539360934fb32db9b2e15a91995607db6'
raise 'pack exists' if File.exist?(DEST)
FileUtils.mkdir_p(DEST + '/inputs')
rows = []
add = lambda do |data, metadata|
  path = DEST + '/inputs/' + format('%03d', rows.length) + '.txt'
  File.binwrite(path, data)
  rows << metadata.merge('file' => path, 'bytes' => data.bytesize, 'sha256' => Digest::SHA256.hexdigest(data))
end
git = lambda do |repo, rev, path|
  data, err, status = Open3.capture3('git', '-C', repo, 'show', rev + ':' + path)
  raise err unless status.success?
  data.b
end
%w[research.md plan.md execution.md].each do |name|
  file = RADIO + '/.claude/tasks/bao-empty-status/' + name
  add.call(File.binread(file), { 'owner' => 'current task', 'path' => name, 'original' => file, 'note' => 'Current-origin amendment; production edit awaits fresh PLAN approval.' })
end
paths = %w[Cargo.toml iroh-blobs/Cargo.toml iroh-docs/Cargo.toml iroh-willow/Cargo.toml radio-cli/Cargo.toml tests/integration/Cargo.toml iroh-blobs/src/hash.rs iroh-blobs/src/store/fs/meta.rs iroh-blobs/src/store/fs/meta/proto.rs iroh-blobs/src/store/fs.rs iroh-blobs/src/api/blobs.rs iroh-blobs/src/util/temp_tag.rs iroh-blobs/src/api/remote.rs iroh-blobs/src/get.rs cyber-bao/src/io/fsm.rs iroh-docs/src/engine.rs iroh-docs/src/engine/live.rs .config/nextest.toml Makefile.toml]
paths.each do |path|
  add.call(git.call(RADIO,RADIO_REV,path), {'owner'=>'current Radio parent','repo'=>RADIO,'revision'=>RADIO_REV,'path'=>path,'note'=>'Complete committed current source; no candidate production modification.'})
end
%w[rs/Cargo.toml specs/tree.md vectors/hemera.json rs/tests/vectors.rs].each do |path|
  add.call(git.call(HEMERA,HEMERA_REV,path), {'owner'=>'current Hemera primary','repo'=>HEMERA,'revision'=>HEMERA_REV,'path'=>path,'note'=>'Complete committed current primary input. Exact current/old identity and scoped fresh runtime controls are separately recorded.'})
end
[
  [HEMERA, HEMERA_REV, 'rs/src/tree.rs', [[1,65],[138,143],[215,228],[873,877]]],
  [RADIO, RADIO_REV, 'iroh-docs/src/sync.rs', [[353,381],[900,909],[1122,1150]]],
  [RADIO, RADIO_REV, 'iroh-docs/src/store/fs/query.rs', [[156,160]]],
  [RADIO, RADIO_REV, '.github/workflows/ci.yml', [[250,343]]],
  [RADIO, RADIO_REV, '.github/workflows/tests.yaml', [[1,148]]]
].each do |repo,rev,path,ranges|
  source = git.call(repo,rev,path)
  ranges.each do |first,last|
    add.call(source.lines[(first-1)..(last-1)].join, {'owner'=>'exact current excerpt','path'=>"#{path}:#{first}-#{last}",'source_repo'=>repo,'source_revision'=>rev,'source_path'=>path,'line_first'=>first,'line_last'=>last,'source_sha256'=>Digest::SHA256.hexdigest(source),'note'=>'Exact inclusive lines from current committed source. Remaining portions are not represented as reviewed.'})
  end
end
%w[iroh-blobs/src/hash/empty_root.rs iroh-blobs/src/hash/empty_root/stores.rs iroh-blobs/src/hash/empty_root/remote.rs].each do |path|
  source = RUN + '/witness/radio/' + path
  add.call(File.binread(source), {'owner'=>'proposed tests and current witness','path'=>path,'original'=>source,'note'=>'Complete independent test file; unchanged from historical tests, freshly executed against current production. No guard has been applied.'})
end
%w[sources.json resolved-closure.json resolved-all-features.json primary-identity.json witness-overlay.json enumeration-witness-source.json fs-enumeration-probe.rs toolchains.json].each do |name|
  source = RUN + '/' + name
  add.call(File.binread(source), {'owner'=>'current measured evidence','path'=>name,'original'=>source,'note'=>'Current-origin source/closure/witness evidence, not historical344 results.'})
end
%w[witness-empty-root-debug witness-empty-root-release witness-enumeration-probe].each do |name|
  %w[json stdout].each do |ext|
    source = RUN + '/logs/' + name + '.' + ext
    add.call(File.binread(source), {'owner'=>'current witness receipt','path'=>name+'.'+ext,'original'=>source,'note'=>'Full current command record or full failure-first stdout. Raw stderr hash is in its record; bulk compiler stderr is retained outside the bounded review.'})
  end
end
source = RUN + '/logs/witness-enumeration-probe.stderr'
add.call(File.binread(source), {'owner'=>'current enumeration stderr','path'=>'witness-enumeration-probe.stderr','original'=>source,'note'=>'Full stderr includes the actual measured lists/key and archive warnings.'})
%w[origin-radio-preplan origin-hemera-preplan parent-metadata parent-metadata-all].each do |name|
  source = RUN + '/logs/' + name + '.json'
  add.call(File.binread(source), {'owner'=>'current provenance receipt','path'=>name+'.json','original'=>source,'note'=>'Full command record; bulk metadata retained with matching hashes outside this bounded review.'})
end
overview = <<~TEXT
  Fresh independent PLAN review of a current-origin amendment.
  Return APPROVE or REQUEST CHANGES; distinguish blockers from advice.
  Scope: only Fs synthetic EMPTY status guard, cfg(test) module wiring and the
  proposed three test files. No production edit exists yet. Current Radio
  bc8b6331d3c76cbc011210e13f81e6ea351ef06f already fixed EMPTY itself and many old
  width/consumer defects. Current Hemera is d5f0a09539360934fb32db9b2e15a91995607db6.
  Do not import old344ac162 gate failures or old registry-only docs ownership.
  An earlier CODE approval against that old five-file scope does not approve this
  current amendment; that worktree and all historical receipts remain untouched.

  Current debug and release tests-only witnesses each execute17 tests:15 pass,
  2 fail because Fs status returns NotFound while existing synthetic empty reads
  and exports require logical Complete{0}. The ordinary assertions are retained.
  Current enumeration is measured [] before and after empty add. The proposed
  guard preserves enumeration; its only new public effect is status/has and
  their consumers. Newly local iroh-docs consumers are fully traced here.
  Its current tombstone identity and validation are unchanged by the proposal.

  Inputs below include complete current owning/status/download callers, all three
  proposed test files, full primary tree contract/literals, current frozen closure,
  complete witness failure stdout and command records. Current Hemera implementation,
  docs tombstone and CI portions are exact labeled excerpts with full-source hashes.
  Remaining implementation/registry/workspace source, bulk compiler stderr, full
  metadata/locks and historical review packs are outside this bounded review.
  Their existence/digest is not a claim that you reviewed their contents. No final
  candidate or current broad/downstream/lint/docs/MSRV/semver pass is asserted.
  Read the planned checks as future work. Root owns implementation authorization,
  later CODE review and ordinary-source merge; this is no release/version approval.
TEXT
File.write(DEST + '/overview.txt', overview)
File.write(DEST + '/index.json', JSON.pretty_generate(rows) + "\n")
body = overview.b + rows.each_with_index.map do |r,i|
  "\n===== SOURCE #{i+1}: #{r['owner']} / #{r['path']} =====\nSHA256 #{r['sha256']}; #{r['note']}\n".b + File.binread(r['file']) + "\n===== END SOURCE =====\n"
end.join
raise "brief exceeds600KB: #{body.bytesize}" if body.bytesize > 600_000
File.binwrite(DEST + '/brief.txt',body)
json = {sections:rows.length,full_git_sources:rows.count{|r|r['revision']},exact_current_excerpts:rows.count{|r|r['source_revision']},proposed_test_files:3,bytes:body.bytesize,sha256:Digest::SHA256.hexdigest(body),index_sha256:Digest::SHA256.file(DEST+'/index.json').hexdigest,radio:RADIO_REV,hemera:HEMERA_REV}
File.write(DEST+'/build.json',JSON.pretty_generate(json)+"\n")
puts JSON.pretty_generate(json)

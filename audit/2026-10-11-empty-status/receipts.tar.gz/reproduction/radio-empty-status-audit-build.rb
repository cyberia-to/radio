require 'json'
require 'digest'
require 'fileutils'
require 'open3'
require 'time'
RUN='/tmp/radio-empty-status.20261011-60036-oi3wr7'
OWNED='/Users/master/cyber/radio-kadek-empty-status'
OLD='/Users/master/cyber/radio-kadek-empty-root'
AUDIT=OWNED+'/audit/2026-10-11-empty-status'
PAYLOAD='/tmp/radio-empty-status-audit-payload'
raise 'audit or payload already exists' if File.exist?(AUDIT)||File.exist?(PAYLOAD)
FileUtils.mkdir_p(AUDIT);FileUtils.mkdir_p(PAYLOAD)
def copy(src,path)
 dest=PAYLOAD+'/'+path
 raise "collision #{path}" if File.exist?(dest)
 FileUtils.mkdir_p(File.dirname(dest));File.binwrite(dest,File.binread(src))
end
def tree(src,path)
 Dir[src+'/**/*',src+'/**/.*'].sort.uniq.each{|p|copy(p,path+'/'+p.delete_prefix(src+'/')) if File.file?(p)}
end
def json(path,obj)=File.write(path,JSON.pretty_generate(obj)+"\n")
tree(RUN+'/logs','logs')
tree(RUN+'/archives','archives')
tree(RUN+'/runtime-outputs','runtime-outputs')
Dir[RUN+'/*'].sort.each{|p|copy(p,'execution/'+File.basename(p)) if File.file?(p)}
tree(RUN+'/review','reviews/plan-verdict')
tree('/tmp/radio-empty-status-plan-v1','reviews/plan')
tree('/tmp/radio-empty-status-code-v1','reviews/code-bounded')
tree(OWNED+'/.claude/tasks/bao-empty-status','task')
freeze=JSON.parse(File.read(RUN+'/candidate-freeze.json'))
freeze['files'].each do |r|
 p=r['path'];raise 'source drift' unless Digest::SHA256.file(OWNED+'/'+p).hexdigest==r['sha256']
 copy(OWNED+'/'+p,'sources/final/'+p)
 copy(RUN+'/parent/radio/'+p,'sources/parent/'+p) if File.file?(RUN+'/parent/radio/'+p)
 copy(RUN+'/witness/radio/'+p,'sources/witness/'+p)
end
%w[parent tag parent-after-sigkill].each{|p|tree(RUN+'/semver-generated/'+p,'semver/generated/'+p)}
tree(RUN+'/semver-generated-final','semver/generated/final')
%w[current parent tag].each do |scope|
 %w[radio/Cargo.toml radio/Cargo.lock radio/iroh-blobs/Cargo.toml hemera/Cargo.toml hemera/rs/Cargo.toml].each{|p|copy(RUN+'/semver/'+scope+'/'+p,'semver/sources/'+scope+'/'+p)}
end
%w[nextest-runner/src/config/config_impl.rs nextest-runner/src/config/slow_timeout.rs nextest-runner/src/runner.rs].each{|p|copy(RUN+'/nextest-source/'+p,'nextest-source/'+p)}
# Historical evidence is an explicitly separate, nested capsule. Never merge its gate rows.
tree(OLD+'/audit/2026-10-11-empty-root','historical/superseded344/audit')
tree(OLD+'/.claude/tasks/bao-empty-root','historical/superseded344/task')
old_freeze=JSON.parse(File.read(OLD+'/audit/2026-10-11-empty-root/source-freeze.json'))
old_freeze.each{|r|copy(OLD+'/'+r['path'],'historical/superseded344/sources/'+r['path'])}
copy('/tmp/kadek-empty-root-grok-code-v1-review.txt','historical/superseded344/code-review.txt')
%w[root-verification.json independent-verification.json build.json].each do |p|
 src='/tmp/kadek-empty-root-grok-code-v1/'+p
 copy(src,'historical/superseded344/code-review-metadata/'+p) if File.file?(src)
end
out,err,status=Open3.capture3('git','-C',OLD,'diff','--binary')
raise err unless status.success?
File.binwrite(PAYLOAD+'/historical/superseded344/tracked-source.diff',out)
json(PAYLOAD+'/historical/superseded344/status.json',{status:'superseded-by-origin; never merged',radio:'344ac1627ef4cb4544a98d9afc5442be85fe1d15',hemera:'23f3bbcff910ea6d504ceb505680a539260869da',superseding_origin:freeze['base'],code_review:'Parent reported fresh Grok4.7 APPROVE session14141 exit0; exact raw verdict retained. The nested immutable audit README was snapshotted before that verdict and says pending. No old gate result is a current result. All five old sources and task notes are preserved here; no old worktree cleanup is performed.'})
%w[radio-empty-status-plan-pack.rb radio-empty-status-code-pack.rb radio-empty-status-code-verify.rb radio-empty-status-audit-build.rb radio-empty-status-verify.nu].each{|p|copy('/tmp/'+p,'reproduction/'+p)}
json(PAYLOAD+'/provenance.json',{created_at:Time.now.utc.iso8601,radio:freeze['base'],hemera:freeze['hemera'],code_review:'pending',note:'Recorded absolute paths are provenance; portable verification executes none of the recorded gate commands. Full current raw streams and separate superseded historical capsule are retained. Bounded review summaries are executor-reported; omitted raw inputs are not claimed reviewed.'})
entries=Dir[PAYLOAD+'/**/*'].select{|p|File.file?(p)}.sort.map{|p|{path:p.delete_prefix(PAYLOAD+'/'),bytes:File.size(p),sha256:Digest::SHA256.file(p).hexdigest}}
json(AUDIT+'/payload-inputs.json',entries)
File.write('/tmp/radio-empty-status-audit-members.txt',entries.map{|r|r[:path]}.join("\n")+"\n")
out,err,status=Open3.capture3({'COPYFILE_DISABLE'=>'1'},'tar','-czf',AUDIT+'/receipts.tar.gz','-C',PAYLOAD,'-T','/tmp/radio-empty-status-audit-members.txt')
raise err unless status.success?
FileUtils.cp(RUN+'/candidate-freeze.json',AUDIT+'/source-freeze.json')
FileUtils.cp('/tmp/radio-empty-status-verify.nu',AUDIT+'/verify.nu')
records=Dir[RUN+'/logs/*.json'].count{|p|JSON.parse(File.read(p)).key?('stdout_sha256')}
json(AUDIT+'/capsule.json',{sha256:Digest::SHA256.file(AUDIT+'/receipts.tar.gz').hexdigest,bytes:File.size(AUDIT+'/receipts.tar.gz'),payload_files:entries.length,payload_bytes:entries.sum{|r|r[:bytes]},command_records:records,raw_streams:records*2,source_files:5,source_freeze_sha256:Digest::SHA256.file(AUDIT+'/source-freeze.json').hexdigest,historical_capsule_sha256:Digest::SHA256.file(OLD+'/audit/2026-10-11-empty-root/receipts.tar.gz').hexdigest})
json(AUDIT+'/review-inputs.json',{code_status:'pending',plan:JSON.parse(File.read('/tmp/radio-empty-status-plan-v1/build.json')),code:JSON.parse(File.read('/tmp/radio-empty-status-code-v1/build.json')),note:'Fresh PLAN APPROVE retained. This snapshot predates current CODE verdict; root will append external verdict/response as outer sidecars. Historical old CODE APPROVE applies only to its separately retained superseded344 scope.'})
puts File.read(AUDIT+'/capsule.json')

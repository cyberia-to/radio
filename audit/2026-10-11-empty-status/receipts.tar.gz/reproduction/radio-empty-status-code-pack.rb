require 'json'
require 'digest'
require 'fileutils'
RUN='/tmp/radio-empty-status.20261011-60036-oi3wr7'
OWNED='/Users/master/cyber/radio-kadek-empty-status'
DEST='/tmp/radio-empty-status-code-v1'
PLAN='/tmp/radio-empty-status-plan-v1'
raise 'frozen CODE package exists' if File.exist?(DEST)
FileUtils.mkdir_p(DEST+'/inputs')
rows=[]
add=lambda do |data,metadata|
 path=DEST+'/inputs/'+format('%03d',rows.length)+'.txt'
 File.binwrite(path,data)
 rows << metadata.merge('file'=>path,'bytes'=>data.bytesize,'sha256'=>Digest::SHA256.hexdigest(data))
end
freeze=JSON.parse(File.read(RUN+'/candidate-freeze.json'))
freeze_paths=freeze.fetch('files').map{|r|r.fetch('path')}
JSON.parse(File.read(PLAN+'/index.json')).each do |r|
 data=File.binread(r.fetch('file'));meta=r.reject{|k,_|%w[file bytes sha256].include?(k)}
 raise 'PLAN input drift' unless Digest::SHA256.hexdigest(data)==r['sha256']
 if freeze_paths.include?(r['path'])
  path=r['path'];data=File.binread(OWNED+'/'+path)
  expected=freeze['files'].find{|entry|entry['path']==path}
  raise 'candidate freeze drift' unless Digest::SHA256.hexdigest(data)==expected['sha256']
  meta={'owner'=>'full final candidate source','path'=>path,'original'=>OWNED+'/'+path,'base_revision'=>freeze['base'],'note'=>'Complete approved-scope implementation source. Unchanged parent constant/docs/equality; production delta only unconditional Fs status guard. Test provenance comment pins current Hemera.'}
 elsif r['owner']=='current task'
  data=File.binread(OWNED+'/.claude/tasks/bao-empty-status/'+r['path'])
  meta['note']='Current task record. Frozen PLAN snapshot is separately preserved with its exact APPROVE review; measured execution and CODE review status are explicit.'
 end
 add.call(data,meta)
end
%w[candidate-freeze.json nextest-bound.json code-gates.md paired-comparison.md].each do |path|
 add.call(File.binread(RUN+'/'+path),{'owner'=>'executor-reported current measurement','path'=>path,'original'=>RUN+'/'+path,'note'=>'Current-origin summary/source identity. Full command records/raw streams remain outside bounded brief; summary inclusion is not reviewer inspection of omitted raw inputs.'})
end
add.call(File.binread(RUN+'/logs/candidate-git-diff.stdout'),{'owner'=>'exact two-existing-file source diff','path'=>'source.patch','original'=>RUN+'/logs/candidate-git-diff.stdout','note'=>'Exact source diff; three new test files are separately included in full.'})
add.call(File.binread(RUN+'/review/plan-review.txt'),{'owner'=>'fresh PLAN review','path'=>'plan-review.txt','original'=>RUN+'/review/plan-review.txt','note'=>'Grok4.7 APPROVE for this current-origin amendment; its timeout-config observation is corrected by nextest-bound.json. This is not CODE approval.'})
overview=<<~TEXT
 Fresh independent CODE review. Return APPROVE or REQUEST CHANGES; blockers separate from advice.
 Current Radio base bc8b6331d3c76cbc011210e13f81e6ea351ef06f and pinned Hemera d5f0a09539360934fb32db9b2e15a91995607db6.
 Scope: unconditional Fs canonical EMPTY Complete{size:0} guard before database lookup, one synthetic-availability comment, cfg(test) wiring and17 independent tests. All five touched source files are full below. sources.json records the initial committed export; candidate-freeze.json identifies the final five-file overlay. Upstream EMPTY literal/docs/equality remain unchanged. No manifest/lock/spec/schema/identity/list/deletion/version change.
 Current witness debug/release each15 pass/2 Fs NotFound failures; final focused all/default/release17 pass and no-default15 pass. Current listing already omits synthetic empty before this patch. Local iroh-docs consumes status and now skips synthetic empty downloads; tombstone identity/validation stays unchanged. See current gate/parent summaries for exact remaining red outcomes, environments and limits; historical344/23f3 gate results are not current evidence.

 Review inputs include full touched sources, relevant complete current owning/status/download callers, full primary literals/tree contract, exact labeled excerpts and complete current witness stdout. Remaining unchanged internals/registry/workspace source, bulk metadata/locks, full compiler/test raw streams, and historical superseded packs are outside this bounded review. Their existence/digest is not a claim that you inspected omitted contents. The durable audit separately preserves them losslessly, including superseded old source/CODE approval with its original baseline label.
 Parent comparison is measured diagnostic evidence, not a blanket regression-free claim. Nextest termination starts30s plus default10s grace; current ci inherits default, verified against0.9.80 source. Local locked/offline, serialized nextest and incremental-cache limits are disclosed. Root owns CODE invocation, commit and ordinary source merge. No release/version/whole-platform approval.
TEXT
File.write(DEST+'/overview.txt',overview)
File.write(DEST+'/index.json',JSON.pretty_generate(rows)+"\n")
body=overview.b+rows.each_with_index.map{|r,i|"\n===== SOURCE #{i+1}: #{r['owner']} / #{r['path']} =====\nSHA256 #{r['sha256']}; #{r['note']}\n".b+File.binread(r['file'])+"\n===== END SOURCE =====\n"}.join
raise "CODE brief exceeds600KB:#{body.bytesize}" if body.bytesize>600_000
File.binwrite(DEST+'/brief.txt',body)
info={bytes:body.bytesize,sha256:Digest::SHA256.hexdigest(body),index_sha256:Digest::SHA256.file(DEST+'/index.json').hexdigest,sections:rows.length,full_git_sources:rows.count{|r|r['revision']},exact_excerpts:rows.count{|r|r['source_revision']},full_candidate_sources:rows.count{|r|r['owner']=='full final candidate source'},candidate_freeze_sha256:Digest::SHA256.file(RUN+'/candidate-freeze.json').hexdigest,source_base:freeze['base'],hemera:freeze['hemera']}
File.write(DEST+'/build.json',JSON.pretty_generate(info)+"\n")
puts JSON.pretty_generate(info)

# Canonical empty BAO root — plan

Stage: v2 Fs status amendment approved with pre-execution compatibility clarification. Serves Kadek phase1
foundation row4 through Radio's authenticated transport prerequisite. Parent
Radio344ac1627ef4cb4544a98d9afc5442be85fe1d15; Hemera23f3bbcff910ea6d504ceb505680a539260869da.
V1 and v2 PLAN approved; prior documents and failures remain frozen. Measure and
pin enumeration before the Fs guard, then execute the remaining approved gates.

## Contract and exact scope

Replace local Hash::EMPTY's zero placeholder with the 32-byte literal
`ea57b2e6b1ec7d2de11b15cb6d7060dd61d247fe0fbf5f7d3fb97a7be9328552`.
Keep its const/public type and all existing method signatures. Rustdoc states
that it is the pinned fixed-chunk empty-tree root, equivalent to the empty
counter0 CHUNK|ROOT leaf and distinct from the plain Hemera particle domain.
The source of truth is Hemera's pinned vectors/hemera.json and tree primitives;
no runtime initializer, alternate EMPTY, compatibility alias or generic helper.
Make Fs logical status agree with its existing synthetic-complete empty storage.

Changed files:

- iroh-blobs/src/hash.rs: constant/docs, strengthen existing test_empty_hash to
  compare computed root with EMPTY, one cfg(test) empty_root module declaration.
  This existing file is 619 lines; disclose the narrow legacy-file exception.
- New iroh-blobs/src/hash/empty_root.rs: literal/domain, raw serialization,
  ticket and leaking-empty-tag tests; declare the two test-only modules below.
- New iroh-blobs/src/hash/empty_root/{stores,remote}.rs: public storage/admission
  and public remote stream tests. Each new source file stays below500 lines.
- iroh-blobs/src/store/fs/meta.rs: after destructuring BlobStatusMsg, if its hash
  equals canonical Hash::EMPTY, send Complete{size:0} and return Ok(()). Keep the
  ordinary DB lookup exactly unchanged. This existing977-line file is a narrow
  exception; use its existing Hash/BlobStatus imports, no new helper or API.
- Task execution/review and measured audit receipts, plus compatibility prose
  in that audit. No specification, dependency, manifest, lock, version change.

No MemStore lifecycle, FsStore checksum/schema/persistence, provider, decoder, parser, registry
package, iroh-docs or iroh-willow production edit. No zero-hash global replacement.
Tests may use the existing concrete StreamPair/Bytes interfaces and a tiny
request-capturing SendStream; this is a byte transport fixture, not a replacement
verifier. Do not expose new production constructors or bypass real verification.

## Steps and decisive checks

1. Freeze the literal oracle and public tests first → verify: exact-parent
   tests-only overlay in a private committed-source archive, debug and release.
   Overlay only test files, cfg(test) declaration and strengthened existing test;
   leave the constant and every production byte unchanged. Keep ordinary success
   assertions: cases reaching the defective constant must fail before repair;
   unchanged controls may pass. Record wrong-key/control results individually.
   Panic, sender closure and timeout are
   failures, never successful asynchronous witnesses. Record actual test counts.
   V1 witness is retained. Before the Fs edit, run the final extended Fs public
   tests on both exact-parent and constant-only overlays; retain NotFound failure.

2. Replace the constant/docs only → verify: literal bytes equal Hash::EMPTY,
   Hash::new(b""), hemera::tree::fixed_chunk_root(b"") and chunk_cv(b"",0,true).
   Explicitly distinguish zero bytes and the published plain-empty particle.
   Preserve the published `hello` tree literal and existing root_policy suite,
   including affected-length ROOT/non-root and ticket controls. The expected
   constant must never be derived solely by calling the production Hash method.

3. Exercise real stores → verify: MemStore add_bytes(empty).temp_tag() returns
   canonical key; after actual add, status Complete{size:0}, reader/get_bytes
   return no data, observe and observe.await_completion give complete(0), and
   export_bao(...,all).bao_to_vec returns exactly eight zero header bytes.
   Include ReadonlyMemStore::new([b"".as_slice()]) as an unchanged
   computed-key control. FsStore repeats real add/read/observe/export, shutdown,
   reopen, exact empty export and canonical status. Explicitly use both Raw and
   HashSeq AddBytesOptions to cover leaking-empty tag format preservation.
   Drop the tags before shutdown; no wait_idle, sleeps, automatic retries or
   implicit network service. All workflows have one finite30s timeout.
   Preserve this existing failing status oracle. Add a separate Fs test covering
   canonical status Complete{0} and has=true on a fresh store and after reopen;
   old zero and hello initially NotFound/has=false; real hello add then Complete5,
   exact read and LE64(5)||hello export before/after reopen. Old zero stays absent.
   Empty Complete is logical synthetic availability, not physical persistence;
   nonempty hello remains on the unchanged DB path. Keep list/get implementation unchanged.
   Measure fresh/after-empty-add list on parent and constant-only code first;
   pin actual observed lists, including any pre/post difference. List enumerates
   persisted rows; has may therefore be true for synthetic empty absent from list.
   Completed probe: parent []→[canonical root], constant-only []→[]; final test
   pins the latter. No existing legacy rows are removed by this repair.
   The separate Fs test is gated by fs-store; assert empty still Complete after
   forced deletion, with zero/nonempty controls unchanged.

4. Test empty input admission and absence of a legacy alias → verify:
   import_bao_reader on exactly LE64(0) accepts the literal canonical key;
   legacy zero and published `hello` key return RequestError::Inner/Error::Io,
   kind Other, detail `invalid size for hash`. Seven bytes give UnexpectedEof.
   A separate fresh-store zero-key observation has empty ranges and is not
   complete; old zero status is NotFound before an observation creates a partial
   handle. Do not assert post-observation NotFound or alter that existing effect.
   Canonical zero-header import itself does not imply actor state mutation.
   Nonempty control is independent LE64(5)||hello with published tree root:
   actual import/read/export succeeds and bytes match. Preserve current range/
   trailing-input policy; this unit changes the root guard only.

5. Reach the actual remote branch → verify: Remote::execute_get with
   StreamPair::new(..., Bytes(LE64(0)), capturing SendStream), root-only all-ranges
   GetRequest::blob(root), then await the real GetProgress. Canonical succeeds with zero
   payload bytes and eight size bytes read; captured serialized Request contains
   the exact requested hash/ranges. Old zero and nonempty `hello` root fail with
   GetError::Decode/DecodeError::LeafHashMismatch{num:ChunkNum(0)}. The canonical
   success drains the existing ResponseDecoder. Wrong hello key here has LE64(0),
   distinct from the successful hello body. Seven bytes return GetError::AtBlobHeaderNext
   wrapping AtBlobHeaderNextError::NotFound; local seven-byte admission instead
   returns RequestError::Inner / Error::Io(UnexpectedEof), as execution.md pins.
   LE64(5)||hello supplies a successful nonempty remote control. No live QUIC,
   relay, timing sample, endpoint identity or broad transport change is needed.

6. Pin byte semantics → verify: Hash raw/from_str, JSON and postcard round trips
   preserve canonical, legacy zero and `hello` bytes. BlobTicket::to_bytes uses
   a fixed endpoint key and literal envelope prefix followed by each exact root;
   parsing does not rewrite zero. Test Raw and HashSeq format fields. The canonical
   EMPTY constant is a semantic sentinel, not a ban on parsing zero bytes.
   TempTag::leaking_empty retains canonical key and requested format for both
   formats; source review verifies no on_drop callback. FsStore step3 exercises
   its sole production caller. Do not add fake tests for registry-owned tombstones.

7. Freeze source and execute gates below → verify: exact files, unchanged
   committed lock, full command/env/timestamp/exit/stdout/stderr receipts, paired
   parent/candidate first diagnostics and per-name outcomes. A test-only format
   correction requires a refreeze and affected checks; production changes require
   renewed relevant tests. Fresh CODE review receives full actual evidence.

## Execution envelope and gates

Use separate parent/witness/candidate git-archive exports of the pinned commits,
excluding only tracked nettools/target with its exact inventory. Keep archive
attributes/symlinks; no original worktree, dependency shim or altered lock enters
builds. The already-authorized metadata receipt proves local-versus-registry
package IDs. Repeat metadata on candidate and compare reverse consumers/lock.
Use actual Rustup1.95.0 Cargo/RUSTC/RUSTDOC for ordinary gates, actual1.89.0 for
MSRV and nightly-2025-10-09 for named docs; RUSTFLAGS=-Dwarnings and owning
RUSTDOCFLAGS=-Dwarnings. Pin installed nextest0.9.80, make0.37.24, deny0.18.9 and
semver0.51.0 to verified binaries/receipts. No tool installation or test run is
claimed by this plan. Coordinate heavy work with root; use two build jobs while
other owned jobs run. Targets are private, clean completed targets after logs,
pre-gate cumulative target guard20GB and hard live guard30GB.

| Scope | Proposed command/check |
|---|---|
| Witness debug/release | `cargo test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --all-features --locked --offline`, then `--release`; strengthened test_empty_hash separately. |
| Candidate direct | Same filters with default, all, no-default features and release/all. Explicit existing test_empty_hash, root_policy, export_pairs and parent_pairs filters; preserve originals. |
| BAO nonempty controls | `cargo test -p cyber-bao --all-features --locked --offline`; no production BAO change. |
| Native broad behavior | Parent and final candidate: `cargo nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --locked --offline --test-threads 1 --profile default --no-fail-fast`; committed30s test bounds. Retain all names/first failures; no inherited PR34 counts or presumed green flips. |
| Owning checks | `cargo clippy --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline -- -D warnings`; strict `cargo doc ... --all-features --no-deps --document-private-items --locked --offline`. |
| Source/format | `git diff --check`, `cargo fmt --all --check`, pinned `cargo make format-check`; compare unchanged baseline diagnostics without reformatting unrelated source. |
| Actual local consumers | `cargo test -p radio-cli -p radio-integration-tests --no-run --locked --offline`; then bounded tests only if compilation succeeds. iroh-docs compile failure here is a consumer blocker, not evidence its registry Hash changed. |
| Required broad compiler | `cargo test --workspace --all-features --no-run --locked --offline`; no uncontrolled all-workspace execution through unrelated known hangs. |
| Named local CI tasks | Workspace nextest `--lib --bins --tests --no-run` and workspace Clippy `--all-targets --lib --bins --tests --benches --examples`, each default/none/all; compiled execution uses named bounded CI profile only if compilation succeeds. Retain exact feature-check/doctest loops and package names from tests.yaml; failures cannot be avoided by substituting renamed packages. `cargo make format-check`; `cargo deny --workspace --all-features --locked check --disable-fetch -Dwarnings` with frozen DB7eebec69c352c7191b1f13eb95dd510eeca5d1de. |
| Named nightly docs | Actual pinned nightly `cargo doc --workspace --all-features --no-deps --document-private-items --locked --offline`, RUSTDOCFLAGS=`--cfg docsrs` as CI; separate strict owning docs above. |
| MSRV | Actual1.89 owning all-target/all-feature check, empty_root/root_policy/export_pairs lib filters; local consumer compilation. No accidental stable tool override. |
| API diagnostics | `cargo semver-checks check-release --manifest-path current/iroh-blobs/Cargo.toml --baseline-root parent/iroh-blobs`, then last tagv0.1.0/f2b1298daa9f635c821d53996c4d1dc4f1042b3d. Preserve scratch manifests/locks and distinguish fresh tool resolution from authoritative committed-lock gates. |

Revalidate the precise named task arguments from the frozen workflows before
execution; retain every actual command, including setup failures. Run current
parent counterpart for each red comparison; matching counts alone are not
parity. Source-mask Clippy failures do not certify new tests. No full cross-target
CI, product/rung, kelvin, four-vendor council or release pass is implied. Radio's
local transport consumers establish nontrivial blast radius; broader policy
closure remains explicit. The committed soft3 component registry at
94af9de717658b3e912bcfccc85409fd29b23a10 maps radio to part_of=soft3; no rung
or kelvin validation runs here. Red required gates require wip/decision accounting.

## Compatibility, failure questions and remaining scope

Computed canonical empty root bytes remain unchanged. Fs empty imports now take
the existing synthetic path, without new DB rows; enumeration follows actual
rows, not logical availability. Legacy canonical rows are not migrated/deleted.
Deleting empty cannot remove synthetic availability, and the status guard masks
the prior missing-inline error on a legacy empty row. No upstream store parity
is claimed. The former all-zero identity stops receiving empty treatment. Zero tickets
retain their bytes and must be rebuilt by their owner if they meant empty data;
no alias, silent migration/re-signing, stored-key rewrite or deployment inventory.
Current registry-owned iroh-docs tombstones remain unchanged by the proved graph.
Future rewiring is a separate compatibility decision. No version/tag/release.

1. Wrong domain/constant? Independent published tree/plain literals and both
   fixed-chunk leaf/root calls distinguish the domains before store tests.
2. Front-end short-circuit hides a broken verifier? Real store publication/export
   and remote ResponseDecoder success bind literal wire bytes to the same root.
3. Zero accepted through another EMPTY branch? Full tracked-Rust hit inventory,
   resolved ownership, negative local/remote admission and zero observation tests.
4. Status accidentally masks absent/nonempty DB records? Fresh/reopened Fs zero
   and hello negatives plus real hello add/read/export; empty is synthetic,
   not a persisted row. Raw/HashSeq controls and MemStore pre-add gap stay explicit.
5. Tests certify the wrong crate or regress nonempty behavior? Isolated metadata
   package IDs, parent tests-only witness, fixed `hello` and existing ROOT/pair
   controls; raw red diagnostics and unchanged source/lock inventories.

Persisted partial checksum/recovery, pre-add status consistency, generic allocator
and work bounds, trailing-data policy and particle/root/length authority stay
separate. Root reviews the frozen plan before a fresh external PLAN invocation;
no additional production edit until amendment approval, no commit/push by executor.

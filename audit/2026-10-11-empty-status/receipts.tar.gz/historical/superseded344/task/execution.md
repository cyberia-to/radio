# Canonical empty root — execution clarifications

Initial PLAN (v1): `/tmp/kadek-empty-root-plan-review.txt`; reviewed research, plan,
bundle, index, verification and verdict retained unchanged under
`/tmp/kadek-empty-root-plan-frozen/` with SHA256SUMS. The initial scope was constant-only; the approved status amendment follows below.

## Admission cases pinned before implementation

| Boundary | Requested root | Response | Exact result after repair |
|---|---|---|---|
| Local import_bao_reader | canonical empty | LE64(0) | success; guard-only, no decoder or store mutation |
| Local import_bao_reader | zero or published hello | LE64(0) | RequestError::Inner / Error::Io, Other, `invalid size for hash` |
| Local import_bao_reader | canonical empty | seven zero bytes | RequestError::Inner / Error::Io, UnexpectedEof |
| Local import_bao_reader | published hello | LE64(5) followed by hello | success through actual decoder and import |
| Remote execute_get | canonical empty | LE64(0) | success through empty guard and ResponseDecoder drain; payload0, size-header8 |
| Remote execute_get | zero or published hello | LE64(0) | GetError::Decode / DecodeError::LeafHashMismatch, chunk0 |
| Remote execute_get | canonical empty | seven zero bytes | GetError::AtBlobHeaderNext / AtBlobHeaderNextError::NotFound |
| Remote execute_get | published hello | LE64(5) followed by hello | success through actual decoder and import |

Reviewer B1 misread the hello-root negative as having a nonempty response. The
reviewed plan instead specifies the zero header for that negative and a separate
nonempty successful control. Both remain; outer error wrappers are explicit here.
Root initially conflated the local bypass with the remote branch; source review
corrected that, and root accepted the correction before implementation:
`api/remote.rs::get_blob_ranges_impl` calls content.drain after the zero guard;
`get.rs::AtBlobHeader::next` constructs ResponseDecoder; AtBlobContent::drain
calls next; `BaoTree::blocks` is at least1; pre_order_chunks_filtered(all) emits
one zero-length ROOT leaf; `io/fsm.rs::next0` hashes and compares it. Local
`api/blobs.rs::import_bao_reader` returns before decoder construction on zero.
The tests use these existing paths, without a production control-flow change.

FsStore empty reopen checks the synthetic complete branch, not persistence or
durability. Its Raw/HashSeq adds also check computed-key versus constant agreement.
Raw zero hash/ticket bytes remain parseable; there is no migration detector or
hint. The metadata-proven registry iroh-blobs domains remain unaffected. Semver
diagnostics will be reported as actual findings, not dismissed as noise.

Execution uses private `/tmp/radio-empty-root.GDc4u3` committed-source closures,
two build jobs and bounded owned targets. No gate outcome is asserted here yet.

## Status amendment discovered before broad gates

The v1 final tests-only parent witness runs16 tests in both debug/release:
9 pass/7 fail; strengthened test_empty_hash separately fails in both. Final
candidate source freeze is SHA256
`1ec379ab1ed9c27b7558d6085853d58b7030d0208843e04cb2924e6a98d204d2`.
Command `cargo test --manifest-path iroh-blobs/Cargo.toml --lib empty_root
--all-features --locked --offline`, actual Rust1.95.0 with RUSTFLAGS=-Dwarnings,
exits101:15 pass/1 fail. Fs status after canonical empty add is NotFound rather
than Complete{size:0}; source and exact stdout/stderr receipts are retained at
`/tmp/radio-empty-root.GDc4u3/logs/candidate-empty-all.*`.
The pipeline stopped before further candidate gates. There was no compiler/test
harness failure and the public assertion remains intact. No Fs code is changed.

Root authorized a v2 PLAN amendment, not its implementation: sole synthetic
empty status guard in store/fs/meta.rs::handle_get_blob_status, with unchanged
ordinary DB lookup and public fresh/add/reopen/zero/hello controls. Full status
routing and the failure are supplied to fresh external review. The first plan
missed that BlobStatus bypasses HashContext's synthetic get_entry_state; this
source-reading error and its measured counterexample remain explicit.

Fresh v2 PLAN APPROVE `/tmp/kadek-empty-root-plan-v2-review.txt` authorizes that
guard after B1's compatibility correction. Approved v2 inputs are preserved at
`/tmp/kadek-empty-root-plan-v2-frozen/`. Root's implementation authorization
includes the measured enumeration control and keeps all prior failure receipts.
The earlier claim that only zero-key behavior changes was too broad: Fs empty
adds stop persisting computed canonical rows. Public list reaches a DB snapshot
and meta::list_blobs_impl enumerates its blobs table, so synthetic availability
does not imply enumeration. Measure both versions before asserting list results.
Existing legacy canonical rows are not migrated and may still be enumerated;
deletion can remove such a row but cannot remove synthetic empty availability.
The guard also bypasses the legacy missing-inline-row status inconsistency.
No upstream/registry store parity or empty persistence proof is claimed.

Enumeration was then measured without assuming a target: the temporary probe
calls actual public list before/after real empty add. Both commands exit0.
Exact parent production: [] then [canonical root]. Approved constant-only
production: [] then []. Both return the same computed canonical key. The source,
source-overlay hashes and full commands/output are under
`/tmp/radio-empty-root.GDc4u3/{fs-enumeration-probe.rs,enumeration-*-source.json,logs/*-enumeration-probe.*}`.
The temporary probe is removed from each archive after its recorded run; the
new permanent Fs test pins the measured constant-only empty lists, status/has,
real hello persistence, zero absence and the crate-private forced-deletion path.

## Approved status implementation and final source freeze

The preceding no-Fs-edit statement records the v1 stop, not the current state.
After v2 approval and compatibility correction, the sole production addition is
four lines in `handle_get_blob_status`: canonical empty replies Complete{0}
before the unchanged DB lookup. No list, deletion, storage-schema or MemStore
production code changed. Final five-path manifest is
`/tmp/radio-empty-root.GDc4u3/source-freeze-v2.json`, SHA256
`54cdc9fd29b957147b1c80fced535344590302d6322f5e7a306566f1e5fc292e`.
The prior four-path manifest remains separately at source-freeze-v1.json,
SHA256 `1ec379ab1ed9c27b7558d6085853d58b7030d0208843e04cb2924e6a98d204d2`;
its original bytes also remain in the frozen v2 PLAN input pack. The current
source-freeze.json is a convenience copy of v2, not the only historical record.

Before the guard, the extended final tests ran on both production variants in
debug and release. Exact-parent tests-only overlay:17 tests,9 pass/8 fail.
Constant-only overlay:17 tests,15 pass/2 fail, both Fs status assertions. Receipts
are logs/{witness,candidate}-status-witness-{debug,release}.{json,stdout,stderr}.
The guard was applied only after these witnesses; no assertion was weakened.
Final owning/candidate source hashes and unchanged lock/source closure are
checked by source-integrity-v2.nu and source-integrity-v2.json. The final gate
matrix is still in progress; this paragraph does not imply its completion.

The actual locked metadata also resolves the named CI package `iroh` and
`iroh-relay` to registry0.96.1, while iroh-bench and iroh-dns-server are local.
The literal named feature loops are retained as required; their green registry
checks do not certify the local cyber-radio package. Actual local consumer
commands remain separate. Metadata is logs/candidate-metadata.stdout at the
pinned parent+five-file overlay, with its command and raw hash receipt.

## Completed local validation

Raw commands/environment/timestamps/exits/output hashes are in the scaffold
logs; code-gates.md and paired-comparison.md index them. Ordinary actual1.95:
empty all/default/release17 pass each, no-default15; existing empty1, ROOT5,
export14, parent pairs11 and BAO71+8+9 all pass. Actual1.89 empty17/ROOT5/export14
pass. Semver0.51 against exact parent and last-tag source both exits0,
202 checks pass/58 skip each; per-baseline helper manifests/locks are retained.
This checks source API against explicitly current pinned Hemera, not historical
release closure or constant/ticket/enumeration compatibility.

Required broad gates remain red. Parent native:124 run,93 pass,26 fail,5 timeout,
2 skipped; candidate:141 run,117 pass,7 fail,17 timeout,2 skipped. No old PASS
becomes FAIL/TIMEOUT. There are7 FAIL→PASS,13 FAIL→TIMEOUT,1 TIMEOUT→FAIL and17
new passes. Three candidate timeouts show the previously hidden persisted
checksum writer panic at store/util.rs:237 (32-byte hash into64-byte slice).
Other timeouts are retained without claiming success; the network failure is
`no viable network path`. No timeout-limit extension or broad rerun was used.

Formatter/compiler counterparts and their exceptions are explicit in the
comparison, not inferred from aggregate counts. Strict private docs expose
unchanged Self::persist; prior PR34 lacked --document-private-items. MSRV
all-target commands first stopped at different examples; four focused paired
checks confirm both custom-protocol and random_store fail on both sources.
Deny has a path-length-dependent diagnostic span delta. Nightly docs stop at
different compiler/rustdoc stages in unchanged iroh-bench, plus iroh-docs errors;
no complete diagnostic parity is claimed. Dependency-masked Clippy does not
certify the new tests; archive build scripts also emit VERGEN warnings.

The20GB staging guard stopped one pending feature command before Cargo; its
receipt remains. Completed targets were cleaned; resume verified prior command,
toolchain and raw hashes and ran only missing cases. All final targets are
cleaned. source-integrity-final.json verifies the final five-path delta, exact
owned/candidate source hashes, identical Hemera exports and unchanged locked
inputs; git diff --check passed. Both historical PLAN bundles reconstruct from
verified preserved bytes via review-history-inputs.json, including the explicit
old-freeze path remap. Fresh CODE review and root's commit/PR decision remain;
no release, rung or foundation-row4 closure is claimed.

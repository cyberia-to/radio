# Canonical empty BAO root — research

Stage: active; Fs status amendment approved, compatibility clarification recorded. Serves Kadek phase 1
foundation row 4, authenticated slice transport.
Discovered from canonical ROOT and native parent-pair repairs. This is source
research, isolated dependency metadata and the narrowly authorized v1 experiment.
The approved constant/tests and pre-amendment failure remain frozen receipts.

## Inputs and closure

Radio origin/main `344ac1627ef4cb4544a98d9afc5442be85fe1d15` was confirmed by
`git ls-remote origin refs/heads/main` on 2026-10-10; source PR34 is merged.
Owned worktree `/Users/master/cyber/radio-kadek-empty-root`, branch
`fix/bao-empty-root`. Hemera `23f3bbcff910ea6d504ceb505680a539260869da` is the
same pinned committed dependency. Dirty original worktrees are excluded.
Applicable doctrine: `~/cyber/AGENTS.md`, `~/cyber/cyberia/dev.md`; no tracked
Radio AGENTS.md/CLAUDE.md exists. Makefile.toml and .github/workflows/{ci.yml,
tests.yaml} name the executable local/CI tasks. New roadmap/soft3-radio.md keeps
verified streaming in radio and separately projects storage replacement; it
supplies no permission to broaden this correction or rewrite dependencies.

Authorized read-only command in exact git-archive exports:
`<rustup-1.95.0>/cargo metadata --locked --offline --format-version 1`, matching
RUSTC/RUSTDOC, no build. Receipt and extracted graph:
`/tmp/radio-empty-root-research.peVg0K/{logs/metadata.json,resolved-blobs.json}`.
Archive setup and metadata succeeded; lock stayed
`295b21c8804e3885a195511ffca6fcf368e7c762c5b411374aecf20ba4d14052`.
Only tracked nettools/target was excluded. Exports honor committed attributes
and symlinks; no blanket Git-blob byte-equality claim.

The graph has two distinct iroh-blobs@0.98.0 package IDs:

- Local `path+file://.../radio/iroh-blobs#0.98.0`, using cyber-bao and pinned
  Hemera. Direct reverse consumers: local radio-cli and radio-integration-tests.
- Registry `registry+https://github.com/rust-lang/crates.io-index#iroh-blobs@0.98.0`,
  checksum `f1f253ea06293e51e166a88a3faa019b67e187d12bd7c6a04369a0ec86f53272`.
  iroh-docs and iroh-willow depend on this BLAKE3 package, not the local one.
  Its EMPTY is `af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262`.
  Archived audit manifests and excluded iroh-ffi's registry0.35 manifests are
  not additional current-workspace local reverse consumers.

Initial text-only suspicion that this repair changes current iroh-docs signed
and persisted tombstones is refuted by the resolved graph. Complete source
traces remain relevant to a future dependency rewiring: sync.rs constructs
Record::empty, validates zero-length/hash pairs, filters is_empty and signs
Entry::to_vec; store/fs/query.rs filters by EMPTY bytes. A future change of that
actual dependency requires explicit compatibility analysis; no such change or
unaffected tombstone test belongs here. No old-zero local-tombstone deployment
or migration is asserted.

## Defect and primary oracle

Local iroh-blobs/src/hash.rs:33–38 defines EMPTY as 32 zero bytes and calls it a
placeholder. Its test_empty_hash compares two computed roots, never the constant.
Hash::new delegates to PreOrderMemOutboard; the current canonical algorithm is
already correct for empty input. The constant repair exposes the Fs status
integration mismatch below; both must agree with synthetic empty availability.

Primary pinned Hemera `vectors/hemera.json`:

| Domain/input | Literal |
|---|---|
| Empty fixed-chunk tree | `ea57b2e6b1ec7d2de11b15cb6d7060dd61d247fe0fbf5f7d3fb97a7be9328552` |
| Plain empty particle | `a67a71b221e6bdd6442a20432bf5d74c885d89e5dfbeec3ec4e334cb806d563c` |
| Tree of `hello` | `626fa46e4e7bd5c87d630eef8333931a0b9198587400a0191eae7821692880d7` |

`rs/src/tree.rs::{hash_leaf,fixed_chunk_root,chunk_cv}` and specs/tree.md pin the
empty single leaf to counter0, CHUNK|ROOT. `rs/tests/vectors.rs` consumes the
published literals. Hash::EMPTY must equal both the literal and the computed
fixed-chunk root; it must differ from all-zero and the plain-particle literal.
CDC root_hash is not substituted for the fixed-chunk interface.

## Bounded source inventory

Commands on committed tracked Rust: `git ls-files '*.rs'` and `git grep -n -E
'Hash::EMPTY|test_empty_hash|leaking_empty|empty_hash|Hash::from_bytes\(\[0|Hash::from\(\[0'
-- '*.rs'`; 587 tracked Rust paths were in the textual search scope. Every hit
was read in context and assigned its resolved owner. This is a bounded inventory,
not an audit of arbitrary external consumers. Exact hit lists are retained at
`/tmp/kadek-empty-root-{references,specialcases}.txt` for the review pack.

| Local owner/path | Effect of the canonical constant |
|---|---|
| api/blobs.rs:384 | Immediate complete(0) observation moves from zero key to canonical key. |
| api/blobs.rs:446 | Eight-byte zero-size header accepted only for canonical key; former zero gets `Other / invalid size for hash`. |
| api/remote.rs:914 | Zero-size remote root guard moves to canonical key; successful path still drains ResponseDecoder and verifies the leaf. Old remote path is not claimed to have accepted a zero root. |
| store/mem.rs:129,419,427 | Distinguished handle creation/get/get-or-create uses canonical key. Empty add already computes canonical bytes. |
| store/fs.rs:286,411 | Synthetic complete empty storage and inline entry-state lookup use canonical key. |
| store/fs.rs:581,1011 | Empty import completion skips persistence and returns leaking_empty for canonical key. |
| store/fs.rs:1204 | Canonical zero-size export proceeds; unknown zero-size records remain suppressed. |
| util/temp_tag.rs:90–98 | Leaking empty tag uses canonical hash, caller-supplied format, no drop callback. Only production caller is FsStore completion. |

ReadonlyMemStore has no EMPTY branch: its supplied empty body gets its key from
CompleteStorage::create. It is a useful unchanged computed-key control.
Hash::from_bytes/from_str, serde and BlobTicket preserve supplied raw bytes;
they do not validate an empty-file claim or rewrite a legacy zero key.

Other zero literals are distinct: HashBackend::zero_hash is a placeholder,
fs/import.rs::compute_outboard overwrites its placeholder through init_outboard,
protocol tests use arbitrary bytes, fs::tests::smoke sets arbitrary tagged keys,
parent-pair tests use a dummy reader root. iroh-willow's default hash belongs to
the registry package. No blind zero-literal replacement is justified.

Source-only limitation: MemStore initializes its distinguished handle as Partial
with Bitfield::empty, so pre-add status is Partial{None}, while public observe
shortcuts to complete(0). This MemStore pre-add status/lifecycle inconsistency
is a separate discovered task. Required complete
MemStore status assertions here follow a real add; zero-header admission itself
returns before actor mutation. Trailing-header bytes and empty-range policy
are also unchanged and must not be implicitly tightened by the tests.

## Fs status discovered during v1 execution

At the pinned parent, final test-only debug/release witnesses execute16 new tests:
9 pass and7 fail; the strengthened existing empty test also fails in each mode.
The approved constant-only candidate freeze
`1ec379ab1ed9c27b7558d6085853d58b7030d0208843e04cb2924e6a98d204d2`
then executes15 pass/1 fail: Fs canonical status is NotFound after real empty add,
where the retained public oracle requires Complete{size:0}. Exact commands,
source manifest and raw output: `/tmp/radio-empty-root.GDc4u3/logs/` and
`source-freeze.json`; decisive receipt `candidate-empty-all.json`, exit101.
This is an observed mismatch, not an assumed green flip or a weakened assertion.

Complete tracked source trace (`rg -n 'GetBlobStatus|handle_get_blob_status|BlobStatusMsg|BlobStatusRequest'`
over api/blobs.rs, api/proto.rs, store/fs.rs and store/fs/**): Blobs::status and
has send BlobStatusRequest; the Fs actor forwards to the metadata command;
meta/proto.rs::ReadOnlyCommand::GetBlobStatus dispatches through handle_readonly
to the sole handle_get_blob_status. That handler reads tables directly and maps
None to NotFound. It never uses HashContext::get_entry_state's synthetic branch.
Fs empty FinishImport now correctly returns a leaking tag without persistence,
so the canonical key reaches the latent DB-only status mismatch. The required
amendment belongs at that final status handler; generic DB get/list remain intact.
Logical Complete means the full file can be read/exported, not that a DB row was
persisted. Empty reopen tests its synthetic availability, not empty-file durability.
The new file in production scope, store/fs/meta.rs, is977 lines at the parent;
the proposed early return is a narrow existing-file exception, with no new API.

## Compatibility and unresolved work

Computed empty root bytes stay the same. Fs canonical empty availability changes
to its synthetic path: fresh/post-fix empty adds create no persisted row. Listing
routes from Blobs::list to the Fs actor's DB snapshot and meta::list_blobs_impl,
which enumerates snapshot.blobs; it does not synthesize empty. Isolated public
enumeration probes (`cargo test --manifest-path iroh-blobs/Cargo.toml --lib
fs_enumeration_probe --all-features --locked --offline -- --nocapture`, Rust1.95.0)
both exit0: parent fresh=[] then after-empty-add=[canonical root]; constant-only
fresh=[] then after-empty-add=[]. The computed key is identical. Exact probe
source and receipts are in `/tmp/radio-empty-root.GDc4u3/fs-enumeration-probe.rs`
and logs/{witness,candidate}-enumeration-probe.*. Existing legacy
canonical rows are not removed or migrated and can remain enumerated. Deletion
cannot remove synthetic logical availability (status remains Complete); on a
fresh store it removes no row, while a legacy row may be removed. The status
guard also bypasses the prior inconsistent-inline-row error for canonical empty.
No registry/upstream store parity is established or claimed. The local
all-zero special-case identity ceases to denote empty content: old zero-key
requests fail empty admission, raw tickets remain zero-valued, and an unknown
zero key is not advertised complete. Recreate empty references/tickets from the
canonical key where necessary; no compatibility alias, automatic rewrite,
deployment inventory, migration, version bump or release is supplied.

Remaining gates must determine precise public outcomes and old/new transitions;
the v1 evidence above is scoped, not a conformance pass. Prior PR34 audit
is context only: required broad gates/CI were red or queued. Its hosted snapshot
`/tmp/kadek-memstore-pairs-hosted/` records seven CI jobs failing missing sibling
Hemera before compilation, separate codespell failure and 17 queued self-hosted
jobs; the additional docs-preview job also lacks Hemera. These are historical
PR34 outcomes, not this branch's CI or eight identical failures. No inherited pass
or prior aggregate failing-test count is claimed for this unit. Parent-pair
and ROOT controls will run unchanged; persisted checksum/recovery, bounded
proof allocation/work and authenticated particle/root/length association stay
separate. Foundation row4 remains open after this empty-root repair.

Fresh review inputs are enumerated by exact owner/revision/path/SHA in
`/tmp/kadek-empty-root-plan-v2-index.json`; the complete relevant Rust files,
primary sources and explicit lock excerpt are in its paired plan-bundle.txt.
V1 documents/bundle/verdict remain unchanged under /tmp/kadek-empty-root-plan-frozen/.
The amendment pack includes full status owners, frozen v1 candidate tests and
the actual failure. Fresh v2 APPROVE requires the enumeration measurement and
these compatibility clarifications before the already-authorized implementation.

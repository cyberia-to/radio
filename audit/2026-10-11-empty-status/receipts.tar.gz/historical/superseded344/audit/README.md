# Canonical empty BAO root

Source repair complete; independent CODE review pending. Required broad gates
remain red. This audit does not close Kadek foundation row 4 or approve a release.

Radio base `344ac1627ef4cb4544a98d9afc5442be85fe1d15`, Hemera
`23f3bbcff910ea6d504ceb505680a539260869da`, plus the five-path local overlay in
[source-freeze.json](source-freeze.json). Its SHA256 is
`54cdc9fd29b957147b1c80fced535344590302d6322f5e7a306566f1e5fc292e`.
All command results below refer to those pinned inputs, executed on October 10;
evidence was verified and packaged on October 11. The original worktree was not
edited by this task. No manifest, authoritative lock, specification or version
changes are included.

## Change and compatibility

`Hash::EMPTY` now contains the published fixed-chunk empty ROOT
`ea57b2e6b1ec7d2de11b15cb6d7060dd61d247fe0fbf5f7d3fb97a7be9328552`.
Computed empty roots already had these bytes; the previous constant was zero.
The existing equality test now checks the constant. Fs logical status gains one
four-line guard so its existing synthetic empty storage reports `Complete{0}`.

Empty Fs imports now take the existing synthetic path and create no row. Actual
enumeration probes observed parent `[]` then `[canonical root]`, and constant-only
candidate `[]` then `[]`, before and after a real empty add. The final tests preserve
this distinction between availability and enumeration. Existing canonical rows
are not migrated or deleted; they may still enumerate. Deleting such a row cannot
remove synthetic empty availability. The guard also bypasses a legacy
missing-inline-row status error for that key. No upstream-store parity is claimed.

Raw zero identities and tickets keep their bytes when parsed. They cease to receive
canonical-empty admission; references that intended empty data need its canonical
root. No automatic migration, alias or deployment inventory is supplied. Locked
metadata distinguishes local Hemera-based `iroh-blobs` from the registry BLAKE3
package used by current `iroh-docs` and `iroh-willow`; their tombstones are outside
this change. MemStore's pre-add status/observe inconsistency remains open.

## Measured checks

Exact argv, environment, timestamps, exits and untouched stdout/stderr are inside
[receipts.tar.gz](receipts.tar.gz), under `logs/`. Commands used matching Rustup
Cargo/RUSTC/RUSTDOC: ordinary 1.95.0, MSRV 1.89.0, named docs nightly-2025-10-09.
Locked offline builds used two jobs and `RUSTFLAGS=-Dwarnings`. Archive build
scripts emit VERGEN warnings; successful exits do not imply all output was free
of warnings. Every receipt is indexed by the filenames used below.

| Command/scope | Result |
|---|---|
| `cargo test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --all-features --locked --offline`; default and release variants | 17 pass each; no-default variant 15 pass |
| Same owning test command, filters `test_empty_hash`, `root_policy`, `export_pairs`, `parent_pairs` | 1, 5, 14, 11 pass |
| `cargo test -p cyber-bao --all-features --locked --offline` | 71 + 8 + 9 pass |
| Actual MSRV owning filters `empty_root`, `root_policy`, `export_pairs` | 17, 5, 14 pass |
| `cargo semver-checks check-release --manifest-path iroh-blobs/Cargo.toml --baseline-root … --verbose`, exact parent and `v0.1.0` source | Both exit 0: 202 checks pass, 58 skipped |
| Owning all-target Clippy; strict private owning rustdoc | Both exit 101 on parent and candidate; first errors `clone_on_copy` in BAO and unresolved `Self::persist` respectively |
| `cargo fmt --all --check`; `cargo make --disable-check-for-updates format-check` | Parent/candidate exit 1 / 105 respectively; 340 / 460 normalized formatter hunks match |
| Workspace all-feature no-run; actual local-consumer no-run | Exit 101 on both: `find_providers` incompatible trait signature in unchanged `iroh-docs` |
| Named workspace nextest no-run and Clippy feature loops | Red on both; paired normalized error blocks retained |
| Actual MSRV all-target checks | Exit 101 on both, stopping at different examples; focused checks confirm both examples fail on both sources |
| Named nightly workspace private docs | Exit 101 on both; different compiler/rustdoc stages reached, so full diagnostic parity is not claimed |
| `cargo deny --workspace --all-features --locked check --disable-fetch -Dwarnings` | Exit 13 on both; frozen advisory DB; path-length-dependent license diagnostic column/padding difference retained |

Native comparison used `cargo nextest run --manifest-path iroh-blobs/Cargo.toml
--lib --all-features --locked --offline --test-threads 1 --profile default
--no-fail-fast`, with unchanged 30-second bounds. Parent: 124 run, 93 pass,
26 fail, 5 timeout; candidate: 141 run, 117 pass, 7 fail, 17 timeout. Both skip
two tests. Per-name transitions are 93 PASS→PASS, seven FAIL→PASS, thirteen
FAIL→TIMEOUT, six FAIL→FAIL, four TIMEOUT→TIMEOUT, one TIMEOUT→FAIL and seventeen
new passes. No previously passing test failed or timed out in this measurement.
Three new timeouts expose an existing persisted-checksum writer panic at
`store/util.rs:237` (32-byte source into a 64-byte destination); other timeouts
remain failures with unestablished causes. The TIMEOUT→FAIL reports no viable
network path. No broader regression-free or conformance claim follows.

Failure-first witnesses are retained. Original tests-only parent: 16 new tests,
9 pass/7 fail in debug and release; strengthened existing empty test fails
separately. Constant-only candidate exposed Fs `NotFound`. Extended witnesses:
parent 17 tests, 9 pass/8 fail; constant-only 17 tests, 15 pass/2 fail. Both Fs
assertions were kept before the approved guard made the final scope pass.
Recorded enumeration commands are `witness-enumeration-probe` and
`candidate-enumeration-probe`; final outcomes are in `candidate-empty-all-v2`,
`candidate-empty-default`, `candidate-empty-none` and `candidate-empty-release`.

Compiler masking means Clippy did not certify the new tests. Semver checks concern
source API using current pinned Hemera and separately retained helper locks;
they do not certify historical release closure, constant values or ticket and
enumeration compatibility. Literal CI package names `iroh`/`iroh-relay` resolve to
registry packages; their green default checks do not certify local cyber-radio.
The capsule's `execution/paired-comparison.md` records exact exceptions, including
MSRV declaration-line movement and differing nightly diagnostics.

## Evidence and review boundary

[capsule.json](capsule.json) identifies the lossless capsule;
[payload-inputs.json](payload-inputs.json) lists every file and its exact digest.
It preserves 209 command receipts and 418 raw streams, including setup failures,
the staging guard, red gates, warnings, and original whitespace. Completed build
targets were cleaned after their receipts were retained. No broad matrix was
repeated during packaging.

The capsule contains:

- `logs/` and `execution/`: full records, summaries, source identities, toolchain
  evidence, historical runner scripts and gate comparisons.
- `sources/`: frozen final, final witness and changed parent source owners.
- `reviews/plan-v1/` and `reviews/plan-v2/`: original approved plans, verdicts,
  bundles, indexes and byte-identical inputs with portable relocation indexes.
- `reviews/code-complete/`: the complete prepared source/evidence package and its
  independent reconstruction receipts. Its duplicate raw streams resolve by
  basename and digest to `logs/`.
- `reviews/code-bounded/`: the smaller CODE brief, exact inputs and root's
  independent verification. It contains five full candidate files, eighteen full
  Git sources and three explicitly marked primary excerpts. Raw gate evidence,
  bulk metadata/locks and specified unchanged internals are omitted from this
  bounded brief. Its gate summary is executor-reported evidence, not a claim that
  a reviewer inspected omitted inputs.
- `semver/`: actual generated helper manifests/locks and source manifests.

[review-inputs.json](review-inputs.json) records both CODE package identities.
CODE review remains pending in this snapshot. Prior PLAN approvals authorize the
scoped implementation, not release or promotion. Required red gates need explicit
`wip:`/`decision` accounting when root commits and merges the ordinary source fix.
Persisted incomplete checkpoints, bounded proof allocation/work and sealed
particle/root/length association remain separate foundation work.

Verify without running recorded commands:

```sh
nu audit/2026-10-11-empty-root/verify.nu --source-root .
```

The recorded [verification command](verification.json) exits 0; its
[complete output](verification.stdout) identifies the checked capsule and counts.

The verifier uses Nushell and `tar`, checks outer and payload digests, matches
raw streams to every command record, reconstructs all four review bundles, and
optionally checks the current checkout's five source files. Successful temporary
extraction is removed. Historical runner scripts retain their original absolute
paths as provenance; they are not portable gate runners and are never invoked by
the verifier.

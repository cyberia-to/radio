use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let initial = (open ($run | path join logs parent-native-clippy.json))
 let stderr = (open --raw ($run | path join logs parent-native-clippy.stderr))
 if $initial.exit == 0 or not ($stderr | str contains 'SIGKILL') { error make {msg: 'retry requires retained interrupted first comparison'} }
 let args = ($initial.argv | skip 1)
 let receipt = ($run | path join logs parent-native-clippy-after-sigkill.json)
 if not ($receipt | path exists) {
  let outcome = (^nu ($run | path join gate.nu) --scope parent --name native-clippy-after-sigkill --execute --args ($args | to json --raw) | complete)
  print $outcome.stdout
 }
 if not ($receipt | path exists) { error make {msg: 'missing retry receipt'} }
 let actual = (open $receipt)
 if ($actual.argv | skip 1) != $args { error make {msg: 'followup argv mismatch'} }
 for stream in [stdout stderr] {
  if (sha ($run | path join logs $'parent-native-clippy-after-sigkill.($stream)')) != ($actual | get $'($stream)_sha256') { error make {msg: 'followup raw drift'} }
 }
 {original: 'parent-native-clippy', followup: 'parent-native-clippy-after-sigkill', exact_cargo_args: $args, reason: 'First comparison rustc derive_builder process received SIGKILL before owning dependency lint diagnostics. One exact-command follow-up preserves initial interruption separately; no matrix rerun.'} | to json | save ($run | path join parent-native-clippy-followup.json)
}

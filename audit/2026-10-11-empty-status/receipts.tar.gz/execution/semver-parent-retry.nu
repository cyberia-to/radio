use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let initial = (open ($run | path join logs candidate-semver-parent-iroh-blobs.json))
 if $initial.exit == 0 or not (open --raw ($run | path join logs candidate-semver-parent-iroh-blobs.stderr) | str contains 'SIGKILL') { error make {msg: 'followup requires interrupted initial semver'} }
 cd $initial.cwd
 let name = 'candidate-semver-parent-iroh-blobs-after-sigkill'
 let before = ((usage $run) + (usage /tmp/radio-gate-tools))
 if $before >= 20000000000 { error make {msg: '20GB staging threshold'} }
 let prior = ([current parent tag] | each {|scope| {scope: $scope, sha256: (sha ($run | path join semver $scope radio Cargo.lock))}})
 let result = (record $run $name $initial.argv $initial.environment)
 let after = ((usage $run) + (usage /tmp/radio-gate-tools))
 {before_bytes: $before, after_bytes: $after, prior_locks: $prior, after_locks: ([current parent tag] | each {|scope| {scope: $scope, sha256: (sha ($run | path join semver $scope radio Cargo.lock))}}), note: 'Exact follow-up, fresh helper resolution; original authoritative inputs remain separately frozen.'} | to json | save ($run | path join logs $'($name).usage.json')
 let generated = ($run | path join targets semver semver-checks)
 let retained = ($run | path join semver-generated parent-after-sigkill)
 let files = (checked [rg --files --hidden -g Cargo.toml -g Cargo.lock -g lib.rs $generated] | lines)
 let copies = ($files | each {|source|
  let relative = ($source | path relative-to $generated)
  let target = ($retained | path join $relative)
  mkdir ($target | path dirname)
  cp $source $target
  {source: $source, retained: $target, sha256: (sha $source)}
 })
 {original: 'candidate-semver-parent-iroh-blobs', followup: $name, files: $copies, note: 'One exact argv/environment follow-up after original helper darling compiler SIGKILL. Original attempt and helper files retained. No matrix rerun; source API only, separate fresh resolution.'} | to json | save ($run | path join semver-parent-followup.json)
 let cleanup = (record $run semver-clean-after-parent-sigkill [($initial.argv | first) clean --target-dir $initial.environment.CARGO_TARGET_DIR] $initial.environment)
 if $cleanup.exit_code != 0 { error make {msg: 'followup cleanup failed'} }
}

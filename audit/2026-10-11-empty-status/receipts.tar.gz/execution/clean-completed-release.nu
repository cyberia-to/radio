use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let proof = (open ($run | path join logs candidate-empty-release.json))
 if $proof.exit != 0 { error make {msg: 'release result not completed green'} }
 let path = ($run | path join targets candidate release)
 required $run release-clean-before [du -sk $path] | ignore
 let processes = (required $run release-clean-processes [ps -axo command])
 if ($processes | lines | any {|line| ($line | str contains '/bin/cargo ') and ($line | str contains '--release') and ($line | str contains 'iroh-blobs')}) { error make {msg: 'release command active'} }
 required $run release-clean-completed-artifacts [rm -r $path] | ignore
 required $run release-clean-after [du -sk ($run | path join targets)] | ignore
}

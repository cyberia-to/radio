use common.nu *
def main [scope: string, suffix: string] {
 let run = $env.FILE_PWD
 if $scope not-in [candidate parent] { error make {msg: 'owned scope required'} }
 let path = ($run | path join targets $scope debug incremental)
 if not ($path | path exists) { error make {msg: 'no completed incremental cache'} }
 required $run $'($scope)-incremental-before-($suffix)' [du -sk $path] | ignore
 required $run $'($scope)-incremental-clean-($suffix)' [rm -r $path] | ignore
 required $run $'($scope)-incremental-after-($suffix)' [du -sk ($run | path join targets)] | ignore
}

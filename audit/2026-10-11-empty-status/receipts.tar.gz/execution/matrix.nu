use common.nu *
def main [scope: string, phase: string, --resume] {
 let run = $env.FILE_PWD
 let scoped = [
  {name: empty-default, args: [test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --locked --offline]}
  {name: empty-none, args: [test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --no-default-features --locked --offline]}
  {name: empty-release, args: [test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --release --all-features --locked --offline]}
  {name: empty-existing, args: [test --manifest-path iroh-blobs/Cargo.toml --lib test_empty_hash --all-features --locked --offline]}
  {name: native-root-policy, args: [test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --all-features --locked --offline]}
  {name: native-export, args: [test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --all-features --locked --offline]}
  {name: native-parent-pairs, args: [test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline]}
  {name: bao-all, args: [test -p cyber-bao --all-features --locked --offline]}
 ]
 let broad = [
  {name: format, args: [fmt --all -- --check]}
  {name: native-clippy, args: [clippy --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline -- -D warnings]}
  {name: native-doc, args: [doc --manifest-path iroh-blobs/Cargo.toml --all-features --no-deps --document-private-items --locked --offline]}
  {name: workspace-no-run, args: [test --workspace --no-run --locked --offline]}
  {name: consumers-nextest, args: [nextest run -p iroh-docs -p radio-cli -p radio-integration-tests --all-features --lib --bins --tests --locked --offline --profile default --test-threads '1' --no-fail-fast]}
  {name: native-nextest, args: [nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --locked --offline --test-threads '1' --profile default --no-fail-fast]}
  {name: named-format, args: [make --disable-check-for-updates format-check]}
  {name: named-nextest-all, args: [nextest run --workspace --all-features --lib --bins --tests --no-run --locked --offline]}
  {name: named-nextest-none, args: [nextest run --workspace --no-default-features --lib --bins --tests --no-run --locked --offline]}
  {name: named-nextest-default, args: [nextest run --workspace --lib --bins --tests --no-run --locked --offline]}
  {name: named-clippy-all, args: [clippy --workspace --all-features --all-targets --lib --bins --tests --benches --examples --locked --offline -- -D warnings]}
  {name: named-clippy-none, args: [clippy --workspace --no-default-features --all-targets --lib --bins --tests --benches --examples --locked --offline -- -D warnings]}
  {name: named-clippy-default, args: [clippy --workspace --all-targets --lib --bins --tests --benches --examples --locked --offline -- -D warnings]}
  {name: named-deny, args: [deny --workspace --all-features --locked check --disable-fetch -Dwarnings]}
  {name: named-doctests-all, args: [test --workspace --all-features --doc --locked --offline]}
 ]
 let msrv = [
  {name: msrv-workspace, args: [check --workspace --all-targets --locked --offline]}
  {name: msrv-native-check, args: [check --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline]}
  {name: msrv-empty, args: [test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --all-features --locked --offline]}
  {name: msrv-root-policy, args: [test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --all-features --locked --offline]}
  {name: msrv-export, args: [test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --all-features --locked --offline]}
  {name: msrv-parent-pairs, args: [test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline]}
  {name: msrv-consumers, args: [test -p iroh-docs -p radio-cli -p radio-integration-tests --no-run --locked --offline]}
 ]
 let feature_cases = ([all none default] | each {|features|
  let flag = if $features == all { [--all-features] } else if $features == none { [--no-default-features] } else { [] }
  [iroh iroh-bench iroh-dns-server iroh-relay] | each {|package|
   [{name: $'named-feature-($features)-($package)', args: ([check -p $package --lib --bins --locked --offline] | append $flag)}
    {name: $'named-doctest-($features)-($package)', args: ([test -p $package --doc --locked --offline] | append $flag)}]
  } | flatten
 } | flatten)
 let cases = if $phase == scoped { $scoped } else if $phase == broad { $broad } else if $phase == msrv { $msrv } else if $phase == features { $feature_cases } else { error make {msg: 'unknown phase'} }
 for item in $cases {
  if $scope == parent and $item.name == msrv-empty { continue }
  let receipt = ($run | path join logs $'($scope)-($item.name).json')
if ($receipt | path exists) {
 if not $resume { error make {msg: $'existing receipt: ($receipt)'} }
 let prior = (open $receipt)
 let wanted_toolchain = if $phase == msrv { '1.89.0' } else { '1.95.0' }
 if ($prior.argv | skip 1) != $item.args or $prior.environment.RUSTUP_TOOLCHAIN != $wanted_toolchain { error make {msg: 'existing command identity differs'} }
 for stream in [stdout stderr] {
  if (sha ($run | path join logs $'($scope)-($item.name).($stream)')) != ($prior | get $'($stream)_sha256') { error make {msg: 'existing raw stream drift'} }
 }
 print $'retained ($scope)-($item.name) exit ($prior.exit)'
 continue
}
  let outcome = (^nu ($run | path join gate.nu) --scope $scope --name $item.name --toolchain (if $phase == msrv { '1.89.0' } else { '1.95.0' }) --execute --args ($item.args | to json --raw) | complete)
  print $outcome.stdout
  if $outcome.stderr != '' { print --stderr $outcome.stderr }
  if not ($receipt | path exists) { error make {msg: 'gate runner failed before receipt'} }
if $phase == scoped and $outcome.exit_code != 0 { error make {msg: 'scoped gate red; inspect before continuing'} }
if ($item.name | str starts-with 'named-nextest-') and $outcome.exit_code == 0 {
 let feature = ($item.name | str replace 'named-nextest-' '')
 let flags = if $feature == all { [--all-features] } else if $feature == none { [--no-default-features] } else { [] }
 for action in [list run] {
  let name = $'ci-($action)-($feature)'
  let args = if $action == list { [nextest list --workspace --lib --bins --tests --run-ignored ignored-only --locked --offline] | append $flags } else { [nextest run --workspace --lib --bins --tests --profile ci --run-ignored default --no-fail-fast --message-format human --test-threads '1' --locked --offline] | append $flags }
  let status = (^nu ($run | path join gate.nu) --scope $scope --name $name --execute --args ($args | to json --raw) | complete)
  print $status.stdout
  if $status.stderr != '' { print --stderr $status.stderr }
  if not (($run | path join logs $'($scope)-($name).json') | path exists) { error make {msg: 'CI gate runner failed before receipt'} }
 }
}
 }
}

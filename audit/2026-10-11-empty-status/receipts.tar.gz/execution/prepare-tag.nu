use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let repo = '/Users/master/cyber/radio-kadek-empty-status'
 required $run tag-nearest [git -C $repo describe --tags --abbrev=0 HEAD] | ignore
 required $run tag-revision [git -C $repo rev-parse v0.1.0] | ignore
 let revision = 'f2b1298daa9f635c821d53996c4d1dc4f1042b3d'
 let dst = ($run | path join tag)
 if ($dst | path exists) { error make {msg: 'tag closure exists'} }
 mkdir ($dst | path join radio)
 mkdir ($dst | path join hemera)
 required $run tag-archive [git -C $repo archive --format=tar $revision --output ($run | path join archives tag-radio.tar) -- . ":(exclude)nettools/target"] | ignore
 required $run tag-radio-extract [tar -xf ($run | path join archives tag-radio.tar) -C ($dst | path join radio) --exclude=nettools/target] | ignore
 required $run tag-hemera-extract [tar -xf ($run | path join archives hemera.tar) -C ($dst | path join hemera)] | ignore
 {radio_revision: $revision, hemera_revision: 'd5f0a09539360934fb32db9b2e15a91995607db6', note: 'Last-tag source API diagnostic with explicitly pinned current Hemera dependency; tag manifest has unversioned sibling path, not a historical release closure.', excluded: ['nettools/target'], radio_archive_sha256: (sha ($run | path join archives tag-radio.tar)), tag_lock_sha256: (sha ($dst | path join radio Cargo.lock))} | to json | save ($run | path join tag-sources.json)
}

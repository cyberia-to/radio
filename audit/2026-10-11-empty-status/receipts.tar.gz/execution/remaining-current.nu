def main [] {
 let run = $env.FILE_PWD
 for args in [[($run | path join matrix.nu) candidate features --resume] [($run | path join finish-current.nu)]] {
  let result = (^nu ...$args | complete)
  print $result.stdout
  if $result.stderr != '' { print --stderr $result.stderr }
  if $result.exit_code != 0 { error make {msg: 'remaining phase stopped; completed receipts remain untouched'} }
 }
}

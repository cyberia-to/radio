use common.nu *
def main [toolchain: string] {
 let run = $env.FILE_PWD
 let candidates = (glob ($run | path join logs 'candidate-*.json') | where {|p| not ($p | str ends-with '.usage.json')} | each {|p| {path: $p, data: (open $p)}} | where {|r| ($r.data.argv? | default [] | length) > 1 and ($r.data.argv.0 | str ends-with '/cargo') and $r.data.argv.1 != clean and ($r.data.environment.RUSTUP_TOOLCHAIN? | default '') == $toolchain and ($r.data.exit != 0 or ($r.path | path basename) == 'candidate-native-nextest.json')} | sort-by {|r| $r.data.started})
 for item in $candidates {
let original_name = ($item.path | path basename | str replace 'candidate-' '' | str replace '.json' '')
let cases = if ($original_name | str starts-with 'ci-run-') {
 open --raw ($run | path join logs $'candidate-($original_name).stderr') | lines | parse --regex '^\s*(?<status>FAIL|TIMEOUT)\s+\[[^\]]+\]\s+(?<binary>\S+)\s+(?<test>\S+)' | uniq
} else { [] }
let name = if ($cases | is-empty) { $original_name } else { $'($original_name)-failed-cases' }
let args = if ($cases | is-empty) { $item.data.argv | skip 1 } else {
 let expression = ($cases | each {|case| (['(binary_id(=' $case.binary ') and test(=' $case.test '))'] | str join)} | str join ' or ')
 $item.data.argv | skip 1 | append [-E $expression]
}
if not ($cases | is-empty) {
 let mapping = ($run | path join $'counterpart-($original_name).json')
 let data = {candidate: $original_name, parent: $name, selected_cases: $cases, candidate_argv: $item.data.argv, parent_cargo_args: $args, note: 'Root explicitly authorized exact failed-case-only CI runtime comparison. Same features/profile/environment/timeout policy, additional exact binary_id/test filter. No whole-parent CI matrix result is claimed.'}
 if not ($mapping | path exists) { $data | to json | save $mapping } else if (open $mapping) != $data { error make {msg: 'counterpart scope drift'} }
}
  let receipt = ($run | path join logs $'parent-($name).json')
  if ($receipt | path exists) {
   let prior = (open $receipt)
   if ($prior.argv | skip 1) != $args { error make {msg: 'parent counterpart command mismatch'} }
   for stream in [stdout stderr] { if (sha ($run | path join logs $'parent-($name).($stream)')) != ($prior | get $'($stream)_sha256') { error make {msg: 'parent raw stream drift'} } }
   print $'retained parent-($name) exit ($prior.exit)'
   continue
  }
  if (usage $run) > 18000000000 {
   ^nu ($run | path join clean-scope.nu) parent $'counterpart-before-($name)'
   if $env.LAST_EXIT_CODE != 0 { error make {msg: 'counterpart cleanup failed'} }
  }
  let extra = if $toolchain == 'nightly-2025-10-09' { [--ci-docs] } else { [] }
  let outcome = (^nu ($run | path join gate.nu) --scope parent --name $name --toolchain $toolchain --execute --args ($args | to json --raw) ...$extra | complete)
  print $outcome.stdout
  if $outcome.stderr != '' { print --stderr $outcome.stderr }
  if not ($receipt | path exists) { error make {msg: 'parent gate runner failed before receipt'} }
 }
}

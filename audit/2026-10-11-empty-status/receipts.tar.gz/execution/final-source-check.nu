use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let freeze = (open ($run | path join candidate-freeze.json))
 let sources = (open ($run | path join sources.json))
 for tree in ['/Users/master/cyber/radio-kadek-empty-status' ($run | path join candidate radio)] {
  for row in $freeze.files {
   if (sha ($tree | path join $row.path)) != $row.sha256 { error make {msg: 'final source freeze drift'} }
  }
  if (sha ($tree | path join Cargo.lock)) != $sources.lock_sha256 { error make {msg: 'authoritative lock drift'} }
 }
 cd /Users/master/cyber/radio-kadek-empty-status
 required $run final-git-diff-check [git diff --check] | ignore
 required $run final-git-head [git rev-parse HEAD] | ignore
 required $run final-git-status [git status --porcelain=v1 --untracked-files=all] | ignore
 required $run final-git-diff [git diff --binary -- iroh-blobs/src/hash.rs iroh-blobs/src/store/fs/meta.rs] | ignore
 required $run final-origin-radio [git ls-remote origin refs/heads/main] | ignore
 required $run final-origin-hemera [git -C /Users/master/cyber/hemera ls-remote origin refs/heads/main] | ignore
 {radio: $freeze.base, hemera: $freeze.hemera, source_freeze_sha256: (sha ($run | path join candidate-freeze.json)), candidate_owned_match: true, authoritative_lock_unchanged: true, note: 'Origins are observed separately by raw command. Any later origin drift needs root assessment; no final release claim.'} | to json | save ($run | path join final-source-verification.json)
}

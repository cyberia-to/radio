use common.nu *
def main [] {
 let run = $env.FILE_PWD
 cd /Users/master/cyber/radio-kadek-empty-status
 required $run candidate-git-diff-check [git diff --check] | ignore
 required $run candidate-git-status [git status --porcelain=v1 --untracked-files=all] | ignore
 required $run candidate-git-diff [git diff --binary -- iroh-blobs/src/hash.rs iroh-blobs/src/store/fs/meta.rs] | ignore
 required $run candidate-git-head [git rev-parse HEAD] | ignore
 required $run current-nextest-config [git show HEAD:.config/nextest.toml] | ignore
 required $run candidate-freeze-identity [shasum -a 256 ($run | path join candidate-freeze.json)] | ignore
}

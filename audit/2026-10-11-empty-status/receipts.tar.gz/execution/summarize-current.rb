require 'json'
require 'digest'
require 'shellwords'
ROOT=File.expand_path(File.dirname(__FILE__))
records=Dir[ROOT+'/logs/*.json'].reject{|p|p.end_with?('.usage.json')}.sort.filter_map do |path|
 r=JSON.parse(File.read(path));next unless r['argv']&.first&.end_with?('/cargo')
 out=File.binread(path.sub(/\.json$/,'.stdout'));err=File.binread(path.sub(/\.json$/,'.stderr'))
 raise 'raw stdout mismatch' unless Digest::SHA256.hexdigest(out)==r['stdout_sha256']
 raise 'raw stderr mismatch' unless Digest::SHA256.hexdigest(err)==r['stderr_sha256']
 r.merge('name'=>File.basename(path,'.json'),'receipt_sha256'=>Digest::SHA256.file(path).hexdigest,'test_results'=>(out.lines.grep(/^test result:/)+err.lines.grep(/Summary.*tests run|Checked.*checks:|Summary no semver update required/)).map(&:strip),'first_error'=>err.lines.find{|l|l.start_with?('error')}&.strip)
end
File.write(ROOT+'/gate-index.json',JSON.pretty_generate(records)+"\n")
nextest={}
records.select{|r|r['argv'][1..2]==['nextest','run']&&!r['argv'].include?('--no-run')}.each do |r|
 text=File.read(ROOT+'/logs/'+r['name']+'.stderr')
 outcomes=text.lines.each_with_object({}) do |line,result|
  if m=line.match(/^\s*(PASS|FAIL|TIMEOUT|SKIP)\s+\[([^\]]+)\]\s+(\S+)\s+(\S+)/)
   result[m[3]+' '+m[4]]={'status'=>m[1],'duration'=>m[2].strip}
  end
 end
 # Preserve exact test-output bodies; no pid/path/content rewriting here.
 detail={}
 sections=text.split(/^--- (STDOUT|STDERR):\s+(\S+) ([^\n]+) ---\s*$/)
 sections.drop(1).each_slice(4) do |kind,pkg,name,body|
  key=pkg+' '+name
  detail[key]||={}
  detail[key][kind]=body.to_s.lines.take_while{|l|!l.match?(/^\s*(PASS|FAIL|TIMEOUT|SLOW|TERMINATING|Summary)\s/)}.join
 end
 nextest[r['name']]={outcomes:outcomes,counts:outcomes.values.group_by{|v|v['status']}.transform_values(&:length),details:detail}
end
File.write(ROOT+'/nextest-outcomes.json',JSON.pretty_generate(nextest)+"\n")
paired=nextest.keys.grep(/^candidate-/).filter_map do |name|
counterpart=name.sub('candidate-','parent-')
map=ROOT+'/counterpart-'+name.sub('candidate-','')+'.json'
mapping=File.exist?(map) ? JSON.parse(File.read(map)) : nil
counterpart='parent-'+mapping['parent'] if mapping
p=nextest[counterpart];next unless p
 c=nextest[name]
 transitions=(p[:outcomes].keys|c[:outcomes].keys).sort.map{|test|{name:test,parent:p[:outcomes][test],candidate:c[:outcomes][test]}}
 {gate:name.sub('candidate-',''),parent_gate:counterpart,comparison_scope:mapping ? 'exact failed cases only; other parent cases not run' : 'full native baseline',parent_counts:p[:counts],candidate_counts:c[:counts],transitions:transitions}
end
File.write(ROOT+'/nextest-comparison.json',JSON.pretty_generate(paired)+"\n")
summary=['# Current-origin executed gates','',
'Radio base bc8b6331d3c76cbc011210e13f81e6ea351ef06f; Hemera d5f0a09539360934fb32db9b2e15a91995607db6.',
"Candidate five-path manifest SHA256 #{Digest::SHA256.file(ROOT+'/candidate-freeze.json').hexdigest}.",
'Ordinary actual Rustup1.95.0, MSRV1.89.0, named docs nightly-2025-10-09. Two jobs, isolated scopes, exact committed Cargo.lock except separately disclosed semver helper resolution.',
'Local --locked/--offline strengthens named workflow commands. Nextest --test-threads1 is a local resource limit; default/ci use committed10s×3 termination with10s grace, verified against pinned0.9.80 source. Cross-target/hosted fleet, minimal-version mutation and release gates are excluded.','',
'## Commands','']
records.each do |r|
 next if r['argv'][1]=='clean'
 summary << "- `#{r['name']}`: exit#{r['exit']}; `cargo #{r['argv'].drop(1).shelljoin}`."
 r['test_results'].each{|s|summary<<"  #{s}"}
 summary << "  First error: #{r['first_error']}" if r['first_error']
end
summary+=['','## Limits','',
'Historical344/23f3 results are not current rows. Failure-first current debug/release witnesses retain15 pass/2 Fs NotFound failures; independent current enumeration is[] before/after empty add. The guard changes canonical EMPTY availability only, not identity, enumeration or record migration.',
'Current local iroh-docs, radio-cli and radio-integration-tests consume this status. Docs intended Complete content status skips synthetic empty downloads; tombstone identity and validation stay unchanged. Local iroh-willow still resolves its iroh-blobs dependency to the registry package. Literal CI iroh/iroh-relay package checks target registry packages and do not certify local cyber-radio.',
'Archive VERGEN warnings are preserved; exit0 does not mean output is warning-free. Compiler-masked Clippy does not certify the new test lint set. All required red gates retain separate current-parent counterparts and raw causes; matching counts alone establish no parity. Mem pre-add status consistency, bounded proof resources and sealed root/particle/length association remain separate work.',
'Semver parent/tag checks use pinned current Hemera; helper locks are retained. They concern source API, not a historical release closure. No release, conformance or whole-platform pass is implied.','']
File.write(ROOT+'/code-gates.md',summary.join("\n"))
puts JSON.pretty_generate({cargo_records:records.length,nextest_runs:nextest.transform_values{|r|r[:counts]},pairs:paired.length})

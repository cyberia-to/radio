
#[cfg(feature = "fs-store")]
#[tokio::test]
async fn fs_enumeration_probe() {
    use crate::store::fs::FsStore;
    bounded(async {
        let dir = tempfile::tempdir().unwrap();
        let store = FsStore::load(dir.path().join("blobs.db")).await.unwrap();
        let fresh = store.list().hashes().await.unwrap();
        let tag = store.add_bytes(Bytes::new()).temp_tag().await.unwrap();
        let added = store.list().hashes().await.unwrap();
        eprintln!("enumeration fresh={fresh:?}; after-empty-add={added:?}; computed-key={:?}", tag.hash());
        drop(tag);
        store.shutdown().await.unwrap();
    }).await;
}

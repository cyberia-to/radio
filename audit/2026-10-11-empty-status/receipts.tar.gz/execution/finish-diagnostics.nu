def main [] {
 let run = $env.FILE_PWD
 ^nu ($run | path join parent-clippy-retry.nu)
 if $env.LAST_EXIT_CODE != 0 { error make {msg: 'follow-up orchestration failed'} }
 ^nu ($run | path join clean-scope.nu) parent after-clippy-followup
 if $env.LAST_EXIT_CODE != 0 { error make {msg: 'follow-up cleanup failed'} }
}

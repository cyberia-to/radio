# Current parent comparison

Radio bc8b6331d3c76cbc011210e13f81e6ea351ef06f + Hemera d5f0a09539360934fb32db9b2e15a91995607db6; final five-path overlay 751d7471250a7899ed4a7a6af35df9200c404448dc08633208d74fc96852213d.
Full raw stdout/stderr, command, environment, timestamp and source identities remain separate receipts. Derived error blocks normalize only exact closure/target paths and remove build-progress lines. Formatter hunk start line numbers also normalize. Count agreement alone establishes no diagnostic parity.

## Tool/compiler counterparts

- format: candidate1, format1; full normalized error blocks equal=true.
  Formatter hunks parent339, candidate339; normalized equality=true.
  Explicit environment differences: CARGO_INCREMENTAL parent="0", candidate=nil.
- named-clippy-all: candidate101, named-clippy-all101; full normalized error blocks equal=true.
- named-clippy-default: candidate101, named-clippy-default101; full normalized error blocks equal=true.
- named-clippy-none: candidate101, named-clippy-none101; full normalized error blocks equal=true.
- named-deny: candidate13, named-deny13; full normalized error blocks equal=false.
  parent_only_error_blocks: error[gather-failure]:
  candidate_only_error_blocks: error[gather-failure]:
  Both have the same36 error headings. The sole unequal full block is Hemera license gather-failure: synthesized path column126 versus129 and corresponding underline spacing follow the three-character parent/candidate path-length difference; license hash0xc0a7a29b and score0.05 match. Full blocks remain retained without column normalization. Advisories/licenses/sources fail; bans pass.
- named-doctest-all-iroh: candidate101, named-doctest-all-iroh101; full normalized error blocks equal=true.
- named-doctest-all-iroh-relay: candidate101, named-doctest-all-iroh-relay101; full normalized error blocks equal=true.
- named-doctest-default-iroh: candidate101, named-doctest-default-iroh101; full normalized error blocks equal=true.
- named-doctest-default-iroh-relay: candidate101, named-doctest-default-iroh-relay101; full normalized error blocks equal=true.
- named-doctest-none-iroh: candidate101, named-doctest-none-iroh101; full normalized error blocks equal=true.
- named-doctest-none-iroh-relay: candidate101, named-doctest-none-iroh-relay101; full normalized error blocks equal=true.
- named-feature-all-iroh: candidate101, named-feature-all-iroh101; full normalized error blocks equal=true.
- named-feature-all-iroh-relay: candidate101, named-feature-all-iroh-relay101; full normalized error blocks equal=true.
- named-feature-none-iroh: candidate101, named-feature-none-iroh101; full normalized error blocks equal=true.
- named-feature-none-iroh-relay: candidate101, named-feature-none-iroh-relay101; full normalized error blocks equal=true.
- named-format: candidate105, named-format105; full normalized error blocks equal=true.
  Formatter hunks parent467, candidate467; normalized equality=true.
- named-nextest-all: candidate101, named-nextest-all101; full normalized error blocks equal=true.
- named-nightly-docs: candidate101, named-nightly-docs101; full normalized error blocks equal=true.
- native-clippy: candidate101, native-clippy-after-sigkill101; full normalized error blocks equal=true.
  Explicit environment differences: CARGO_INCREMENTAL parent="0", candidate=nil.
- native-doc: candidate101, native-doc101; full normalized error blocks equal=true.
  Explicit environment differences: CARGO_INCREMENTAL parent="0", candidate=nil.
- native-nextest: candidate0, native-nextest100; full normalized error blocks equal=false.
  parent_only_error_blocks: error: test run failed

## Runtime comparisons

- ci-run-none: exact failed cases only; other parent cases not run; parent {"FAIL" => 1}; candidate {"PASS" => 546, "TIMEOUT" => 1}.
  iroh-willow::spaces prop_sync_simulation_matches_model: parent FAIL 6.987s; candidate TIMEOUT 30.009s.
  Unselected parent cases were not rerun; this is not a full parent workspace runtime result.
  Parent reports `net failed: failed while active`, whereas candidate reaches the timeout. A generated proptest regression seed is preserved separately under runtime-outputs; no identical failure cause is claimed.
- native-nextest: full native baseline; parent {"PASS" => 122, "TIMEOUT" => 2}; candidate {"PASS" => 141}.
  Per-name transitions: 122 PASS→PASS, 17 absent→PASS, 2 TIMEOUT→PASS.
  iroh-blobs util::connection_pool::tests::connection_pool_idle: parent TIMEOUT 30.009s; candidate PASS 7.366s.
  iroh-blobs util::connection_pool::tests::connection_pool_smoke: parent TIMEOUT 30.010s; candidate PASS 15.494s.

## Limits

Parent native connection_pool_idle/smoke timeouts are not attributed to the empty-status guard; their causes remain unestablished. Candidate native141 passes do not erase CI no-default Willow timeout or lint/docs/policy failures. Test-body streams and per-name outcomes are retained in nextest-outcomes.json and original logs.
First parent owning Clippy exited101 after derive_builder rustc received SIGKILL. It remains an interrupted/inconclusive original comparison. Its one exact-command follow-up native-clippy-after-sigkill completed with the same full normalized lint/error blocks as the candidate; no full matrix was rerun.
Current named nightly docs fail generating rustdoc search.index/type data (invalid null) in both candidate and exact parent commands; the same cyber-radio/base failures remain. Strict private owning docs separately fail on unchanged Self::persist. Neither result imports old344 causes.
Initial candidate format/native-clippy/native-doc commands preceded the local CARGO_INCREMENTAL=0 resource policy. Parent and all subsequent commands record that limit explicitly; this affects compiler caching, not source. Native/consumer/CI runtime uses local serialized test threads; committed default/ci termination begins30s then10s graceful shutdown. No added timeout profile is used.
Historical old source and CODE approval are retained only under superseded344 evidence. Current source identity and parent comparisons never use its gate rows. No blanket regression-free, release, whole-platform or conformance claim follows.

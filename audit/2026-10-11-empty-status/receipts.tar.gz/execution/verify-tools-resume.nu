use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let prior = (open /tmp/radio-empty-root.GDc4u3/tools.json)
 required $run tool-version-make-corrected [/tmp/radio-gate-tools/bin/cargo-make make --version] | ignore
 required $run tool-version-deny [/tmp/radio-gate-tools/bin/cargo-deny --version] | ignore
 let revision = (required $run tools-db-head [git -C $prior.advisory_db.path rev-parse HEAD] | str trim)
 let dirty = (required $run tools-db-status [git -C $prior.advisory_db.path status --porcelain=v1 --untracked-files=all])
 if $dirty != '' { error make {msg: 'dirty advisory DB'} }
 $prior | update advisory_db.revision $revision | update note 'Fresh current command receipts verify exact tool payloads and current advisory DB. Historical acquisition receipts identify only acquisition.' | to json | save ($run | path join tools.json)
 required $run nextest-source-tag [git ls-remote --tags https://github.com/nextest-rs/nextest.git '*0.9.80*'] | ignore
 required $run nextest-source-download [curl --fail --location --output ($run | path join nextest-source.tar.gz) https://codeload.github.com/nextest-rs/nextest/tar.gz/19c03ce27d861e12b73df4590881d1e97e5ea07f] | ignore
 mkdir ($run | path join nextest-source)
 required $run nextest-source-extract [tar -xf ($run | path join nextest-source.tar.gz) --strip-components=1 -C ($run | path join nextest-source)] | ignore
}

def main [scope: string, suffix: string] {
 let run = $env.FILE_PWD
 for nightly in [false true] {
  let args = [($run | path join gate.nu) --scope $scope --name $'clean-($suffix)-(if $nightly { "nightly" } else { "ordinary" })' --clean-completed --execute]
  let args = if $nightly { $args | append [--ci-docs] } else { $args }
  ^nu ...$args
  if $env.LAST_EXIT_CODE != 0 { exit $env.LAST_EXIT_CODE }
 }
}

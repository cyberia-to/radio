def invoke [args: list<string>] {
 let result = (^nu ...$args | complete)
 print $result.stdout
 if $result.stderr != '' { print --stderr $result.stderr }
 if $result.exit_code != 0 { error make {msg: 'phase orchestration failed; inspect before resuming'} }
}
def main [] {
 let run = $env.FILE_PWD
 invoke [($run | path join clean-scope.nu) candidate after-ordinary]
 invoke [($run | path join matrix.nu) candidate msrv]
 invoke [($run | path join clean-scope.nu) candidate after-msrv]
 let docs = (^nu ($run | path join nightly.nu) candidate | complete)
 print $docs.stdout
 if not (($run | path join logs candidate-named-nightly-docs.json) | path exists) { error make {msg: 'missing candidate nightly receipt'} }
 invoke [($run | path join clean-scope.nu) candidate after-nightly]
 for chain in ['1.95.0' '1.89.0' 'nightly-2025-10-09'] {
  invoke [($run | path join current-counterparts.nu) $chain]
  invoke [($run | path join clean-scope.nu) parent $'after-($chain | str replace --all "." "-")']
 }
 invoke [($run | path join candidate-semver.nu)]
 invoke [($run | path join retain-semver.nu)]
}

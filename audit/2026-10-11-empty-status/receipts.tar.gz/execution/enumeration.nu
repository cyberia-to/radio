use common.nu *
let run = $env.FILE_PWD
let probe = (open --raw ($run | path join fs-enumeration-probe.rs))
for scope in [witness] {
 let source = ($run | path join $scope radio iroh-blobs src hash empty_root stores.rs)
 let before = (open --raw $source)
 $before | save ($run | path join $'enumeration-($scope)-stores-before.rs')
 ($before + $probe) | save --force $source
 {scope: $scope, prior_sha256: ($before | hash sha256), probe_sha256: ($probe | hash sha256), compiled_sha256: (sha $source), production_basis: 'current bc8b6331 production plus test-only module; canonical EMPTY already upstream'} | to json | save ($run | path join $'enumeration-($scope)-source.json')
 let result = (^nu ($run | path join gate.nu) --scope $scope --name enumeration-probe --execute --args '["test","--manifest-path","iroh-blobs/Cargo.toml","--lib","fs_enumeration_probe","--all-features","--locked","--offline","--","--nocapture"]' | complete)
 print $result.stdout
 if $result.stderr != '' { print --stderr $result.stderr }
 if not ($run | path join logs $'($scope)-enumeration-probe.json' | path exists) { error make {msg: 'probe missing receipt'} }
 # Only the owned temporary test overlay is removed; production was never edited.
 $before | save --force $source
 if $result.exit_code != 0 { error make {msg: 'enumeration probe failed'} }
}

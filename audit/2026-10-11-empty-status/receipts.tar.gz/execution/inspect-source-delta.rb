require 'digest';require 'json'
r=File.dirname(__FILE__)
files=lambda{|root|Dir[root+'/**/*',root+'/**/.*'].uniq.select{|p|File.file?(p)}.map{|p|p.delete_prefix(root+'/')}.sort}
pbase=r+'/parent/radio';cbase=r+'/candidate/radio'
paths=files.call(pbase)|files.call(cbase)
diffs=paths.filter_map do |p|
 a=File.file?(pbase+'/'+p) ? Digest::SHA256.file(pbase+'/'+p).hexdigest : nil
 b=File.file?(cbase+'/'+p) ? Digest::SHA256.file(cbase+'/'+p).hexdigest : nil
 {path:p,parent:a,candidate:b} unless a==b
end
allowed=JSON.parse(File.read(r+'/candidate-freeze.json'))['files'].map{|f|f['path']}
generated=JSON.parse(File.read(r+'/generated-runtime-output.json'))
raise 'runtime evidence drift' unless Digest::SHA256.file(generated['retained']).hexdigest==generated['sha256']
runtime=diffs.select{|d| d[:path]==generated['path']&&d[:parent]==generated['sha256']&&d[:candidate].nil?}
raise 'runtime output missing or altered' unless runtime.length==1
source_diffs=diffs-runtime
unknown=source_diffs.reject{|d|allowed.include?(d[:path])}
File.write(r+'/candidate-whole-tree-delta.json',JSON.pretty_generate({differences:source_diffs,generated_runtime_outputs:runtime,unexpected:unknown})+"\n")
raise "unexpected source/artifact delta: #{unknown.map{|d|d[:path]}.inspect}" unless unknown.empty?
puts JSON.pretty_generate({changed_source_paths:source_diffs.length,generated_runtime_paths:runtime.length,only_five_frozen_source_paths:true})

require 'json'
require 'digest'
R=File.expand_path(File.dirname(__FILE__))
rows=JSON.parse(File.read(R+'/paired-diagnostics.json'))['gates']
transitions=JSON.parse(File.read(R+'/nextest-comparison.json'))
lines=['# Current parent comparison','',
'Radio bc8b6331d3c76cbc011210e13f81e6ea351ef06f + Hemera d5f0a09539360934fb32db9b2e15a91995607db6; final five-path overlay '+Digest::SHA256.file(R+'/candidate-freeze.json').hexdigest+'.',
'Full raw stdout/stderr, command, environment, timestamp and source identities remain separate receipts. Derived error blocks normalize only exact closure/target paths and remove build-progress lines. Formatter hunk start line numbers also normalize. Count agreement alone establishes no diagnostic parity.','',
'## Tool/compiler counterparts','']
rows.each do |r|
 next if r['candidate_exit']==0&&r['parent_exit']==0
 lines << "- #{r['name']}: candidate#{r['candidate_exit']}, #{r['parent_name']}#{r['parent_exit']}; full normalized error blocks equal=#{r['error_blocks_equal_after_path_normalization']}."
 if r.key?('format_hunks_equal_after_paths_and_line_normalization')
  lines << "  Formatter hunks parent#{r['parent_format_hunks']}, candidate#{r['candidate_format_hunks']}; normalized equality=#{r['format_hunks_equal_after_paths_and_line_normalization']}."
 end
 unless r['error_blocks_equal_after_path_normalization']
  %w[parent_only_error_blocks candidate_only_error_blocks].each{|k|r[k].each{|b|lines<<"  #{k}: #{b.lines.first.strip}"}}
 end
 if r['name']=='named-deny'
  lines << '  Both have the same36 error headings. The sole unequal full block is Hemera license gather-failure: synthesized path column126 versus129 and corresponding underline spacing follow the three-character parent/candidate path-length difference; license hash0xc0a7a29b and score0.05 match. Full blocks remain retained without column normalization. Advisories/licenses/sources fail; bans pass.'
 end
 unless r['environment_differences'].empty?
  lines << '  Explicit environment differences: '+r['environment_differences'].map{|v|"#{v['name']} parent=#{v['parent'].inspect}, candidate=#{v['candidate'].inspect}"}.join('; ')+'.'
 end
end
lines+=['','## Runtime comparisons','']
transitions.each do |r|
 lines << "- #{r['gate']}: #{r['comparison_scope']}; parent #{r['parent_counts']}; candidate #{r['candidate_counts']}."
 if r['comparison_scope'].include?('failed cases')
  selected=r['transitions'].select{|t|t['parent']}
  selected.each{|t|lines<<"  #{t['name']}: parent #{t.dig('parent','status')} #{t.dig('parent','duration')}; candidate #{t.dig('candidate','status')} #{t.dig('candidate','duration')}."}
  lines << '  Unselected parent cases were not rerun; this is not a full parent workspace runtime result.'
  lines << '  Parent reports `net failed: failed while active`, whereas candidate reaches the timeout. A generated proptest regression seed is preserved separately under runtime-outputs; no identical failure cause is claimed.'
 else
  counts=r['transitions'].group_by{|t|[t.dig('parent','status')||'absent',t.dig('candidate','status')||'absent']}.transform_values(&:length)
  lines << '  Per-name transitions: '+counts.map{|(a,b),n|"#{n} #{a}→#{b}"}.join(', ')+'.'
  r['transitions'].select{|t|t['parent']&&t.dig('parent','status')!=t.dig('candidate','status')}.each{|t|lines<<"  #{t['name']}: parent #{t.dig('parent','status')} #{t.dig('parent','duration')}; candidate #{t.dig('candidate','status')} #{t.dig('candidate','duration')}."}
 end
end
lines+=['','## Limits','',
'Parent native connection_pool_idle/smoke timeouts are not attributed to the empty-status guard; their causes remain unestablished. Candidate native141 passes do not erase CI no-default Willow timeout or lint/docs/policy failures. Test-body streams and per-name outcomes are retained in nextest-outcomes.json and original logs.',
'First parent owning Clippy exited101 after derive_builder rustc received SIGKILL. It remains an interrupted/inconclusive original comparison. Its one exact-command follow-up native-clippy-after-sigkill completed with the same full normalized lint/error blocks as the candidate; no full matrix was rerun.',
'Current named nightly docs fail generating rustdoc search.index/type data (invalid null) in both candidate and exact parent commands; the same cyber-radio/base failures remain. Strict private owning docs separately fail on unchanged Self::persist. Neither result imports old344 causes.',
'Initial candidate format/native-clippy/native-doc commands preceded the local CARGO_INCREMENTAL=0 resource policy. Parent and all subsequent commands record that limit explicitly; this affects compiler caching, not source. Native/consumer/CI runtime uses local serialized test threads; committed default/ci termination begins30s then10s graceful shutdown. No added timeout profile is used.',
'Historical old source and CODE approval are retained only under superseded344 evidence. Current source identity and parent comparisons never use its gate rows. No blanket regression-free, release, whole-platform or conformance claim follows.','']
File.write(R+'/paired-comparison.md',lines.join("\n"))
puts "comparison bytes #{File.size(R+'/paired-comparison.md')}"

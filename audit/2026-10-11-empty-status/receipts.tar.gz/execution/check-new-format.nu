use common.nu *
def main [] {
 let run = $env.FILE_PWD
 cd /Users/master/cyber/radio-kadek-empty-status
 required $run candidate-new-test-format [/Users/master/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin/rustfmt --check --edition 2024 iroh-blobs/src/hash/empty_root.rs iroh-blobs/src/hash/empty_root/stores.rs iroh-blobs/src/hash/empty_root/remote.rs] | ignore
}

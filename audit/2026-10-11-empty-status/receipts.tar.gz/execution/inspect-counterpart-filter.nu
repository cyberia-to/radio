let cases = (open --raw logs/candidate-ci-run-none.stderr | lines | parse --regex '^\s*(?<status>FAIL|TIMEOUT)\s+\[[^\]]+\]\s+(?<binary>\S+)\s+(?<test>\S+)' | uniq)
$cases | each {|c| ['(binary_id(=' $c.binary ') and test(=' $c.test '))'] | str join } | str join ' or '

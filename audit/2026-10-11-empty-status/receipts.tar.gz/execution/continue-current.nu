use common.nu *
def invoke [run: path, args: list<string>] {
 let result = (run-external nu ...$args | complete)
 print $result.stdout
 if $result.stderr != '' { print --stderr $result.stderr }
 if $result.exit_code != 0 { error make {msg: 'phase runner failed; gate receipts retained'} }
}
def main [] {
 let run = $env.FILE_PWD
 invoke $run [($run | path join matrix.nu) candidate broad]
 invoke $run [($run | path join matrix.nu) candidate features]
}

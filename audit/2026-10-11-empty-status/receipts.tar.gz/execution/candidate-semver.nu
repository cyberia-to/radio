use common.nu *
def main [] {
 let run = $env.FILE_PWD
 let bin = '/Users/master/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin'
 let environment = {PATH: ([$bin] | append $env.PATH), RUSTC: ($bin | path join rustc), RUSTDOC: ($bin | path join rustdoc), RUSTUP_TOOLCHAIN: '1.95.0', RUSTFLAGS: '-Dwarnings', RUSTDOCFLAGS: '-Dwarnings', CARGO_BUILD_JOBS: '2', CARGO_INCREMENTAL: '0', CARGO_TARGET_DIR: ($run | path join targets semver), CARGO_NET_OFFLINE: 'true', RUSTUP_AUTO_INSTALL: '0'}
 cd ($run | path join semver current radio)
 for baseline in [parent tag] {
  for crate in [iroh-blobs] {
   let name = $'candidate-semver-($baseline)-($crate)'
   let before = ((usage $run) + (usage /tmp/radio-gate-tools))
   if $before >= 20000000000 { error make {msg: '20GB staging threshold'} }
   let prior = ([current parent tag] | each {|scope| {scope: $scope, sha256: (sha ($run | path join semver $scope radio Cargo.lock))}})
   let result = (record $run $name [($bin | path join cargo) semver-checks check-release --manifest-path ($crate | path join Cargo.toml) --baseline-root ($run | path join semver $baseline radio $crate) --verbose] $environment)
   let generated = ($run | path join targets semver semver-checks)
   let retained = ($run | path join semver-generated $baseline)
   let generated_files = (checked [rg --files --hidden -g Cargo.toml -g Cargo.lock -g lib.rs $generated] | lines)
   let copies = ($generated_files | each {|source|
    let relative = ($source | path relative-to $generated)
    let target = ($retained | path join $relative)
    mkdir ($target | path dirname)
    cp $source $target
    {source: $source, retained: $target, sha256: (sha $source)}
   })
   {baseline: $baseline, files: $copies, note: "Actual helper manifests/locks/source after this command, captured before the next baseline can overwrite them."} | to json | save ($run | path join $'semver-generated-($baseline).json')
   let after = ((usage $run) + (usage /tmp/radio-gate-tools))
   {before_bytes: $before, after_bytes: $after, target: $environment.CARGO_TARGET_DIR, limit_bytes: 30000000000, prior_locks: $prior, after_locks: ([current parent tag] | each {|scope| {scope: $scope, sha256: (sha ($run | path join semver $scope radio Cargo.lock))}}), note: 'Semver fresh resolution is a source API diagnostic, not an exact-locked or content-identity compatibility gate.'} | to json | save ($run | path join logs $'($name).usage.json')
   if $after > 30000000000 { error make {msg: '30GB live bound'} }
  }
 }
}

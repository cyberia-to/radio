# Current-origin executed gates

Radio base bc8b6331d3c76cbc011210e13f81e6ea351ef06f; Hemera d5f0a09539360934fb32db9b2e15a91995607db6.
Candidate five-path manifest SHA256 751d7471250a7899ed4a7a6af35df9200c404448dc08633208d74fc96852213d.
Ordinary actual Rustup1.95.0, MSRV1.89.0, named docs nightly-2025-10-09. Two jobs, isolated scopes, exact committed Cargo.lock except separately disclosed semver helper resolution.
Local --locked/--offline strengthens named workflow commands. Nextest --test-threads1 is a local resource limit; default/ci use committed10s×3 termination with10s grace, verified against pinned0.9.80 source. Cross-target/hosted fleet, minimal-version mutation and release gates are excluded.

## Commands

- `candidate-bao-all`: exit0; `cargo test -p cyber-bao --all-features --locked --offline`.
  test result: ok. 71 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s
  test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.10s
  test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
- `candidate-ci-list-default`: exit0; `cargo nextest list --workspace --lib --bins --tests --run-ignored ignored-only --locked --offline`.
- `candidate-ci-list-none`: exit0; `cargo nextest list --workspace --lib --bins --tests --run-ignored ignored-only --locked --offline --no-default-features`.
- `candidate-ci-run-default`: exit0; `cargo nextest run --workspace --lib --bins --tests --profile ci --run-ignored default --no-fail-fast --message-format human --test-threads 1 --locked --offline`.
  Summary [ 314.056s] 547 tests run: 547 passed (2 slow), 9 skipped
- `candidate-ci-run-none`: exit100; `cargo nextest run --workspace --lib --bins --tests --profile ci --run-ignored default --no-fail-fast --message-format human --test-threads 1 --locked --offline --no-default-features`.
  Summary [ 300.539s] 547 tests run: 546 passed (1 slow), 1 timed out, 9 skipped
  First error: error: test run failed
- `candidate-consumers-nextest`: exit0; `cargo nextest run -p iroh-docs -p radio-cli -p radio-integration-tests --all-features --lib --bins --tests --locked --offline --profile default --test-threads 1 --no-fail-fast`.
  Summary [  27.750s] 108 tests run: 108 passed, 3 skipped
- `candidate-empty-default`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --locked --offline`.
  test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 126 filtered out; finished in 0.36s
- `candidate-empty-existing`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib test_empty_hash --all-features --locked --offline`.
  test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 142 filtered out; finished in 0.00s
- `candidate-empty-none`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --no-default-features --locked --offline`.
  test result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 66 filtered out; finished in 0.01s
- `candidate-empty-release`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --release --all-features --locked --offline`.
  test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 126 filtered out; finished in 0.20s
- `candidate-empty-root-all`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --all-features --locked --offline`.
  test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 126 filtered out; finished in 0.33s
- `candidate-format`: exit1; `cargo fmt --all -- --check`.
- `candidate-msrv-consumers`: exit0; `cargo test -p iroh-docs -p radio-cli -p radio-integration-tests --no-run --locked --offline`.
- `candidate-msrv-empty`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --all-features --locked --offline`.
  test result: ok. 17 passed; 0 failed; 0 ignored; 0 measured; 126 filtered out; finished in 0.33s
- `candidate-msrv-export`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --all-features --locked --offline`.
  test result: ok. 14 passed; 0 failed; 0 ignored; 0 measured; 129 filtered out; finished in 0.35s
- `candidate-msrv-native-check`: exit0; `cargo check --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline`.
- `candidate-msrv-parent-pairs`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline`.
  test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 132 filtered out; finished in 0.32s
- `candidate-msrv-root-policy`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --all-features --locked --offline`.
  test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 138 filtered out; finished in 0.35s
- `candidate-msrv-workspace`: exit0; `cargo check --workspace --all-targets --locked --offline`.
- `candidate-named-clippy-all`: exit101; `cargo clippy --workspace --all-features --all-targets --lib --bins --tests --benches --examples --locked --offline -- -D warnings`.
  First error: error: consider using `sort_by_key`
- `candidate-named-clippy-default`: exit101; `cargo clippy --workspace --all-targets --lib --bins --tests --benches --examples --locked --offline -- -D warnings`.
  First error: error: using `clone` on type `Hash` which implements the `Copy` trait
- `candidate-named-clippy-none`: exit101; `cargo clippy --workspace --no-default-features --all-targets --lib --bins --tests --benches --examples --locked --offline -- -D warnings`.
  First error: error: consider using `sort_by_key`
- `candidate-named-deny`: exit13; `cargo deny --workspace --all-features --locked check --disable-fetch -Dwarnings`.
  First error: error[source-not-allowed]: detected 'git' source not explicitly allowed
- `candidate-named-doctest-all-iroh-bench`: exit0; `cargo test -p iroh-bench --doc --locked --offline --all-features`.
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
- `candidate-named-doctest-all-iroh-dns-server`: exit0; `cargo test -p iroh-dns-server --doc --locked --offline --all-features`.
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
- `candidate-named-doctest-all-iroh-relay`: exit101; `cargo test -p iroh-relay --doc --locked --offline --all-features`.
  First error: error: cannot specify features for packages outside of workspace
- `candidate-named-doctest-all-iroh`: exit101; `cargo test -p iroh --doc --locked --offline --all-features`.
  First error: error: cannot specify features for packages outside of workspace
- `candidate-named-doctest-default-iroh-bench`: exit0; `cargo test -p iroh-bench --doc --locked --offline`.
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
- `candidate-named-doctest-default-iroh-dns-server`: exit0; `cargo test -p iroh-dns-server --doc --locked --offline`.
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
- `candidate-named-doctest-default-iroh-relay`: exit101; `cargo test -p iroh-relay --doc --locked --offline`.
  First error: error: package `iroh-relay` cannot be tested because it requires dev-dependencies and is not a member of the workspace
- `candidate-named-doctest-default-iroh`: exit101; `cargo test -p iroh --doc --locked --offline`.
  First error: error: package `iroh` cannot be tested because it requires dev-dependencies and is not a member of the workspace
- `candidate-named-doctest-none-iroh-bench`: exit0; `cargo test -p iroh-bench --doc --locked --offline --no-default-features`.
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
- `candidate-named-doctest-none-iroh-dns-server`: exit0; `cargo test -p iroh-dns-server --doc --locked --offline --no-default-features`.
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
- `candidate-named-doctest-none-iroh-relay`: exit101; `cargo test -p iroh-relay --doc --locked --offline --no-default-features`.
  First error: error: cannot specify features for packages outside of workspace
- `candidate-named-doctest-none-iroh`: exit101; `cargo test -p iroh --doc --locked --offline --no-default-features`.
  First error: error: cannot specify features for packages outside of workspace
- `candidate-named-doctests-all`: exit0; `cargo test --workspace --all-features --doc --locked --offline`.
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
  test result: ok. 27 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s
  test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
  test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
  test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 5.03s
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
  test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.37s
  test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.08s
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
  test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s
- `candidate-named-feature-all-iroh-bench`: exit0; `cargo check -p iroh-bench --lib --bins --locked --offline --all-features`.
- `candidate-named-feature-all-iroh-dns-server`: exit0; `cargo check -p iroh-dns-server --lib --bins --locked --offline --all-features`.
- `candidate-named-feature-all-iroh-relay`: exit101; `cargo check -p iroh-relay --lib --bins --locked --offline --all-features`.
  First error: error: cannot specify features for packages outside of workspace
- `candidate-named-feature-all-iroh`: exit101; `cargo check -p iroh --lib --bins --locked --offline --all-features`.
  First error: error: cannot specify features for packages outside of workspace
- `candidate-named-feature-default-iroh-bench`: exit0; `cargo check -p iroh-bench --lib --bins --locked --offline`.
- `candidate-named-feature-default-iroh-dns-server`: exit0; `cargo check -p iroh-dns-server --lib --bins --locked --offline`.
- `candidate-named-feature-default-iroh-relay`: exit0; `cargo check -p iroh-relay --lib --bins --locked --offline`.
- `candidate-named-feature-default-iroh`: exit0; `cargo check -p iroh --lib --bins --locked --offline`.
- `candidate-named-feature-none-iroh-bench`: exit0; `cargo check -p iroh-bench --lib --bins --locked --offline --no-default-features`.
- `candidate-named-feature-none-iroh-dns-server`: exit0; `cargo check -p iroh-dns-server --lib --bins --locked --offline --no-default-features`.
- `candidate-named-feature-none-iroh-relay`: exit101; `cargo check -p iroh-relay --lib --bins --locked --offline --no-default-features`.
  First error: error: cannot specify features for packages outside of workspace
- `candidate-named-feature-none-iroh`: exit101; `cargo check -p iroh --lib --bins --locked --offline --no-default-features`.
  First error: error: cannot specify features for packages outside of workspace
- `candidate-named-format`: exit105; `cargo make --disable-check-for-updates format-check`.
- `candidate-named-nextest-all`: exit101; `cargo nextest run --workspace --all-features --lib --bins --tests --no-run --locked --offline`.
  First error: error[E0599]: no method named `add` found for enum `Result<T, E>` in the current scope
- `candidate-named-nextest-default`: exit0; `cargo nextest run --workspace --lib --bins --tests --no-run --locked --offline`.
- `candidate-named-nextest-none`: exit0; `cargo nextest run --workspace --no-default-features --lib --bins --tests --no-run --locked --offline`.
- `candidate-named-nightly-docs`: exit101; `cargo doc --workspace --all-features --no-deps --document-private-items --locked --offline`.
  First error: error: couldn't generate documentation: failed to read column from disk: data consumer error: invalid type: null, expected type data at line 1 column 4
- `candidate-native-clippy`: exit101; `cargo clippy --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline -- -D warnings`.
  First error: error: using `clone` on type `Hash` which implements the `Copy` trait
- `candidate-native-doc`: exit101; `cargo doc --manifest-path iroh-blobs/Cargo.toml --all-features --no-deps --document-private-items --locked --offline`.
  First error: error: unresolved link to `Self::persist`
- `candidate-native-export`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib export_pairs --all-features --locked --offline`.
  test result: ok. 14 passed; 0 failed; 0 ignored; 0 measured; 129 filtered out; finished in 0.32s
- `candidate-native-nextest`: exit0; `cargo nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --locked --offline --test-threads 1 --profile default --no-fail-fast`.
  Summary [ 158.864s] 141 tests run: 141 passed (2 slow), 2 skipped
- `candidate-native-parent-pairs`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib parent_pairs --all-features --locked --offline`.
  test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 132 filtered out; finished in 0.30s
- `candidate-native-root-policy`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib root_policy --all-features --locked --offline`.
  test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 138 filtered out; finished in 0.35s
- `candidate-semver-parent-iroh-blobs-after-sigkill`: exit0; `cargo semver-checks check-release --manifest-path iroh-blobs/Cargo.toml --baseline-root /private/tmp/radio-empty-status.20261011-60036-oi3wr7/semver/parent/radio/iroh-blobs --verbose`.
  Checked [   0.027s] 202 checks: 202 pass, 58 skip
  Summary no semver update required
- `candidate-semver-parent-iroh-blobs`: exit101; `cargo semver-checks check-release --manifest-path iroh-blobs/Cargo.toml --baseline-root /private/tmp/radio-empty-status.20261011-60036-oi3wr7/semver/parent/radio/iroh-blobs --verbose`.
  First error: error: could not compile `darling` (lib)
- `candidate-semver-tag-iroh-blobs`: exit0; `cargo semver-checks check-release --manifest-path iroh-blobs/Cargo.toml --baseline-root /private/tmp/radio-empty-status.20261011-60036-oi3wr7/semver/tag/radio/iroh-blobs --verbose`.
  Checked [   0.030s] 202 checks: 202 pass, 58 skip
  Summary no semver update required
- `candidate-workspace-no-run`: exit0; `cargo test --workspace --no-run --locked --offline`.
- `parent-ci-run-none-failed-cases`: exit100; `cargo nextest run --workspace --lib --bins --tests --profile ci --run-ignored default --no-fail-fast --message-format human --test-threads 1 --locked --offline --no-default-features -E \(binary_id\(\=iroh-willow::spaces\)\ and\ test\(\=prop_sync_simulation_matches_model\)\)`.
  First error: error: test run failed
- `parent-format`: exit1; `cargo fmt --all -- --check`.
- `parent-metadata-all`: exit0; `cargo metadata --format-version 1 --all-features --locked --offline`.
- `parent-metadata`: exit0; `cargo metadata --format-version 1 --locked --offline`.
- `parent-named-clippy-all`: exit101; `cargo clippy --workspace --all-features --all-targets --lib --bins --tests --benches --examples --locked --offline -- -D warnings`.
  First error: error: consider using `sort_by_key`
- `parent-named-clippy-default`: exit101; `cargo clippy --workspace --all-targets --lib --bins --tests --benches --examples --locked --offline -- -D warnings`.
  First error: error: using `clone` on type `Hash` which implements the `Copy` trait
- `parent-named-clippy-none`: exit101; `cargo clippy --workspace --no-default-features --all-targets --lib --bins --tests --benches --examples --locked --offline -- -D warnings`.
  First error: error: consider using `sort_by_key`
- `parent-named-deny`: exit13; `cargo deny --workspace --all-features --locked check --disable-fetch -Dwarnings`.
  First error: error[source-not-allowed]: detected 'git' source not explicitly allowed
- `parent-named-doctest-all-iroh-relay`: exit101; `cargo test -p iroh-relay --doc --locked --offline --all-features`.
  First error: error: cannot specify features for packages outside of workspace
- `parent-named-doctest-all-iroh`: exit101; `cargo test -p iroh --doc --locked --offline --all-features`.
  First error: error: cannot specify features for packages outside of workspace
- `parent-named-doctest-default-iroh-relay`: exit101; `cargo test -p iroh-relay --doc --locked --offline`.
  First error: error: package `iroh-relay` cannot be tested because it requires dev-dependencies and is not a member of the workspace
- `parent-named-doctest-default-iroh`: exit101; `cargo test -p iroh --doc --locked --offline`.
  First error: error: package `iroh` cannot be tested because it requires dev-dependencies and is not a member of the workspace
- `parent-named-doctest-none-iroh-relay`: exit101; `cargo test -p iroh-relay --doc --locked --offline --no-default-features`.
  First error: error: cannot specify features for packages outside of workspace
- `parent-named-doctest-none-iroh`: exit101; `cargo test -p iroh --doc --locked --offline --no-default-features`.
  First error: error: cannot specify features for packages outside of workspace
- `parent-named-feature-all-iroh-relay`: exit101; `cargo check -p iroh-relay --lib --bins --locked --offline --all-features`.
  First error: error: cannot specify features for packages outside of workspace
- `parent-named-feature-all-iroh`: exit101; `cargo check -p iroh --lib --bins --locked --offline --all-features`.
  First error: error: cannot specify features for packages outside of workspace
- `parent-named-feature-none-iroh-relay`: exit101; `cargo check -p iroh-relay --lib --bins --locked --offline --no-default-features`.
  First error: error: cannot specify features for packages outside of workspace
- `parent-named-feature-none-iroh`: exit101; `cargo check -p iroh --lib --bins --locked --offline --no-default-features`.
  First error: error: cannot specify features for packages outside of workspace
- `parent-named-format`: exit105; `cargo make --disable-check-for-updates format-check`.
- `parent-named-nextest-all`: exit101; `cargo nextest run --workspace --all-features --lib --bins --tests --no-run --locked --offline`.
  First error: error[E0599]: no method named `add` found for enum `Result<T, E>` in the current scope
- `parent-named-nightly-docs`: exit101; `cargo doc --workspace --all-features --no-deps --document-private-items --locked --offline`.
  First error: error: couldn't generate documentation: failed to read column from disk: data consumer error: invalid type: null, expected type data at line 1 column 4
- `parent-native-clippy-after-sigkill`: exit101; `cargo clippy --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline -- -D warnings`.
  First error: error: using `clone` on type `Hash` which implements the `Copy` trait
- `parent-native-clippy`: exit101; `cargo clippy --manifest-path iroh-blobs/Cargo.toml --all-targets --all-features --locked --offline -- -D warnings`.
  First error: error: could not compile `derive_builder` (lib)
- `parent-native-doc`: exit101; `cargo doc --manifest-path iroh-blobs/Cargo.toml --all-features --no-deps --document-private-items --locked --offline`.
  First error: error: unresolved link to `Self::persist`
- `parent-native-nextest`: exit100; `cargo nextest run --manifest-path iroh-blobs/Cargo.toml --lib --all-features --locked --offline --test-threads 1 --profile default --no-fail-fast`.
  Summary [ 211.177s] 124 tests run: 122 passed (4 slow), 2 timed out, 2 skipped
  First error: error: test run failed
- `version-1.89.0-cargo`: exit0; `cargo -Vv`.
- `version-1.95.0-cargo`: exit0; `cargo -Vv`.
- `witness-empty-root-debug`: exit101; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --all-features --locked --offline`.
  test result: FAILED. 15 passed; 2 failed; 0 ignored; 0 measured; 126 filtered out; finished in 0.16s
  First error: error: test failed, to rerun pass `--lib`
- `witness-empty-root-release`: exit101; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib empty_root --release --all-features --locked --offline`.
  test result: FAILED. 15 passed; 2 failed; 0 ignored; 0 measured; 126 filtered out; finished in 0.11s
  First error: error: test failed, to rerun pass `--lib`
- `witness-enumeration-probe`: exit0; `cargo test --manifest-path iroh-blobs/Cargo.toml --lib fs_enumeration_probe --all-features --locked --offline -- --nocapture`.
  test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 143 filtered out; finished in 0.15s

## Limits

Historical344/23f3 results are not current rows. Failure-first current debug/release witnesses retain15 pass/2 Fs NotFound failures; independent current enumeration is[] before/after empty add. The guard changes canonical EMPTY availability only, not identity, enumeration or record migration.
Current local iroh-docs, radio-cli and radio-integration-tests consume this status. Docs intended Complete content status skips synthetic empty downloads; tombstone identity and validation stay unchanged. Local iroh-willow still resolves its iroh-blobs dependency to the registry package. Literal CI iroh/iroh-relay package checks target registry packages and do not certify local cyber-radio.
Archive VERGEN warnings are preserved; exit0 does not mean output is warning-free. Compiler-masked Clippy does not certify the new test lint set. All required red gates retain separate current-parent counterparts and raw causes; matching counts alone establish no parity. Mem pre-add status consistency, bounded proof resources and sealed root/particle/length association remain separate work.
Semver parent/tag checks use pinned current Hemera; helper locks are retained. They concern source API, not a historical release closure. No release, conformance or whole-platform pass is implied.
